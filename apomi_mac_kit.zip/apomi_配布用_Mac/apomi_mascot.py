# -*- coding: utf-8 -*-
"""デスクトップに住むアポミちゃん（常駐マスコット）。

画面のすみに小さなアポミちゃんが立っていて、その「魔法の窓」に予約一覧などの
ファイルをドラッグ＆ドロップすると、そのままチェックが走る。

・背景は透明（Windows）。アポミちゃんと金色の窓だけが浮かんで見える
・ドラッグで好きな場所へ移動できる（位置は次回も覚えている）
・右クリックでメニュー（魔法の窓を開く／取り込みフォルダ／隠す）
・Macなど透明にできない環境では、クリーム色の小さなカードとして表示する

起動: python apomi_main.py --mascot   （または apomi_mascot.main()）
"""
import os
import sys
import json
import shutil
import threading
import traceback
import tkinter as tk

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
from apomi_paths import data_dir, open_path

IS_WIN = sys.platform.startswith('win')
IS_MAC = sys.platform == 'darwin'
KEY_COLOR = '#0b0c0d'          # ここを透明にする（画面でまず使われない色）
CARD_COLOR = '#fffcf2'         # 透明にできない環境の下地（イラストと同じクリーム）
MASCOT_W = 430                 # 表示するアポミちゃんの幅（ピクセル）
IMG_IDLE = 'アポミちゃん（窓・待機）_透過.png'    # ふだん（ここにドロップしてね）
IMG_BUSY = 'アポミちゃん（窓・受取）_透過.png'    # 受け取った直後（喜んでいる）
POS_FILE = 'アポミちゃんの居場所.json'

# 落とされたファイルの振り分け（拡張子とファイル名から、どの受け皿か決める）
SHIFT_WORDS = ('shift', 'シフト', '勤務')
MEMO_WORDS = ('休み', '臨時休', 'メモ', 'off')


def _pos_path():
    return os.path.join(data_dir(), POS_FILE)


def load_pos():
    try:
        with open(_pos_path(), encoding='utf-8') as f:
            d = json.load(f)
        return int(d['x']), int(d['y'])
    except Exception:
        return None


def save_pos(x, y):
    try:
        with open(_pos_path(), 'w', encoding='utf-8') as f:
            json.dump({'x': int(x), 'y': int(y)}, f)
    except OSError:
        pass


# ===== パソコン起動時に自動で出す =====
STARTUP_LNK = 'アポミちゃん.lnk'


def _startup_dir():
    return os.path.join(os.environ.get('APPDATA', ''),
                        'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')


def _startup_lnk():
    return os.path.join(_startup_dir(), STARTUP_LNK)


MAC_AGENT = os.path.expanduser('~/Library/LaunchAgents/jp.apomi.mascot.plist')


def autostart_on():
    if IS_WIN:
        return os.path.exists(_startup_lnk())
    if IS_MAC:
        return os.path.exists(MAC_AGENT)
    return False


def _set_autostart_mac(on):
    """Macは「ログイン項目」の代わりに LaunchAgent を置く（管理者権限は不要）"""
    try:
        if not on:
            if os.path.exists(MAC_AGENT):
                os.remove(MAC_AGENT)
            return True
        os.makedirs(os.path.dirname(MAC_AGENT), exist_ok=True)
        if getattr(sys, 'frozen', False):
            args = [sys.executable, '--mascot']
        else:
            args = [sys.executable, os.path.join(BASE, 'apomi_main.py'), '--mascot']
        items = '\n'.join(f'    <string>{a}</string>' for a in args)
        plist = ('<?xml version="1.0" encoding="UTF-8"?>\n'
                 '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
                 '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                 '<plist version="1.0"><dict>\n'
                 '  <key>Label</key><string>jp.apomi.mascot</string>\n'
                 '  <key>ProgramArguments</key><array>\n' + items + '\n  </array>\n'
                 '  <key>RunAtLoad</key><true/>\n'
                 '</dict></plist>\n')
        with open(MAC_AGENT, 'w', encoding='utf-8') as f:
            f.write(plist)
        return True
    except Exception:
        return False


def _launch_command():
    """アポミちゃんを起こすための「実行するもの」と「引数」を返す"""
    if getattr(sys, 'frozen', False):          # 製品版（exe）
        return sys.executable, '--mascot'
    exe = sys.executable                       # 開発時（python）
    w = exe.replace('python.exe', 'pythonw.exe')   # 黒い画面を出さない
    if os.path.exists(w):
        exe = w
    return exe, f'-X utf8 "{os.path.join(BASE, "apomi_main.py")}" --mascot'


def set_autostart(on):
    """スタートアップにショートカットを置く/消す（管理者権限は不要）"""
    if IS_MAC:
        return _set_autostart_mac(on)
    if not IS_WIN:
        return False
    lnk = _startup_lnk()
    try:
        if not on:
            if os.path.exists(lnk):
                os.remove(lnk)
            return True
        os.makedirs(_startup_dir(), exist_ok=True)
        target, args = _launch_command()
        ps = ('$s=(New-Object -ComObject WScript.Shell).CreateShortcut({0});'
              '$s.TargetPath={1};$s.Arguments={2};$s.WorkingDirectory={3};'
              '$s.Description={4};$s.Save()').format(
            _ps_quote(lnk), _ps_quote(target), _ps_quote(args),
            _ps_quote(BASE), _ps_quote('apomi デスクトップのアポミちゃん'))
        import subprocess
        r = subprocess.run(['powershell', '-NoProfile', '-Command', ps],
                           capture_output=True,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        return r.returncode == 0 and os.path.exists(lnk)
    except Exception:
        return False


def _ps_quote(s):
    """PowerShellの文字列にする（'を''にして囲む）"""
    return "'" + str(s).replace("'", "''") + "'"


def _settings_path():
    return os.path.join(data_dir(), 'アポミちゃんの設定.json')


def load_prefs():
    try:
        with open(_settings_path(), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_prefs(d):
    try:
        with open(_settings_path(), 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False)
    except OSError:
        pass


def _image_path(name):
    for d in (os.path.join(BASE, 'アポミちゃん', 'web'), os.path.join(BASE, 'web'), BASE):
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    return ''


def cutout(im):
    """イラストの下地（クリーム色）だけを透明にする。
    画面のふち・魔法の窓の内側からつながっている部分だけを消すので、
    帽子の白いリボン・白い靴・歯のチャームなど、内側の白は残る。"""
    im = im.convert('RGBA')
    w, h = im.size
    px = im.load()

    def is_bg(c):
        r, g, b = c[0], c[1], c[2]
        return r > 240 and g > 236 and b > 222

    seen = bytearray(w * h)
    stack = []
    for x in range(w):                      # 画面の上下のふち
        for y in (0, h - 1):
            stack.append((x, y))
    for y in range(h):                      # 画面の左右のふち
        for x in (0, w - 1):
            stack.append((x, y))
    # 魔法の窓の内側（イラストの左寄り中央）からも消し始める
    for sx, sy in ((int(w * 0.22), int(h * 0.45)), (int(w * 0.22), int(h * 0.7))):
        stack.append((sx, sy))
    while stack:
        x, y = stack.pop()
        if x < 0 or y < 0 or x >= w or y >= h:
            continue
        i = y * w + x
        if seen[i]:
            continue
        seen[i] = 1
        if not is_bg(px[x, y]):
            continue
        px[x, y] = (0, 0, 0, 0)
        stack.extend(((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)))
    return im


def shrink_transparent(im, width):
    """アルファ付きのまま縮小して、輪郭に下地の色がにじまないようにする。

    ふつうに「下地に合成してから縮小」すると、縁の半透明部分に下地の色
    （＝透明にしたい色）が焼き付き、透明にならずに黒いフチとして残る。
    そこで①色にアルファを掛けてから縮小②縮小後に割り戻す、の順で処理する。"""
    from PIL import Image
    im = im.convert('RGBA')
    h = int(im.height * width / im.width)
    a = im.getchannel('A')
    ch = []
    for c in im.split()[:3]:                      # ① 乗算（外側の色を混ぜない）
        ch.append(Image.frombytes('L', im.size, bytes(
            (v * av) // 255 for v, av in zip(c.tobytes(), a.tobytes()))))
    ch = [c.resize((width, h), Image.LANCZOS) for c in ch]
    a = a.resize((width, h), Image.LANCZOS)
    ab = a.tobytes()
    ch = [Image.frombytes('L', (width, h), bytes(                # ② 割り戻す
        min(255, (v * 255) // av) if av > 8 else 0
        for v, av in zip(c.tobytes(), ab))) for c in ch]
    col = Image.merge('RGB', ch)
    # Windowsの透明化は「その色ぴったり」しか消せないので、半透明は残す/消すの二択にする
    hard = a.point(lambda v: 255 if v >= 140 else 0)
    out = Image.new('RGB', (width, h), _hex_to_rgb(KEY_COLOR))
    out.paste(col, mask=hard)
    return out


def make_photo(root, transparent, name=IMG_IDLE):
    """アポミちゃんの画像を読み込んで、表示用に縮小する。
    transparent=True なら下地を KEY_COLOR に置き換える（＝画面上で透明になる）。"""
    cut = _image_path(name)                                  # 切り抜き済み（あればこちら）
    src = cut or _image_path('アポミちゃん（魔法の窓）.png')
    if not src:
        return None
    try:
        from PIL import Image, ImageTk
        tag = 'busy' if name == IMG_BUSY else 'idle'
        cache = os.path.join(data_dir(),
                             f'.mascot3_{tag}_{MASCOT_W}{"_t" if transparent else ""}.png')
        try:    # 切り抜きは少し時間がかかるので、一度作ったら次からは使い回す
            if os.path.getmtime(cache) > os.path.getmtime(src):
                return ImageTk.PhotoImage(Image.open(cache), master=root)
        except OSError:
            pass
        im = Image.open(src)
        if transparent:
            if im.mode != 'RGBA' or im.getchannel('A').getextrema()[0] == 255:
                im = cutout(im)                   # 切り抜き済みが無いときだけ自分で抜く
            im = shrink_transparent(im, MASCOT_W)
        else:
            # 透明にできない環境はクリームのカードに乗せる（下地と同じ色なのでにじまない）
            if im.mode == 'RGBA':
                bg = Image.new('RGBA', im.size, _hex_to_rgb(CARD_COLOR) + (255,))
                im = Image.alpha_composite(bg, im)
            im = im.convert('RGB')
            im = im.resize((MASCOT_W, int(im.height * MASCOT_W / im.width)), Image.LANCZOS)
        try:
            im.save(cache)
        except OSError:
            pass
        return ImageTk.PhotoImage(im, master=root)
    except Exception:
        # Pillowが無い環境でも動くように（縮小だけの簡易版・下地は残る）
        img = tk.PhotoImage(file=src, master=root)
        k = max(1, round(img.width() / MASCOT_W))
        return img.subsample(k, k)


def _hex_to_rgb(s):
    s = s.lstrip('#')
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def classify(path):
    """落とされたファイルが、予約一覧・シフト表・お休みメモのどれかを判断する"""
    name = os.path.basename(path)
    low = name.lower()
    ext = os.path.splitext(low)[1]
    if ext == '.txt' or any(w in low for w in MEMO_WORDS):
        return 'memo'
    if any(w in low for w in SHIFT_WORDS):
        return 'shift'
    if ext in ('.csv', '.xls', '.xlsx', '.xlsm', '.pdf'):
        return 'yoyaku'
    return ''


def receive(paths, inbox):
    """落とされたファイルを取り込みフォルダへ入れる。戻り値 (入れたファイル, 断ったファイル)"""
    os.makedirs(inbox, exist_ok=True)
    ok, ng = [], []
    for p in paths:
        if os.path.isdir(p):
            ng.append(os.path.basename(p))
            continue
        kind = classify(p)
        if not kind:
            ng.append(os.path.basename(p))
            continue
        if kind == 'shift':
            dst = os.path.join(inbox, 'シフト表_取込' + os.path.splitext(p)[1])
        elif kind == 'memo':
            dst = os.path.join(inbox, '臨時休メモ.txt')
        else:
            dst = os.path.join(inbox, os.path.basename(p))
            stem, ext = os.path.splitext(dst)
            i = 2
            while os.path.exists(dst):
                dst = f'{stem}({i}){ext}'
                i += 1
        try:
            shutil.copy2(p, dst)
            ok.append(dst)
        except OSError:
            ng.append(os.path.basename(p))
    return ok, ng


class Mascot:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('アポミちゃん')
        self.root.overrideredirect(True)          # 枠なしウィンドウ
        self.root.attributes('-topmost', True)    # いつも手前に
        self.transparent = False
        if IS_WIN:
            try:
                self.root.configure(bg=KEY_COLOR)
                self.root.attributes('-transparentcolor', KEY_COLOR)
                self.transparent = True
            except tk.TclError:
                pass
        if not self.transparent:
            self.root.configure(bg=CARD_COLOR)

        self.photo = make_photo(self.root, self.transparent, IMG_IDLE)
        self.photo_busy = make_photo(self.root, self.transparent, IMG_BUSY)
        bg = KEY_COLOR if self.transparent else CARD_COLOR
        self.label = tk.Label(self.root, image=self.photo, bg=bg, bd=0,
                              cursor='hand2')
        self.label.pack()
        self.bubble = tk.Label(self.root, text='', bg='#fff8e6', fg='#8a5a1e',
                               font=('Meiryo UI', 10, 'bold'), bd=0, padx=10, pady=4)

        pos = load_pos()
        self.root.update_idletasks()
        w = self.root.winfo_width() or MASCOT_W
        h = self.root.winfo_height() or MASCOT_W
        if pos:
            x, y = pos
        else:   # はじめては右下（タスクバーの少し上）に立たせる
            x = self.root.winfo_screenwidth() - w - 30
            y = self.root.winfo_screenheight() - h - 90
        # 絵の大きさを変えたときや、モニタ構成が変わったときに画面外へ消えないようにする
        x = max(0, min(x, self.root.winfo_screenwidth() - w))
        y = max(0, min(y, self.root.winfo_screenheight() - h - 40))
        self.root.geometry(f'+{x}+{y}')

        self.label.bind('<Button-1>', self._grab)
        self.label.bind('<B1-Motion>', self._drag)
        self.label.bind('<ButtonRelease-1>', self._drop_move)
        self.label.bind('<Button-3>', self._menu)
        self.label.bind('<Button-2>', self._menu)          # Macの右クリック
        self.label.bind('<Control-Button-1>', self._menu)  # Macのcontrol+クリック
        self.label.bind('<Double-Button-1>', lambda e: self.open_magic_window())
        if not IS_WIN:
            # Windows以外は窓へのドロップを受け取れないので、
            # 「クリックしたら魔法の窓がひらく」を入り口にする
            self.label.bind('<ButtonRelease-1>', self._click_open, add='+')
        self._moved = False
        self._register_drop()
        self.root.after(1200, self._first_time)

    def _first_time(self):
        """はじめて出したときだけ、次回から自動で出るようにする（黙ってやらない）"""
        p = load_prefs()
        if p.get('asked') or not IS_WIN:
            return
        p['asked'] = True
        p['autostart'] = set_autostart(True)
        save_prefs(p)
        if p['autostart']:
            self.say('次からは、パソコンを開くと自動で出ます'
                     '（右クリックでやめられます）', 7000)

    # ---- 表示まわり ----
    def set_busy(self, busy):
        """受け取った瞬間だけ、喜んでいる絵に切り替える"""
        img = self.photo_busy if busy else self.photo
        if img:
            self.label.config(image=img)

    def say(self, text, msec=2500):
        """アポミちゃんの上にひとことを出す"""
        self.bubble.config(text=text)
        self.bubble.pack(before=self.label)
        if msec:
            self.root.after(msec, self.bubble.pack_forget)

    def _grab(self, e):
        self._ox, self._oy, self._moved = e.x_root, e.y_root, False

    def _drag(self, e):
        dx, dy = e.x_root - self._ox, e.y_root - self._oy
        if abs(dx) > 2 or abs(dy) > 2:
            self._moved = True
        self.root.geometry(f'+{self.root.winfo_x() + dx}+{self.root.winfo_y() + dy}')
        self._ox, self._oy = e.x_root, e.y_root

    def _drop_move(self, e):
        if self._moved:
            save_pos(self.root.winfo_x(), self.root.winfo_y())

    def _click_open(self, e):
        """動かしただけのときは何もしない。ただ押しただけなら窓をひらく"""
        if not self._moved:
            self.open_magic_window()

    def _menu(self, e):
        m = tk.Menu(self.root, tearoff=0)
        m.add_command(label='🪄 魔法の窓をひらく', command=self.open_magic_window)
        m.add_command(label='📂 取り込みフォルダをひらく', command=self.open_inbox)
        m.add_separator()
        on = autostart_on()
        m.add_command(label=('✅ パソコンを開いたら出てくる' if on
                             else '　 パソコンを開いたら出てくる'),
                      command=self.toggle_autostart)
        m.add_separator()
        m.add_command(label='× 今日は隠れる（次に開いたときはまた出ます）',
                      command=self.root.destroy)
        m.tk_popup(e.x_root, e.y_root)

    def toggle_autostart(self):
        want = not autostart_on()
        ok = set_autostart(want)
        p = load_prefs()
        p['autostart'] = want
        p['asked'] = True
        save_prefs(p)
        if not ok:
            self.say('設定を変えられませんでした…', 3500)
        elif want:
            self.say('次からは、パソコンを開くと出てきます🪄', 4000)
        else:
            self.say('自動で出るのをやめました', 3500)

    # ---- 受け取り ----
    def inbox(self):
        import watch_patrol as w
        return w.INBOX

    def open_inbox(self):
        try:
            open_path(self.inbox())
        except OSError:
            pass

    def open_magic_window(self):
        def run():
            try:
                import apomi_main
                apomi_main.open_magic_window()
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()
        self.say('窓をひらいたよ！', 2500)

    def on_files(self, paths):
        """ファイルを受け取ったときの処理（画面を止めないよう裏で走らせる）"""
        ok, ng = receive(paths, self.inbox())
        if ng:
            self.say('これは読めないかも…: ' + '、'.join(ng[:2]), 4000)
        if not ok:
            return
        self.set_busy(True)

        def run():
            try:
                import watch_patrol as w
                w.maybe_apply_shift_drop()
                w.maybe_apply_offmemo_drop()
                targets = [p for p in ok if os.path.exists(p)
                           and not w._is_special_name(os.path.basename(p))]
                if targets:
                    w.process(max(targets, key=os.path.getmtime))
            except Exception:
                try:
                    import watch_patrol as w
                    w.log(f'マスコットからの処理でエラー:\n{traceback.format_exc()}')
                except Exception:
                    pass
            finally:   # チェックが終わったら、いつもの顔に戻す
                try:
                    self.root.after(0, lambda: self.set_busy(False))
                except Exception:
                    pass
        threading.Thread(target=run, daemon=True).start()

    def _register_drop(self):
        """Windows: エクスプローラーからのドロップを受け取れるようにする"""
        if not IS_WIN:
            return
        try:
            import ctypes
            from ctypes import wintypes
            shell32 = ctypes.windll.shell32
            user32 = ctypes.windll.user32
            self.root.update()          # 窓ができてから登録する
            # winfo_id() が返すのは内側の窓(TkChild)。エクスプローラーからのドロップは
            # 外側の窓(TkTopLevel)に届くので、必ず外側を取り直す（2026-08-20の不具合）
            hwnd = self.root.winfo_id()
            top = user32.GetAncestor(hwnd, 2) or user32.GetParent(hwnd) or hwnd
            hwnd = top
            shell32.DragAcceptFiles(hwnd, True)
            try:    # 念のため、ドロップ関連のメッセージを通す（環境によっては既定で塞がる）
                flt = user32.ChangeWindowMessageFilterEx
                for msg in (0x0233, 0x0049, 0x004A):   # DROPFILES/COPYGLOBALDATA/COPYDATA
                    flt(hwnd, msg, 1, None)            # 1 = MSGFLT_ALLOW
            except Exception:
                pass

            WM_DROPFILES = 0x0233
            GWLP_WNDPROC = -4
            LRESULT = ctypes.c_ssize_t
            WPARAM, LPARAM = ctypes.c_size_t, ctypes.c_ssize_t
            WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND,
                                         ctypes.c_uint, WPARAM, LPARAM)
            set_long = getattr(user32, 'SetWindowLongPtrW', user32.SetWindowLongW)
            # 64bit環境で値が欠けないよう、引数と戻り値の型をきちんと宣言する
            set_long.argtypes = [wintypes.HWND, ctypes.c_int, WNDPROC]
            set_long.restype = ctypes.c_void_p
            call_old = user32.CallWindowProcW
            call_old.argtypes = [ctypes.c_void_p, wintypes.HWND,
                                 ctypes.c_uint, WPARAM, LPARAM]
            call_old.restype = LRESULT

            # 受け取ったHDROPは64bitの値。型を宣言しないと32bitに切り詰められて
            # OverflowError になり、ドロップが黙って消える（2026-08-20の不具合）
            shell32.DragQueryFileW.argtypes = [ctypes.c_void_p, ctypes.c_uint,
                                               ctypes.c_wchar_p, ctypes.c_uint]
            shell32.DragQueryFileW.restype = ctypes.c_uint
            shell32.DragFinish.argtypes = [ctypes.c_void_p]

            def handler(h, msg, wparam, lparam):
                if msg == WM_DROPFILES:
                    try:
                        hdrop = ctypes.c_void_p(wparam)
                        n = shell32.DragQueryFileW(hdrop, 0xFFFFFFFF, None, 0)
                        buf = ctypes.create_unicode_buffer(1024)
                        files = []
                        for i in range(n):
                            shell32.DragQueryFileW(hdrop, i, buf, 1024)
                            files.append(buf.value)
                        shell32.DragFinish(hdrop)
                        self.root.after(1, lambda: self.on_files(files))
                    except Exception:
                        self._log(f'ドロップの受け取りで失敗:\n{traceback.format_exc()}')
                    return 0
                if not self._old_proc:
                    return user32.DefWindowProcW(h, msg, wparam, lparam)
                return call_old(self._old_proc, h, msg, wparam, lparam)

            self._old_proc = None                  # 差し替え中に来たメッセージ対策
            self._proc = WNDPROC(handler)          # 参照を保持（消えると落ちる）
            self._old_proc = set_long(hwnd, GWLP_WNDPROC, self._proc)
        except Exception:
            self._log(f'ドロップの登録で失敗:\n{traceback.format_exc()}')

    def _log(self, msg):
        """黙って消えると原因が分からなくなるので、必ず記録に残す"""
        try:
            import watch_patrol as w
            w.log(msg)
        except Exception:
            try:
                with open(os.path.join(data_dir(), 'アポミちゃんのログ.txt'),
                          'a', encoding='utf-8') as f:
                    f.write(msg + '\n')
            except Exception:
                pass

    def run(self):
        self.root.mainloop()


def main():
    try:
        Mascot().run()
    except Exception:
        traceback.print_exc()
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
