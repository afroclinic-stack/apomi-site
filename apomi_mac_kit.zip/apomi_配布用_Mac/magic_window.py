# -*- coding: utf-8 -*-
"""アポミの魔法の窓 — 取り込みフォルダを知らなくても、ここにファイルを落とせば取り込める入り口。

仕組み: パソコンの中だけで動く小さな受付（ローカルサーバー）を立てて、その画面をブラウザで開く。
ドラッグ＆ドロップまたは「ファイルを選ぶ」で渡されたファイルを apomi_取込 フォルダに保存する。
外部への通信は一切しない（127.0.0.1 = 自分自身のみ）。

使い方（apomi_main.py から）:
    import magic_window
    saved = magic_window.open_window(inbox_dir, system_label='アポツール（Apotool & Box）')
    # saved = 保存したファイルのパス一覧（窓を閉じた／取り込んだら返る）
"""
import os
import re
import json
import base64
import shutil
import socket
import threading
import http.server
import urllib.parse

BASE = os.path.dirname(os.path.abspath(__file__))

# 受け皿の定義（表示名, 説明, 受け付ける拡張子, 保存時の名前の付け方）
SLOTS = [
    ('yoyaku', '予約一覧', 'いつもの予約表（CSV・Excel・PDF）',
     ('.csv', '.xls', '.xlsx', '.xlsm', '.pdf'), None),
    ('shift', 'シフト表', 'スタッフの勤務表（CSV）。入れておくと「担当が休みの日の予約」も見つけます',
     ('.csv', '.xls', '.xlsx'), 'シフト表_取込'),
    ('memo', 'お休みメモ', '有給・セミナーなどの臨時のお休み（テキスト）',
     ('.txt',), '臨時休メモ'),
]


def _img(name):
    """アポミちゃんの画像を画面に直接埋め込む（外部ファイル参照なしで完結させる）"""
    for d in (os.path.join(BASE, 'アポミちゃん', 'web'),
              os.path.join(BASE, 'web'), BASE):
        p = os.path.join(d, name)
        if os.path.exists(p):
            ext = 'png' if name.lower().endswith('.png') else 'jpeg'
            with open(p, 'rb') as f:
                return f'data:image/{ext};base64,' + base64.b64encode(f.read()).decode('ascii')
    return ''


def _safe_name(name):
    """変な文字・フォルダ移動の記号を落として、安全なファイル名にする"""
    name = os.path.basename(name.replace('\\', '/'))
    name = re.sub(r'[\x00-\x1f<>:"|?*]', '', name).strip() or 'file'
    return name[:120]


PAGE = r'''<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>apomi ｜ アポミの魔法の窓</title>
<style>
 :root{--mint:#eefaf6;--green:#2fa27a;--green-d:#1f7d5e;--leaf:#7cc6a6;--ink:#274b40;
   --line:#cfe8dd;--gold:#e0a83c;--cream:#fffaf0;}
 *{box-sizing:border-box}
 body{font-family:-apple-system,"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif;
   color:var(--ink);margin:0;background:linear-gradient(160deg,var(--mint),var(--cream));
   min-height:100vh;line-height:1.8}
 .wrap{max-width:900px;margin:0 auto;padding:22px 18px 50px}
 .head{display:flex;align-items:center;gap:14px;justify-content:center;text-align:center;
   flex-wrap:wrap;margin-bottom:6px}
 .head h1{font-size:21px;color:var(--green-d);margin:0}
 .head p{margin:2px 0 0;font-size:13.5px;color:#5c7d70}
 .stage{display:flex;gap:18px;align-items:flex-start;justify-content:center;flex-wrap:wrap;margin-top:10px}
 .apomi{width:230px;flex:0 0 auto;text-align:center}
 .apomi img{width:100%;border-radius:16px}
 .slots{flex:1 1 420px;min-width:320px;display:flex;flex-direction:column;gap:12px}
 .slot{background:#fff;border:2.5px dashed var(--leaf);border-radius:18px;padding:14px 16px;
   transition:.15s;position:relative}
 .slot.main{border-color:var(--gold);box-shadow:0 4px 16px rgba(224,168,60,.18)}
 .slot.over{background:#fffbe9;border-color:var(--gold);transform:scale(1.02)}
 .slot.done{border-style:solid;border-color:var(--green);background:#f3fbf8}
 .slot b{display:block;font-size:16px;color:var(--green-d)}
 .slot .desc{font-size:12.5px;color:#6d8d81;margin:2px 0 8px}
 .slot .zone{font-size:13.5px;color:#5c7d70}
 .pick{display:inline-block;background:var(--green);color:#fff;border:0;border-radius:999px;
   padding:7px 16px;font-size:13px;font-weight:800;cursor:pointer;font-family:inherit}
 .pick:hover{background:var(--green-d)}
 .files{margin:8px 0 0;padding:0;list-style:none;font-size:13px}
 .files li{background:var(--mint);border-radius:8px;padding:4px 10px;margin-top:4px}
 .go{display:block;width:100%;margin-top:16px;background:var(--gold);color:#fff;border:0;
   border-radius:16px;padding:15px;font-size:18px;font-weight:900;cursor:pointer;font-family:inherit;
   box-shadow:0 5px 16px rgba(224,168,60,.35)}
 .go:disabled{background:#d8e4df;color:#96aca3;box-shadow:none;cursor:default}
 .note{font-size:12px;color:#7c968c;text-align:center;margin-top:14px}
 .done-view{display:none;text-align:center;padding:20px 0}
 .done-view img{width:260px;border-radius:18px}
 .done-view .msg{font-size:20px;font-weight:900;color:var(--green-d);margin-top:8px}
 .done-view .sub{font-size:14px;color:#5c7d70}
 .sparkle{position:fixed;pointer-events:none;font-size:22px;animation:up 1.1s ease-out forwards}
 @keyframes up{from{opacity:1;transform:translateY(0) scale(.6)}
   to{opacity:0;transform:translateY(-70px) scale(1.3)}}
</style></head><body>
<div class="wrap">
 <div id="main">
  <div class="head">
   <div><h1>🪄 ここに入れてね！</h1>
    <p>__LABEL__ から書き出したファイルを、下のわくにドラッグ＆ドロップ。<br>
       「ファイルを選ぶ」から選んでもOKです。</p></div>
  </div>
  <div class="stage">
   <div class="apomi"><img src="__IMG_WINDOW__" alt="アポミちゃん"></div>
   <div class="slots" id="slots"></div>
  </div>
  <button class="go" id="go" disabled>🦷 チェックをはじめる</button>
  <div class="note">🔒 ファイルはこのパソコンの中だけで扱われます（どこにも送信されません）</div>
 </div>
 <div class="done-view" id="done">
  <img src="__IMG_JOY__" alt="アポミちゃん">
  <div class="msg">受け取りました！</div>
  <div class="sub" id="doneSub">いまからチェックします。結果の画面がひらくまで少し待ってね。<br>
    この画面は閉じて大丈夫です。</div>
 </div>
</div>
<script>
var SLOTS = __SLOTS__;
var picked = {};   // key -> [File]
function $(id){ return document.getElementById(id); }

function sparkle(x, y){
  var s = document.createElement('div');
  s.className = 'sparkle'; s.textContent = '✨';
  s.style.left = (x - 10) + 'px'; s.style.top = (y - 10) + 'px';
  document.body.appendChild(s);
  setTimeout(function(){ s.remove(); }, 1100);
}

function refresh(){
  var any = false;
  SLOTS.forEach(function(s){
    var box = $('slot_' + s.key), ul = $('files_' + s.key);
    var list = picked[s.key] || [];
    ul.innerHTML = '';
    list.forEach(function(f){
      var li = document.createElement('li');
      li.textContent = '📄 ' + f.name;
      ul.appendChild(li);
    });
    box.classList.toggle('done', list.length > 0);
    if (list.length) any = true;
  });
  $('go').disabled = !any;
}

function addFiles(key, fileList, ev){
  var s = SLOTS.filter(function(x){ return x.key === key; })[0];
  var ok = [], ng = [];
  Array.prototype.forEach.call(fileList, function(f){
    var e = ('.' + f.name.split('.').pop()).toLowerCase();
    (s.ext.indexOf(e) >= 0 ? ok : ng).push(f);
  });
  if (ng.length){
    alert('この枠に入れられるのは ' + s.ext.join(' / ') + ' です。\n' +
          '入らなかったファイル: ' + ng.map(function(f){ return f.name; }).join('、'));
  }
  if (!ok.length) return;
  picked[key] = (picked[key] || []).concat(ok);
  refresh();
  if (ev) sparkle(ev.clientX, ev.clientY);
}

SLOTS.forEach(function(s){
  var div = document.createElement('div');
  div.className = 'slot' + (s.key === 'yoyaku' ? ' main' : '');
  div.id = 'slot_' + s.key;
  div.innerHTML = '<b>' + s.title + '</b><div class="desc">' + s.desc + '</div>' +
    '<div class="zone">ここにドラッグ＆ドロップ　または　' +
    '<button class="pick" type="button">ファイルを選ぶ</button></div>' +
    '<ul class="files" id="files_' + s.key + '"></ul>' +
    '<input type="file" multiple class="hide" style="display:none" accept="' + s.ext.join(',') + '">';
  $('slots').appendChild(div);
  var input = div.querySelector('input');
  div.querySelector('.pick').addEventListener('click', function(){ input.click(); });
  input.addEventListener('change', function(){ addFiles(s.key, input.files, null); input.value = ''; });
  ['dragenter','dragover'].forEach(function(t){
    div.addEventListener(t, function(e){ e.preventDefault(); div.classList.add('over'); });
  });
  ['dragleave','drop'].forEach(function(t){
    div.addEventListener(t, function(e){ e.preventDefault(); div.classList.remove('over'); });
  });
  div.addEventListener('drop', function(e){
    if (e.dataTransfer && e.dataTransfer.files) addFiles(s.key, e.dataTransfer.files, e);
  });
});
// 画面のどこに落としてもブラウザが勝手にファイルを開かないようにする
['dragover','drop'].forEach(function(t){
  window.addEventListener(t, function(e){ e.preventDefault(); });
});
refresh();

$('go').addEventListener('click', function(){
  var fd = new FormData(), n = 0;
  SLOTS.forEach(function(s){
    (picked[s.key] || []).forEach(function(f){ fd.append(s.key, f, f.name); n++; });
  });
  if (!n) return;
  $('go').disabled = true;
  $('go').textContent = '🪄 魔法をかけています…';
  fetch('/upload', {method: 'POST', body: fd}).then(function(r){ return r.json(); })
   .then(function(res){
     if (!res.ok) throw new Error(res.msg || '保存に失敗しました');
     $('main').style.display = 'none';
     $('done').style.display = 'block';
     if (res.msg) $('doneSub').innerHTML = res.msg;
     for (var i = 0; i < 12; i++){
       (function(i){ setTimeout(function(){
         sparkle(window.innerWidth / 2 + (Math.random() - .5) * 260,
                 window.innerHeight / 2 + (Math.random() - .5) * 160);
       }, i * 90); })(i);
     }
   })
   .catch(function(e){
     alert('うまく受け取れませんでした。\nもう一度お試しください。\n\n詳細: ' + e);
     $('go').disabled = false;
     $('go').textContent = '🦷 チェックをはじめる';
   });
});
</script></body></html>'''


def build_page(system_label):
    slots = [{'key': k, 'title': t, 'desc': d, 'ext': list(ext)}
             for (k, t, d, ext, _) in SLOTS]
    return (PAGE
            .replace('__LABEL__', system_label or 'お使いの予約システム')
            .replace('__IMG_WINDOW__', _img('アポミちゃん（魔法の窓）.png'))
            .replace('__IMG_JOY__', _img('アポミちゃん（受け取り喜び）.png'))
            .replace('__SLOTS__', json.dumps(slots, ensure_ascii=False)))


def _parse_multipart(body, boundary):
    """アップロードされたファイルを取り出す（[(枠のkey, ファイル名, 中身)]）。
    標準のcgiモジュールはPython 3.13で廃止のため、自前で最小限だけ解く。"""
    out = []
    sep = b'--' + boundary
    for part in body.split(sep):
        if not part.strip() or part.strip() == b'--':
            continue
        head, _, data = part.partition(b'\r\n\r\n')
        if not data:
            continue
        head_s = head.decode('utf-8', 'replace')
        m = re.search(r'name="([^"]*)"', head_s)
        fm = re.search(r'filename="([^"]*)"', head_s)
        if not m or not fm or not fm.group(1):
            continue
        out.append((m.group(1), fm.group(1), data.rstrip(b'\r\n')))
    return out


def open_window(inbox, system_label='', timeout_sec=900):
    """魔法の窓を開き、受け取ったファイルを inbox に保存する。
    戻り値: 保存したファイルのパス一覧（何も受け取らずに閉じたら空）"""
    from apomi_paths import open_path
    os.makedirs(inbox, exist_ok=True)
    page = build_page(system_label).encode('utf-8')
    saved = []
    done = threading.Event()
    store_names = {k: st for (k, _, _, _, st) in SLOTS}

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass                      # ターミナルに通信ログを出さない

        def _send(self, code, ctype, body):
            self.send_response(code)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            try:
                self.wfile.write(body)
            except OSError:
                pass

        def do_GET(self):
            if self.path.startswith('/close'):
                self._send(200, 'text/plain; charset=utf-8', b'ok')
                done.set()
                return
            self._send(200, 'text/html; charset=utf-8', page)

        def do_POST(self):
            try:
                ctype = self.headers.get('Content-Type', '')
                m = re.search(r'boundary=(.+)$', ctype)
                length = int(self.headers.get('Content-Length', 0))
                if not m or length <= 0:
                    raise ValueError('ファイルがありませんでした')
                body = self.rfile.read(length)
                got = _parse_multipart(body, m.group(1).strip('"').encode('utf-8'))
                if not got:
                    raise ValueError('ファイルがありませんでした')
                for key, name, data in got:
                    name = _safe_name(name)
                    fixed = store_names.get(key)
                    if fixed:      # シフト表・お休みメモは決まった名前で置く
                        name = fixed + os.path.splitext(name)[1]
                    dst = os.path.join(inbox, name)
                    stem, ext = os.path.splitext(dst)
                    i = 2
                    while os.path.exists(dst) and not fixed:
                        dst = f'{stem}({i}){ext}'
                        i += 1
                    with open(dst, 'wb') as f:
                        f.write(data)
                    saved.append(dst)
                msg = ('いまからチェックします。結果の画面がひらくまで少し待ってね。<br>'
                       'この画面は閉じて大丈夫です。')
                if not any(os.path.splitext(p)[1].lower() in ('.csv', '.xls', '.xlsx', '.xlsm', '.pdf')
                           and 'シフト' not in os.path.basename(p)
                           and '臨時休' not in os.path.basename(p) for p in saved):
                    msg = ('登録しました！ 次に<b>予約一覧</b>を入れると、'
                           'お休みの人の予約もまとめてチェックします。<br>この画面は閉じて大丈夫です。')
                self._send(200, 'application/json; charset=utf-8',
                           json.dumps({'ok': True, 'msg': msg}).encode('utf-8'))
            except Exception as e:
                self._send(200, 'application/json; charset=utf-8',
                           json.dumps({'ok': False, 'msg': str(e)}).encode('utf-8'))
                return
            threading.Timer(1.0, done.set).start()   # 返事を返しきってから終了

    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f'http://127.0.0.1:{srv.server_address[1]}/'
    try:
        open_path(url)
    except OSError:
        pass
    done.wait(timeout_sec)      # 受け取るか、時間切れまで待つ
    srv.shutdown()
    srv.server_close()
    return saved
