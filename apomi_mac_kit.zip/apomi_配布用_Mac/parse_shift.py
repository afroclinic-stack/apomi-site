# -*- coding: utf-8 -*-
"""勤務予定表PDF（月間シフト）をパースする"""
import re, sys, json, datetime
import pdfplumber

def role_of(header):
    h = header.replace('．', '.').replace(' ', '')
    if h.startswith('院長') or h.startswith('Dr'):
        return 'Dr'
    if h.startswith('DH'):
        return 'DH'
    if h.startswith('TC'):
        return 'TC'
    if h.startswith('RD'):
        return 'RD'
    return '他'

def surname_of(header):
    s = re.sub(r'^(院長|Dr\.?|DH\.?|DH|TC|RD)', '',
               header.replace('．', '.').replace(' ', ''))
    return s if s else header  # 「院長」「TC」など名前なしはそのまま

def parse_shift(path):
    """{日(int): [{'name','role','start','end'} または 休は含めない]} を返す"""
    days = {}
    with pdfplumber.open(path) as pdf:
        # タイトル等から年月を拾う（例: 2026年7月）
        month_info = ''
        for page in pdf.pages:
            t = (page.extract_text() or '')[:200]
            m = re.search(r'(\d{4})年\s*(\d{1,2})月', t)
            if m:
                month_info = f'{m.group(1)}-{int(m.group(2)):02d}'
                break
        for page in pdf.pages:
            for table in page.extract_tables():
                header = [(c or '').replace('\n', '').strip() for c in table[0]]
                staff_cols = [(i, h) for i, h in enumerate(header) if i >= 3 and h]
                for row in table[1:]:
                    cells = [(c or '').replace('\n', '').strip() for c in row]
                    if not cells or not cells[0].isdigit():
                        continue
                    day = int(cells[0])
                    days.setdefault(day, [])
                    for i, h in staff_cols:
                        v = cells[i] if i < len(cells) else ''
                        m = re.match(r'(\d{1,2}:\d{2})～(\d{1,2}:\d{2})', v)
                        if m:
                            days[day].append({'name': surname_of(h), 'role': role_of(h),
                                              'start': m.group(1), 'end': m.group(2)})
    return {'month': month_info, 'days': days}

if __name__ == '__main__':
    res = parse_shift(sys.argv[1])
    print('month:', res['month'])
    d4 = res['days'].get(4, [])
    print('7/4 出勤:', len(d4))
    for s in d4:
        print(' ', s['role'], s['name'], s['start'], '-', s['end'])


# ===== アポツール（Apotool & Box）のシフト表CSV =====
# 形式: 1行目「YYYY年M月　シフト表」/ 2行目=日番号 / 3行目=曜日 /
#       役職見出し行（歯科医・衛生士・助手）の下にスタッフ行（コード or 空欄=休み）/
#       末尾に「勤務時間帯」の凡例（時間帯名(コード), 勤務時間）
import csv as _csv
import io as _io
import unicodedata as _ud

_APOTOOL_ROLES = {'歯科医': 'Dr', '衛生士': 'DH', '助手': 'DA', '受付': '受付', 'その他': ''}


def is_apotool_shift(text):
    """アポツールのシフト表CSVかどうか"""
    head = text[:200]
    return ('シフト表' in head) and re.search(r'\d{4}年\s*\d{1,2}月', head) is not None


def parse_apotool_shift(text):
    """アポツールのシフト表CSV → {'year','month','byDate':{'YYYY-MM-DD':[{name,role,start,end}]}}
    byDate はその月の全日をキーに持つ（誰も出勤しない日は空リスト＝休診日と判定できる）。"""
    rows = list(_csv.reader(_io.StringIO(text.lstrip('\ufeff'))))
    if not rows or not rows[0]:
        raise ValueError('シフト表が空です')
    m = re.search(r'(\d{4})年\s*(\d{1,2})月', rows[0][0])
    if not m:
        raise ValueError('シフト表の年月が見つかりません')
    year, month = int(m.group(1)), int(m.group(2))
    day_row = next((r for r in rows
                    if sum(1 for c in r[1:] if c.strip().isdigit()) >= 27), None)
    if day_row is None:
        raise ValueError('シフト表の日付の行が見つかりません')
    day_cols = [(i, int(c)) for i, c in enumerate(day_row) if c.strip().isdigit()]
    # 凡例: 「時間帯名(コード)」,「HH:MM - HH:MM」。同じコードが複数あれば最初を採用。
    legend = {}
    for r in rows:
        lm = re.match(r'^(.+?)（?\((.+?)\)）?$', (r[0] or '').strip())
        if lm and len(r) > 1:
            tm = re.match(r'(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})', (r[1] or '').strip())
            if tm and lm.group(2) not in legend:
                legend[lm.group(2)] = (tm.group(1), tm.group(2))
    by_date = {}
    for d in range(1, 32):
        try:
            datetime.date(year, month, d)
        except ValueError:
            continue
        by_date[f'{year}-{month:02d}-{d:02d}'] = []
    cur_role = None
    for r in rows[1:]:
        name = (r[0] or '').strip()
        if not name:
            continue
        if name in _APOTOOL_ROLES:
            cur_role = _APOTOOL_ROLES[name]
            continue
        if name == '勤務時間帯' or '時間帯名' in name or cur_role is None:
            continue
        if name.upper().startswith('FREE'):
            # FREE枠は「人」ではなく空き枠の器。休み判定の対象外＝毎日いる扱いにする。
            for key in by_date:
                by_date[key].append({'name': name, 'role': cur_role,
                                     'start': '00:00', 'end': '23:59'})
            continue
        for i, d in day_cols:
            code = (r[i] if i < len(r) else '').strip()
            if not code:
                continue
            start, end = legend.get(code, ('09:00', '18:00'))
            key = f'{year}-{month:02d}-{d:02d}'
            if key in by_date:
                by_date[key].append({'name': name, 'role': cur_role,
                                     'start': start, 'end': end})
    n = sum(len(v) for v in by_date.values())
    if n == 0:
        raise ValueError('出勤データが1件も読み取れませんでした')
    return {'year': year, 'month': month, 'byDate': by_date}


# ===== 臨時休メモ（有給・セミナーなどの不規則な休み） =====
# 1行1件: 「8/15 桑野 有給」「2026/8/20 濱 セミナー」など。日付と名前だけでもOK。

_OFF_REASONS = ('有給', '有休', '休暇', '休み', '欠勤', 'セミナー', '研修',
                '出張', '学会', '休診')
_HONORIFICS = ('先生', 'せんせい', 'さん', '様', 'Dr', 'DH', 'DA', '氏')


def _split_name_reason(s):
    """「納冨先生有給」「桑野 有給」などから (名前, 理由) を取り出す。
    敬称は名前から外す（シフト表の名前と前方一致させるため）。"""
    s = s.strip()
    reason = ''
    for w in _OFF_REASONS:
        i = s.find(w)
        if i > 0:                      # 名前のあとに理由語がくっついている
            s, reason = s[:i], s[i:]
            break
    name = s.strip()
    for h in _HONORIFICS:
        if len(name) > len(h) and name.endswith(h):
            name = name[:-len(h)]
            break
    return name.strip(), reason.strip()


def parse_off_memo(text):
    """臨時休メモ → [{'date':'YYYY-MM-DD','name':..., 'reason':...}]（読めた行だけ）。
    アポツールの日毎メモをそのまま貼った「8/8 納冨先生有給」のような行も読める。"""
    out = []
    this_year = datetime.date.today().year
    for line in text.splitlines():
        line = line.strip().lstrip('・-　 ')
        if not line or line.startswith('#') or line.startswith('※'):
            continue
        dm = re.match(r'(?:(\d{4})[/年])?(\d{1,2})[/月](\d{1,2})日?[\s,、\t]*', line)
        if not dm:
            continue
        y = int(dm.group(1)) if dm.group(1) else this_year
        try:
            date = datetime.date(y, int(dm.group(2)), int(dm.group(3)))
        except ValueError:
            continue
        rest = line[dm.end():].strip()
        if not rest:
            continue
        parts = [p for p in re.split(r'[\s,、\t]+', rest) if p]
        if len(parts) >= 2:
            name, extra = _split_name_reason(parts[0])
            reason = (extra + ' ' + ' '.join(parts[1:])).strip()
        else:
            name, reason = _split_name_reason(parts[0])
        if name:
            out.append({'date': date.isoformat(), 'name': name, 'reason': reason})
    return out


def apply_off_memo(shift, memo):
    """臨時休メモを出勤情報(byDate)に反映する（その日その人を休み扱いに）。
    名前は前方一致（メモ「桑野」→シフト「桑野碧」に一致）。"""
    if not shift or not shift.get('byDate') or not memo:
        return shift
    def norm(s):
        return _ud.normalize('NFKC', s or '').replace('　', '').replace(' ', '')
    for e in memo:
        key = e['date']
        nm = norm(e['name'])
        if key in shift['byDate'] and nm:
            shift['byDate'][key] = [s for s in shift['byDate'][key]
                                    if not norm(s['name']).startswith(nm)]
    return shift
