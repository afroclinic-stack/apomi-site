# -*- coding: utf-8 -*-
"""予約一覧CSVを取り込む汎用アダプタ。

システムごとに「設定ファイル（JSON）」を1枚用意すれば、同じエンジンで
どの予約システムのCSVでも読める。各社のCSVは列名・日付形式・時刻の書き方が
違うので、その対応関係だけを設定ファイルに書く。

設定ファイルは「取り込み設定」フォルダに置く（例: Apotool.json）。
"""
import os, csv, json, io, re, datetime

from apomi_paths import data_dir
BASE = data_dir()
CONFIG_DIR = os.path.join(BASE, '取り込み設定')

# apo_patrol が使う共通レコードの項目
OUT_FIELDS = ['予約日', '開始', '終了', '区分', '患者No', '氏名', '性別',
              '年齢', 'スタッフ', 'チェア', '処置名', '主訴', '特記事項', '要注意']

def list_configs():
    """使える取り込み設定の一覧を返す [(表示名, パス)]"""
    if not os.path.isdir(CONFIG_DIR):
        return []
    out = []
    for fn in sorted(os.listdir(CONFIG_DIR)):
        if fn.lower().endswith('.json'):
            path = os.path.join(CONFIG_DIR, fn)
            try:
                with open(path, encoding='utf-8') as f:
                    name = json.load(f).get('name', fn)
            except Exception:
                name = fn
            out.append((name, path))
    return out

def load_config(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)

# ===== 日付・時刻の解釈 =====

def _to_reiwa(s):
    """いろいろな日付表記を「令和8.07.17」形式に変換する。
    受け付ける例: 2026-07-17 / 2026/07/17 / R8.7.17 / 令和8年7月17日"""
    s = (s or '').strip()
    # 令和表記
    m = re.search(r'(?:令和|R|Ｒ)\s*(\d+)\D+(\d+)\D+(\d+)', s)
    if m:
        y = 2018 + int(m.group(1)); mo = int(m.group(2)); d = int(m.group(3))
        return f'令和{y - 2018}.{mo:02d}.{d:02d}'
    # 西暦表記
    m = re.search(r'(\d{4})\D+(\d{1,2})\D+(\d{1,2})', s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f'令和{y - 2018}.{mo:02d}.{d:02d}'
    return s

def _norm_time(s):
    """9:0 / 09:00 / 9時00分 → 09:00"""
    s = (s or '').strip()
    m = re.search(r'(\d{1,2})\D+(\d{1,2})', s)
    if m:
        return f'{int(m.group(1)):02d}:{int(m.group(2)):02d}'
    return s

def _split_range(s):
    """「09:00～09:30」を ('09:00','09:30') に分ける"""
    parts = re.split(r'[~～\-—−]', s or '', maxsplit=1)
    if len(parts) == 2:
        return _norm_time(parts[0]), _norm_time(parts[1])
    return _norm_time(s), ''

# ===== 取り込み本体 =====

def _excel_rows(path):
    """Excelファイル（.xls / .xlsx）の1枚目のシートを文字列の行列にする"""
    if path.lower().endswith('.xls'):
        import xlrd
        # アポツールの.xlsはOLE構造が僅かに壊れていることがある（実ファイルで確認済み）
        bk = xlrd.open_workbook(path, ignore_workbook_corruption=True)
        sh = bk.sheet_by_index(0)
        rows = []
        for r in range(sh.nrows):
            row = []
            for c in range(sh.ncols):
                cell = sh.cell(r, c)
                if cell.ctype == xlrd.XL_CELL_DATE:
                    dt = xlrd.xldate.xldate_as_datetime(cell.value, bk.datemode)
                    # 時刻だけのセル（日付部が1899年）は時刻として出す
                    if dt.year < 1905:
                        row.append(dt.strftime('%H:%M'))
                    else:
                        row.append(dt.strftime('%Y/%m/%d %H:%M').replace(' 00:00', ''))
                elif cell.ctype == xlrd.XL_CELL_NUMBER and cell.value == int(cell.value):
                    row.append(str(int(cell.value)))
                else:
                    row.append('' if cell.value is None else str(cell.value))
            rows.append(row)
        return rows
    import openpyxl
    import datetime as _dt
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sh = wb.worksheets[0]
    rows = []
    for row in sh.iter_rows(values_only=True):
        out = []
        for v in row:
            if v is None:
                out.append('')
            elif isinstance(v, _dt.datetime):
                out.append(v.strftime('%Y/%m/%d %H:%M').replace(' 00:00', ''))
            elif isinstance(v, _dt.time):
                out.append(v.strftime('%H:%M'))
            elif isinstance(v, float) and v == int(v):
                out.append(str(int(v)))
            else:
                out.append(str(v))
        rows.append(out)
    wb.close()
    return rows


def excel_to_csv_text(path_or_rows):
    """Excel → CSVテキスト（既存のCSV処理をそのまま使うため）"""
    rows = path_or_rows if isinstance(path_or_rows, list) else _excel_rows(path_or_rows)
    buf = io.StringIO()
    w = csv.writer(buf)
    for r in rows:
        w.writerow(r)
    return buf.getvalue()


# ===== 予約表グリッド形式（アポツール等）の読み取り =====
# セルの中身の例:
#   10:00-10:30 <153>
#   塩谷 安奈/シオタニ アンナ/39歳(4) /C処 /小泉
#   次回アポあり
GRID_APPT = re.compile(
    r'(\d{1,2}[:：]\d{2})\s*[-~～〜]\s*(\d{1,2}[:：]\d{2})\s*[<＜](\d+)[>＞]')


def is_grid(rows):
    """「行=時間帯・列=ユニット・マスに予約」のグリッド形式かを判定する"""
    for row in rows[:60]:
        for c in row:
            if GRID_APPT.search(str(c)):
                return True
    return False


_KATAKANA = re.compile(r'^[ァ-ヶーｦ-ﾟ・\s　]+$')


def _staff_like(s):
    """担当者名らしいか。数字・カッコ入り・長すぎる文字列はメニュー名とみなす
    （例:「3Mメンテ(SPT)」を担当と誤読して同名扱い→ダブルブッキング誤検知、の再発防止）"""
    return bool(s) and not re.search(r'[0-9０-９()（）]', s) and len(s) <= 6


def _grid_info(line):
    """マス内の情報行「氏名/カナ/39歳(4) /C処 /小泉」を分解する。
    年齢・担当が無いマス（例「氏名/カナ/3Mメンテ(SPT)」）でも誤読しない。"""
    fields = [f.strip() for f in line.split('/') if f.strip()]
    if not fields:
        return '', '', '', ''
    name, rest = fields[0], fields[1:]
    if rest and _KATAKANA.match(rest[0]):      # カナ行は読み飛ばす
        rest = rest[1:]
    age = ''
    if rest and '歳' in rest[0]:
        age = re.sub(r'\D', '', rest[0].split('(')[0])
        rest = rest[1:]
    # 残りは「処置…／担当」。処置の欄が複数に分かれる医院もある
    # （例:「氏名/カナ/56歳(1) /大草DH業務/3Mメンテ(SPT) /大草」＝業務・処置・担当の3つ）。
    # 担当は必ず最後にくるので、最後が担当者名らしければ担当、それ以外は全部まとめて処置とする。
    if len(rest) > 1 and _staff_like(rest[-1]):
        staff = rest[-1]
        proc = ' '.join(rest[:-1]).strip()
    else:
        staff = ''
        proc = ' '.join(rest).strip()
    return name, age, proc, staff


LAST_ABSENCES = []      # 直近のグリッド読み取りで見つかった休み情報（日毎メモ・不在ブロック）

_ABS_REASONS = ('有給', '有休', '休暇', '休み', '欠勤', 'セミナー', '研修',
                '出張', '学会', '休診', '不在')
_ABS_TIME = re.compile(r'(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})')
# 歯科の名字でよくある異体字（予約表の「納富」とメモの「納冨」を同一視するため）
_KANJI_VARIANTS = {'冨': '富', '髙': '高', '﨑': '崎', '嶋': '島', '邉': '辺', '邊': '辺',
                   '齋': '斉', '齊': '斉', '斎': '斉', '眞': '真', '澤': '沢', '淺': '浅',
                   '惠': '恵', '國': '国', '德': '徳', '榮': '栄'}

def fold_name(s):
    """名前照合用の正規化（NFKC＋空白除去＋異体字の同一視）"""
    import unicodedata
    s = unicodedata.normalize('NFKC', s or '').replace('　', '').replace(' ', '')
    return ''.join(_KANJI_VARIANTS.get(c, c) for c in s)


_ABS_HONORIFICS = ('先生', 'せんせい', 'さん', '様', 'Dr', 'DH', 'DA', '氏')

def _abs_name_reason(s):
    """「斉藤有給」「納冨先生 休み」→ (名前, 理由)。敬称は名前から外す。
    （parse_shift._split_name_reason と同じ考え方。お試し版はparse_shiftが
      スタブのため、こちらに独立して持つ）"""
    s = s.strip()
    reason = ''
    for w in _ABS_REASONS:
        i = s.find(w)
        if i > 0:
            s, reason = s[:i], s[i:]
            break
    name = s.strip()
    for h in _ABS_HONORIFICS:
        if len(name) > len(h) and name.endswith(h):
            name = name[:-len(h)]
            break
    return name.strip(), reason.strip()


def _grid_absences(rows, date_reiwa):
    """グリッドの「日毎メモ」行と「◯◯不在」ブロックから休み情報を拾う。
    戻り値: [{'日付','名前','理由','開始','終了','根拠'}]（開始が空＝終日）"""
    _split_name_reason = _abs_name_reason
    out, seen = [], set()
    # ① 日毎メモ（自由記述。休み関連の言葉がある行だけ拾う）
    memo_i = next((i for i, row in enumerate(rows)
                   if any(str(c).strip() == '日毎メモ' for c in row)), -1)
    if memo_i >= 0:
        for row in rows[memo_i + 1:]:
            for c in row:
                line = str(c).strip()
                if not line or not any(w in line for w in _ABS_REASONS):
                    continue
                name, reason = _split_name_reason(line.replace('不在', '休み'))
                if name and (name, '') not in seen:
                    seen.add((name, ''))
                    out.append({'日付': date_reiwa, '名前': name,
                                '理由': reason or 'お休み', '開始': '', '終了': '',
                                '根拠': f'日毎メモ「{line}」'})
    # ② 不在ブロック（患者番号のない「9:30-14:00 ◯◯不在」のマス）
    for row in rows:
        for cell in row:
            text = str(cell)
            if '不在' not in text or GRID_APPT.search(text):
                continue          # 予約の入ったマスは対象外
            tm = _ABS_TIME.search(text)
            if not tm:
                continue
            for line in text.splitlines():
                line = line.strip()
                if not line.endswith('不在'):
                    continue
                name, _ = _split_name_reason(line[:-len('不在')])
                start, end = _norm_time(tm.group(1)), _norm_time(tm.group(2))
                if name and (name, start) not in seen:
                    seen.add((name, start))
                    out.append({'日付': date_reiwa, '名前': name, '理由': '不在',
                                '開始': start, '終了': end,
                                '根拠': f'予約表のブロック「{start}-{end} {line}」'})
    return out


def grid_records(rows):
    """グリッド形式 → 共通レコード形式。日付は先頭付近のセルから拾う。
    あわせて日毎メモ・不在ブロックの休み情報を LAST_ABSENCES に入れる。"""
    date = ''
    for row in rows[:5]:
        for c in row:
            m = re.search(r'(\d{4})[/年.-](\d{1,2})[/月.-](\d{1,2})', str(c))
            if m:
                date = f'{m.group(1)}/{m.group(2)}/{m.group(3)}'
                break
        if date:
            break

    # 見出し行 = 予約ブロックを含まず、2列目以降に名前が2つ以上ある最初の行
    head_i, headers = -1, []
    for i, row in enumerate(rows[:10]):
        cells = [str(c).strip() for c in row]
        if any(GRID_APPT.search(c) for c in cells):
            break
        if len(cells) >= 3 and sum(1 for c in cells[1:] if c) >= 2 \
                and not any(re.search(r'\d{4}[/年.-]\d{1,2}', c) for c in cells):
            head_i, headers = i, cells
            break

    seen = set()
    global LAST_ABSENCES
    LAST_ABSENCES = _grid_absences(rows, _to_reiwa(date))

    records = []
    for row in rows[head_i + 1:]:
        for j, cell in enumerate(row):
            if j == 0:
                continue      # 1列目は時間ラベル
            chair = headers[j] if j < len(headers) else ''
            text = str(cell)
            hits = list(GRID_APPT.finditer(text))
            for k, m in enumerate(hits):
                seg_end = hits[k + 1].start() if k + 1 < len(hits) else len(text)
                seg = text[m.end():seg_end]
                start = _norm_time(m.group(1))
                end = _norm_time(m.group(2))
                pno = m.group(3)
                key = (pno, start, chair)
                if key in seen:   # 複数の時間帯行に同じ予約が現れても1件に
                    continue
                seen.add(key)
                lines = [l.strip() for l in seg.splitlines() if l.strip()]
                name = age = proc = staff = ''
                notes = []
                if lines:
                    name, age, proc, staff = _grid_info(lines[0])
                    notes = lines[1:]
                rec = {f: '' for f in OUT_FIELDS}
                rec.update({
                    '予約日': _to_reiwa(date), '開始': start, '終了': end,
                    '患者No': pno, '氏名': name.replace('　', ' ').strip(),
                    '年齢': age, 'スタッフ': staff, 'チェア': chair,
                    '処置名': proc, '特記事項': ' '.join(notes),
                })
                records.append(rec)
    return records


def _sniff_delim(text):
    """区切り文字を推定する（カンマ・タブ・セミコロン）"""
    head = '\n'.join(text.splitlines()[:10])
    counts = {d: head.count(d) for d in (',', '\t', ';')}
    return max(counts, key=counts.get) if any(counts.values()) else ','


def _header_offset(rows, wanted):
    """見出し行が先頭でないファイル（上部に日付やタイトル行がある書き出し）に
    対応するため、設定の列名が現れる行を探す。見つからなければ0行目。"""
    want = {str(w).strip() for w in wanted if w}
    for i, row in enumerate(rows[:30]):
        cells = {str(c).strip() for c in row}
        hits = len(want & cells)
        if hits >= min(2, len(want)) and hits >= 1:
            return i
    return 0


def _rows_to_records(rows, config):
    """行列 → 共通レコード形式（グリッド形式なら専用の読み取りへ）"""
    if is_grid(rows):
        return grid_records(rows)
    off = _header_offset(rows, config.get('columns', {}).values())
    buf = io.StringIO()
    w = csv.writer(buf)
    for r in rows[off:]:
        w.writerow(r)
    buf.seek(0)
    return _read_reader(csv.DictReader(buf), config)


def read_any(path, config):
    """CSV / Excel（.xls .xlsx）を共通レコード形式に変換する"""
    global LAST_ABSENCES
    LAST_ABSENCES = []          # 前のファイルの休み情報を持ち越さない（グリッド読取で再設定）
    ext = os.path.splitext(path)[1].lower()
    if ext in ('.xls', '.xlsx', '.xlsm'):
        return _rows_to_records(_excel_rows(path), config)
    return read_csv(path, config)


def _read_text(path, enc_hint):
    """文字コードを自動判別して読む（UTF-8系 → cp932 → 設定値の順に試す）。
    予約システムによって書き出しの文字コードが違うため、決め打ちにしない。"""
    with open(path, 'rb') as f:
        raw = f.read()
    text = None
    for enc in ('utf-8-sig', 'cp932', enc_hint):
        try:
            text = raw.decode(enc)
            break
        except (UnicodeDecodeError, LookupError):
            continue
    if text is None:
        text = raw.decode(enc_hint or 'utf-8-sig', errors='replace')
    # 裸の\r（バイナリ誤投入や他OS由来）でcsvパーサが落ちないよう改行を正規化する
    return text.replace('\r\n', '\n').replace('\r', '\n')


def read_csv(path, config):
    """CSVを共通レコード形式に変換する"""
    text = _read_text(path, config.get('encoding', 'utf-8-sig'))
    rows = list(csv.reader(io.StringIO(text), delimiter=_sniff_delim(text)))
    return _rows_to_records(rows, config)


def _read_reader(reader, config):
    cols = config.get('columns', {})            # 共通項目 → CSVの列見出し
    chair_map = config.get('chair_map', {})     # チェア名の言い換え（任意）
    gender_map = config.get('gender_map', {})   # 性別の言い換え（任意）
    skip_status = config.get('skip_status', []) # 無視する状態（キャンセル等）

    records = []
    if True:
        for row in reader:
            def col(field):
                src = cols.get(field)
                return (row.get(src, '') or '').strip() if src else ''

            # キャンセル済みなどを除外
            status = col('状態') or col('区分')
            if any(k and k in status for k in skip_status):
                continue

            # 時刻: 開始/終了が別列か、1列の範囲表記か、開始+所要時間(分)か
            if cols.get('時間帯'):
                start, end = _split_range(col('時間帯'))
            else:
                start, end = _norm_time(col('開始')), _norm_time(col('終了'))
            if not start:
                continue  # 予約行でない
            # 時刻の形になっていない値（「終日」「未定」等）で後段が落ちないようにする
            if not re.match(r'^\d{1,2}:\d{2}$', start):
                continue                       # 開始が時刻でない行は予約として扱わない
            if end and not re.match(r'^\d{1,2}:\d{2}$', end):
                end = ''
            if not end and cols.get('所要分'):
                # アポツール一覧形式など「開始時刻＋所要時間(分)」の書き出しに対応
                dur = re.sub(r'\D', '', col('所要分'))
                if dur:
                    h, m = start.split(':')
                    t = int(h) * 60 + int(m) + int(dur)
                    end = f'{t // 60:02d}:{t % 60:02d}'
            if not end:
                end = start                    # 終了不明でも読み込みは続ける（長さ0分扱い）

            date = _to_reiwa(col('予約日'))
            chair = col('チェア')
            chair = chair_map.get(chair, chair)
            gender = col('性別')
            gender = gender_map.get(gender, gender)

            rec = {k: '' for k in OUT_FIELDS}
            rec.update({
                '予約日': date, '開始': start, '終了': end,
                '区分': col('区分'),
                '患者No': col('患者No'),
                '氏名': col('氏名').replace('　', ' ').strip(),
                '性別': gender, '年齢': re.sub(r'\D', '', col('年齢')),
                'スタッフ': col('スタッフ'),
                'チェア': chair,
                '処置名': col('処置名'),
                '主訴': col('主訴'),
                '特記事項': col('特記事項'),
                '要注意': col('要注意'),
            })
            records.append(rec)
    return records

if __name__ == '__main__':
    import sys
    cfg = load_config(sys.argv[2])
    recs = read_csv(sys.argv[1], cfg)
    print(f'{len(recs)}件 取り込み（設定: {cfg.get("name")}）')
    for r in recs[:3]:
        print(' ', r['予約日'], r['開始'], r['終了'], r['チェア'], r['患者No'], r['氏名'], r['処置名'])
