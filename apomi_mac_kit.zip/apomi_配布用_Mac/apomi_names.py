# -*- coding: utf-8 -*-
"""同姓同名・似た名前の注意（患者さんの取り違え防止）。

この部品は「アポ表の患者さん」と「照らし合わせる患者さんの一覧」を渡すと、
注意の一覧を返すだけ。ファイルの読み書きも通信もしない（＝ここには何も保存されない）。

    alerts = find_similar(appts, patients)

appts    … アポ表の予約。1件 = {'date','start','end','chair','no','name','kana','birth','age'}
patients … 照らし合わせる相手（登録のある患者さんなど）。1人 = {'no','name','kana','birth','age'}
           省略すると「同じ日のアポ表の中」だけを見る。
戻り値   … 注意の一覧。1件 = {'date','kind','reasons','a','b','level'}
           kind: 'same_day'（同じ日に2人とも予約がある）/ 'registered'（もう1人は登録にいる別の患者さん）

別人かどうかは患者番号で決める（番号が同じ＝同じ人＝注意しない）。
番号が無いデータでは、生年月日が両方あって違うときだけ別人とみなす（分からないときは黙る）。

「似ている」の基準（院長と決めたもの・2026-10-05。強さは全部「注意」）:
  1. 漢字が同じ        … 空白・全角半角の違いを除いて、氏名の文字が同じ
  2. 旧字体ちがい      … 髙/高、齋/斎/斉、邊/邉/辺、﨑/崎 などをそろえると同じ
  3. よみが同じ        … ふりがな（よみ）があり、それが同じ（漢字は違う）
  4. 名字のよみが同じ  … よみのデータが無いとき用。伊藤/伊東 のような「よくある同じ読みの名字」の表で補う
                        （名前のほうは同じ漢字のときだけ）
名字だけが同じ人（ご家族など）は注意しない。多すぎて誰も見なくなるため。
"""
import re
import html
import unicodedata

LEVEL = '注意'
CATEGORY = '似た名前'

# ── 旧字体・異体字 → そろえる先（比べるときだけ使う。表示は元の字のまま）─────────
_VARIANT_PAIRS = (
    '髙高 﨑崎 嵜崎 碕崎 齋斉 齊斉 斎斉 邊辺 邉辺 濱浜 濵浜 澤沢 廣広 國国 圀国 櫻桜 嶋島 嶌島 '
    '德徳 惠恵 眞真 槇槙 龍竜 瀧滝 條条 圓円 藏蔵 與与 萬万 壽寿 榮栄 實実 靜静 彌弥 禮礼 '
    '曾曽 增増 莊荘 壯壮 淺浅 渕淵 驒騨 黑黒 賴頼 瀨瀬 來来 兒児 學学 桒桑 栁柳 舘館 冨富 '
    '嶽岳 峯峰 淸清 髮髪 豐豊 惣総 聰聡 澁渋 濟済 縣県 廳庁 鐵鉄 鹽塩 稻稲 穗穂 穰穣 '
    '櫛櫛 橫横 權権 歲歳 氣気 滿満 榊榊 祐祐 福福 晴晴 靑青 敎教 敏敏 梅梅 海海 琢琢 '
    '𠮷吉 塚塚 ヶケ ｹケ ケケ'
).split()
VARIANTS = {p[0]: p[-1] for p in _VARIANT_PAIRS if len(p) >= 2 and p[0] != p[-1]}

# ── よみのデータが無いときに使う「よくある同じ読みの名字」──────────────────
# 1行が1グループ。旧字体は上の表で先にそろえるので、ここは新字体だけでよい。
_HOMOPHONE_SURNAMES = '''
伊藤 伊東 井藤
佐藤 佐東 左藤
加藤 加東 嘉藤
後藤 五藤 後東
近藤 今藤
安藤 安東
遠藤 円藤
斉藤 西藤
渡辺 渡部
阿部 安部 安倍 阿倍
河野 川野
菊池 菊地
小島 児島
川村 河村
川合 河合 川井 河井
川上 河上
川口 河口
川端 川畑 河端
坂本 阪本 坂元
坂田 阪田 酒田
酒井 坂井 境
山本 山元
松本 松元
橋本 橋元
岡本 岡元
福本 福元
杉本 杉元
宮本 宮元
秋本 秋元
新井 荒井
上田 植田
上野 植野
森田 守田 盛田
柴田 芝田
増田 益田 桝田 舛田
吉川 吉河 芳川
古川 古河
西川 西河
前川 前河
中川 中河 仲川
中村 仲村
中田 仲田
中野 仲野
中山 仲山
太田 大田
大島 大嶋
小沢 尾沢
長島 永島
長田 永田
長井 永井
長野 永野
'''
HOMOPHONE = {}
for _i, _line in enumerate(l for l in _HOMOPHONE_SURNAMES.strip().splitlines() if l.strip()):
    for _name in _line.split():
        HOMOPHONE.setdefault(_name, set()).add(_i)

_SPACE = re.compile(r'[\s　]+')
_VS = re.compile('[︀-️\U000e0100-\U000e01ef]')   # 異体字セレクタ


def basic(name):
    """全角半角・異体字セレクタをそろえる（空白は残す）"""
    return _VS.sub('', unicodedata.normalize('NFKC', str(name or ''))).strip()


def key_raw(name):
    """空白と全角半角の違いだけを無視した氏名"""
    return _SPACE.sub('', basic(name))


def fold(text):
    """旧字体・異体字を新字体にそろえる"""
    return ''.join(VARIANTS.get(ch, ch) for ch in text)


def key_fold(name):
    return fold(key_raw(name))


def key_yomi(kana):
    """よみを比べる形にする（カタカナ→ひらがな、空白なし、同じ音の字をそろえる）。無ければ ''"""
    s = _SPACE.sub('', basic(kana))
    out = []
    for ch in s:
        c = ord(ch)
        if 0x30A1 <= c <= 0x30F6:
            ch = chr(c - 0x60)
        out.append(ch)
    s = ''.join(out)
    for a, b in (('づ', 'ず'), ('ぢ', 'じ'), ('を', 'お'), ('ゐ', 'い'), ('ゑ', 'え'), ('ゔ', 'ぶ')):
        s = s.replace(a, b)
    # ひらがな・長音以外（漢字など）が混ざっていたら、よみとしては使わない
    return s if s and re.fullmatch(r'[ぁ-ゖー・]+', s) else ''


def split_name(name):
    """「姓 名」を (姓, 名) に分ける。空白が無ければ (全体, '')"""
    parts = _SPACE.split(basic(name))
    parts = [p for p in parts if p]
    if len(parts) >= 2:
        return parts[0], ''.join(parts[1:])
    return (parts[0] if parts else ''), ''


def _homophone_key(name):
    """よみが無いとき用: 名字が「同じ読みの名字」の表にあれば (グループ番号, 名) を返す"""
    sur, given = split_name(name)
    if not sur or not given:
        return None
    groups = HOMOPHONE.get(fold(sur))
    if not groups:
        return None
    return (frozenset(groups), fold(given))


def _person(d):
    """入力の1件を、比べやすい形にそろえる"""
    name = basic(d.get('name', ''))
    return {
        'no': str(d.get('no') or '').strip(),
        'name': name,
        'kana': basic(d.get('kana', '')),
        'birth': str(d.get('birth') or '').strip(),
        'age': str(d.get('age') or '').strip(),
        'raw': key_raw(name),
        'fold': key_fold(name),
        'yomi': key_yomi(d.get('kana', '')),
        'homo': _homophone_key(name),
        'slots': [],
    }


def different_person(p, q):
    """別人だと言えるか。True=別人 / False=同じ人、または分からない（→注意しない）"""
    if p['no'] and q['no']:
        return p['no'] != q['no']
    if p['birth'] and q['birth']:
        return p['birth'] != q['birth']
    return False


def reasons_for(p, q):
    """2人の名前が似ている理由の一覧（似ていなければ空）"""
    if not p['raw'] or not q['raw']:
        return []
    if p['raw'] == q['raw']:
        r = ['漢字が同じ']
        if p['yomi'] and q['yomi']:
            r.append('よみも同じ' if p['yomi'] == q['yomi'] else 'よみは違う')
        return r
    if p['fold'] == q['fold']:
        r = ['旧字体ちがい']
        if p['yomi'] and q['yomi'] and p['yomi'] == q['yomi']:
            r.append('よみも同じ')
        return r
    if p['yomi'] and q['yomi']:
        return ['よみが同じ'] if p['yomi'] == q['yomi'] else []
    # どちらかのよみが分からないときだけ、名字の対応表で補う
    if p['homo'] and q['homo'] and p['homo'][1] == q['homo'][1] and (p['homo'][0] & q['homo'][0]):
        return ['名字のよみが同じ']
    return []


def _sort_time(p):
    return min((s[0] for s in p['slots'] if s[0]), default='99:99')


def find_similar(appts, patients=None, options=None):
    """アポ表（appts）の中と、照らし合わせる相手（patients）から、似た名前の別人を探す。"""
    options = options or {}
    # 日付ごと・患者さんごとにまとめる（同じ人の複数予約は1人として扱う）
    by_date = {}
    for a in appts or []:
        date = str(a.get('date') or '')
        if not date or not key_raw(a.get('name', '')):
            continue
        p = _person(a)
        ident = p['no'] or ('name:' + p['raw'] + '|' + p['birth'])
        day = by_date.setdefault(date, {})
        cur = day.get(ident)
        if cur is None:
            cur = day[ident] = p
        else:                                   # よみ・生年月日は、分かっている予約から補う
            for k in ('kana', 'yomi', 'birth', 'age'):
                if not cur[k] and p[k]:
                    cur[k] = p[k]
        cur['slots'].append((str(a.get('start') or ''), str(a.get('end') or ''), str(a.get('chair') or '')))

    regs = [_person(x) for x in (patients or []) if key_raw(x.get('name', ''))]
    # 相手を速く探すための索引
    idx = {'fold': {}, 'yomi': {}, 'homo': {}}
    for r in regs:
        idx['fold'].setdefault(r['fold'], []).append(r)
        if r['yomi']:
            idx['yomi'].setdefault(r['yomi'], []).append(r)
        if r['homo']:
            idx['homo'].setdefault(r['homo'][1], []).append(r)

    alerts = []
    for date in sorted(by_date):
        people = sorted(by_date[date].values(), key=lambda p: (_sort_time(p), p['no'], p['raw']))
        day_nos = {p['no'] for p in people if p['no']}
        seen_pairs = set()
        # ① 同じ日のアポ表の中
        for i, p in enumerate(people):
            for q in people[i + 1:]:
                if not different_person(p, q):
                    continue
                rs = reasons_for(p, q)
                if rs:
                    seen_pairs.add(frozenset((p['no'] or p['raw'], q['no'] or q['raw'])))
                    alerts.append({'date': date, 'kind': 'same_day', 'level': LEVEL,
                                   'reasons': ['同じ日に来院'] + rs, 'a': p, 'b': q})
        # ② 登録にいる別の患者さん
        if regs:
            for p in people:
                cands = {}
                for r in idx['fold'].get(p['fold'], []):
                    cands[id(r)] = r
                if p['yomi']:
                    for r in idx['yomi'].get(p['yomi'], []):
                        cands[id(r)] = r
                if p['homo']:
                    for r in idx['homo'].get(p['homo'][1], []):
                        cands[id(r)] = r
                done = set()
                for r in cands.values():
                    if r['no'] and r['no'] in day_nos:
                        continue                 # その人も同じ日に来る → ①で出している
                    if not different_person(p, r):
                        continue
                    key = frozenset((p['no'] or p['raw'], r['no'] or r['raw']))
                    if key in seen_pairs or key in done:
                        continue
                    rs = reasons_for(p, r)
                    if rs:
                        done.add(key)
                        alerts.append({'date': date, 'kind': 'registered', 'level': LEVEL,
                                       'reasons': rs, 'a': p, 'b': r})
    return alerts


# ===== 表示（文と、結果ページ用のカード）=====

def _who(p, with_slots=True):
    bits = [p['no'], p['name']]
    if p['kana']:
        bits.append(f'（{p["kana"]}）')
    if p['birth']:
        bits.append(f'{p["birth"]}生')
    elif p['age']:
        bits.append(f'{p["age"]}歳')
    s = ' '.join(b for b in bits if b)
    if with_slots and p['slots']:
        s += '　' + '、'.join(f'{a}〜{b} {c}'.strip() for a, b, c in p['slots'])
    return s


def message(alert):
    """チェック結果の一覧に出す文（1行目は「日付 見出し」＝ほかのチェックと同じ形）"""
    a, b = alert['a'], alert['b']
    head = f'{alert["date"]} 名前の似た別の患者さんがいます（{"・".join(alert["reasons"])}）'
    line2 = '  ② ' + _who(b) if alert['kind'] == 'same_day' else '  ② ' + _who(b, False) + '　※この日の予約はありません（登録のある別の患者さん）'
    return head + '\n  ① ' + _who(a) + '\n' + line2


def _mark_diff(x, y):
    """2つの氏名で、違っている字に印を付ける（長さが同じときだけ）"""
    ex, ey = html.escape, html.escape
    if len(x) != len(y):
        return ex(x), ey(y)
    ox, oy = [], []
    for cx, cy in zip(x, y):
        if cx == cy:
            ox.append(ex(cx)); oy.append(ey(cy))
        else:
            ox.append(f'<mark>{ex(cx)}</mark>'); oy.append(f'<mark>{ey(cy)}</mark>')
    return ''.join(ox), ''.join(oy)


def card_html(alert):
    """結果ページのカードの中身（2人を上下に並べ、違う字に色を付け、理由を札で出す）"""
    a, b = alert['a'], alert['b']
    na, nb = _mark_diff(a['name'], b['name'])
    tags = ''.join(f'<span class="nm-tag{" nm-day" if r == "同じ日に来院" else ""}">{html.escape(r)}</span>'
                   for r in alert['reasons'])

    def row(p, name_html, is_reg):
        when = ('、'.join(f'{html.escape(s)}〜{html.escape(e)} {html.escape(c)}'.strip() for s, e, c in p['slots'])
                if p['slots'] else '')
        if is_reg:
            when = 'この日の予約なし（登録のある別の患者さん）'
        age = (html.escape(p['birth']) + '生') if p['birth'] else ((html.escape(p['age']) + '歳') if p['age'] else '')
        return (f'<tr><td class="nm-no">{html.escape(p["no"])}</td>'
                f'<td class="nm-name">{name_html}</td>'
                f'<td class="nm-kana">{html.escape(p["kana"])}</td>'
                f'<td class="nm-age">{age}</td><td class="nm-when">{when}</td></tr>')

    return (f'<div class="nm-tags">{tags}</div>'
            '<table class="nm-tbl"><tr><th>患者番号</th><th>氏名</th><th>よみ</th><th>生年月日／年齢</th><th>予約</th></tr>'
            + row(a, na, False) + row(b, nb, alert['kind'] != 'same_day') + '</table>')


CARD_CSS = '''
  .nm-tags { margin-bottom:6px; }
  .nm-tag { display:inline-block; background:#e3f2fd; color:#1565c0; border-radius:999px; padding:1px 10px; font-size:12px; margin-right:6px; }
  .nm-tag.nm-day { background:#ffe0b2; color:#e65100; font-weight:700; }
  .nm-tbl { border-collapse:collapse; width:100%; font-size:13px; }
  .nm-tbl th { text-align:left; color:#78909c; font-weight:400; font-size:11px; padding:2px 8px 2px 0; }
  .nm-tbl td { padding:3px 8px 3px 0; border-top:1px solid #eceff1; vertical-align:top; }
  .nm-name { font-size:16px; font-weight:700; white-space:nowrap; }
  .nm-name mark { background:#fff176; color:#c62828; padding:0 1px; border-radius:3px; }
  .nm-no { color:#546e7a; white-space:nowrap; }
'''


def to_issues(alerts):
    """ほかのチェックと同じ形（重要度, 分類, 文）にする。あわせてカード用のHTMLも返す"""
    issues, cards = [], {}
    for al in alerts:
        msg = message(al)
        issues.append((al['level'], CATEGORY, msg))
        cards[msg] = card_html(al)
    return issues, cards
