# -*- coding: utf-8 -*-
"""apomi の入口（1つの実行ファイルにまとめる用）。

  apomi.exe            … アポチェック（取り込みフォルダの最新ファイルをチェック）
                          初回だけ、必要なフォルダ作成・自動起動登録なども行う
  apomi.exe --watch    … 見張り役（常駐。パソコン起動時に自動で動く）
  apomi.exe --setup    … 初期設定だけやり直す

画面のない実行ファイルにするため、お知らせは print ではなくダイアログで出す。
"""
import os
import sys
import glob
import subprocess
import traceback

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from apomi_paths import (data_dir, bundle_dir, desktop_dir, open_path,
                         IS_WIN, IS_MAC, IS_FROZEN)


def say(msg, title='apomi', kind='info'):
    """お知らせを出す。画面が使えない環境では黙って無視する。"""
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        if kind == 'error':
            messagebox.showerror(title, msg)
        else:
            messagebox.showinfo(title, msg)
        root.destroy()
    except Exception:
        try:
            print(msg)
        except Exception:
            pass


def _exe_path():
    """自分自身（exe または python スクリプト）の場所"""
    return sys.executable if IS_FROZEN else os.path.abspath(__file__)


def _make_shortcut(link_path, target, args='', icon=None):
    """Windowsのショートカットを作る（PowerShell経由。追加部品なしで作れる）"""
    if not IS_WIN:
        return False
    ps = (
        "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');"
        "$s.TargetPath='%s';$s.Arguments='%s';"
        "$s.WorkingDirectory='%s';%s$s.Save()"
        % (link_path, target, args, os.path.dirname(target),
           ("$s.IconLocation='%s';" % icon) if icon else '')
    )
    try:
        subprocess.run(['powershell', '-NoProfile', '-Command', ps],
                       check=True, capture_output=True, timeout=30)
        return True
    except Exception:
        return False


def _mac_autostart(exe):
    """Mac: ログイン時に見張り役が動くよう登録（launchd）。何度実行しても安全。"""
    la = os.path.expanduser('~/Library/LaunchAgents')
    plist = os.path.join(la, 'com.apomi.watch.plist')
    content = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"'
        ' "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0"><dict>\n'
        '  <key>Label</key><string>com.apomi.watch</string>\n'
        f'  <key>ProgramArguments</key><array><string>{exe}</string>'
        '<string>--watch</string></array>\n'
        '  <key>RunAtLoad</key><true/>\n'
        '</dict></plist>\n')
    try:
        os.makedirs(la, exist_ok=True)
        if os.path.exists(plist) and open(plist, encoding='utf-8').read() == content:
            return False
        with open(plist, 'w', encoding='utf-8') as f:
            f.write(content)
        subprocess.run(['launchctl', 'unload', plist], capture_output=True, timeout=20)
        subprocess.run(['launchctl', 'load', plist], capture_output=True, timeout=20)
        return True
    except Exception:
        return False


def _mac_app_root():
    """apomi.app として動いているとき、その .app 自体の場所を返す"""
    p = sys.executable
    for _ in range(3):
        p = os.path.dirname(p)
    return p if p.endswith('.app') else sys.executable


def setup(quiet=False):
    """初回の準備（何度実行しても安全）"""
    import shutil
    home = data_dir()
    made = []

    # 1. 医院設定.json が無ければ、初期値から作る
    cfg = os.path.join(home, '医院設定.json')
    if not os.path.exists(cfg):
        import json
        from apomi_settings import DEFAULTS
        with open(cfg, 'w', encoding='utf-8') as f:
            f.write(json.dumps(DEFAULTS, ensure_ascii=False, indent=2))
        made.append('医院設定.json')

    # 2. 取り込み設定フォルダ（同梱の見本をコピー）
    cdir = os.path.join(home, '取り込み設定')
    if not os.path.isdir(cdir):
        os.makedirs(cdir, exist_ok=True)
        src = os.path.join(bundle_dir(), '取り込み設定')
        if os.path.isdir(src):
            for fn in os.listdir(src):
                try:
                    shutil.copy2(os.path.join(src, fn), os.path.join(cdir, fn))
                except OSError:
                    pass
        made.append('取り込み設定フォルダ')

    # 3. 設定画面などのHTMLを、すぐ開ける場所に置く
    for fn in ('アポミちゃんのQ&A.html', 'ようこそ.html'):
        src = os.path.join(bundle_dir(), fn)
        dst = os.path.join(home, fn)
        if os.path.exists(src) and not os.path.exists(dst):
            try:
                shutil.copy2(src, dst)
            except OSError:
                pass

    # 4. 取り込みフォルダ（デスクトップ）を用意し、設定画面を「今の設定入り」で最新化
    import watch_patrol
    watch_patrol.ensure_inbox()
    watch_patrol.refresh_settings_page()

    # 5. パソコン起動時に見張り役が動くように登録＋デスクトップに「アポチェック」
    if IS_WIN and IS_FROZEN:
        exe = _exe_path()
        startup = os.path.join(os.environ.get('APPDATA', ''),
                               r'Microsoft\Windows\Start Menu\Programs\Startup')
        if os.path.isdir(startup):
            lnk = os.path.join(startup, 'apomi見張り.lnk')
            if not os.path.exists(lnk):
                if _make_shortcut(lnk, exe, '--watch'):
                    made.append('自動起動の登録')
        desk = desktop_dir()
        lnk2 = os.path.join(desk, 'アポチェック.lnk')
        if not os.path.exists(lnk2):
            if _make_shortcut(lnk2, exe):
                made.append('デスクトップの「アポチェック」')
    elif IS_MAC and IS_FROZEN:
        if _mac_autostart(_exe_path()):
            made.append('自動起動の登録')
        link = os.path.join(desktop_dir(), 'アポチェック')
        if not os.path.exists(link):
            try:
                os.symlink(_mac_app_root(), link)
                made.append('デスクトップの「アポチェック」')
            except OSError:
                pass

    if made and not quiet:
        say('apomiの準備ができました。\n\n作成したもの:\n・' + '\n・'.join(made)
            + f'\n\n設定の保存先:\n{home}')
    return made


def start_watcher():
    """見張り役をこの場で動かし始める（次回起動を待たなくてよいように）。
    すでに動いている場合は、向こう側の二重起動防止で自動的に終了する。"""
    if not IS_FROZEN:
        return
    try:
        flags = 0
        if IS_WIN:
            flags = 0x00000008 | 0x08000000   # DETACHED_PROCESS | CREATE_NO_WINDOW
        subprocess.Popen([sys.executable, '--watch'], creationflags=flags) if IS_WIN \
            else subprocess.Popen([sys.executable, '--watch'])
    except Exception:
        pass


def ask_license_code():
    """ライセンスコードの入力ダイアログ。キャンセルなら None。

    パソコンが得意でない方向けに、右クリック貼り付け・貼り付けボタンを備えた
    自作ダイアログにしてある（標準の simpledialog は右クリックが効かない）。"""
    try:
        import tkinter as tk
        import apomi_license as lic
        result = {'code': None, 'action': None}
        root = tk.Tk()
        root.title('apomi ライセンス')
        root.configure(bg='#eefaf6')
        root.attributes('-topmost', True)
        root.resizable(False, False)

        tk.Label(root, text='ライセンスコードを入力してください',
                 bg='#eefaf6', fg='#1f7d5e',
                 font=('Meiryo UI', 12, 'bold')).pack(padx=26, pady=(18, 2))
        tk.Label(root, text='お手元のご案内にある APOMI-〜 のコードです。\n'
                            '小文字やハイフン抜けは自動で直るので大丈夫です。',
                 bg='#eefaf6', fg='#5c7a70', justify='center',
                 font=('Meiryo UI', 9)).pack(padx=26)

        ent = tk.Entry(root, font=('Consolas', 14), width=28, justify='center')
        ent.pack(padx=26, pady=10, ipady=5)
        ent.focus_set()

        def paste(_=None):
            try:
                s = root.clipboard_get()
            except Exception:
                return
            ent.delete(0, 'end')
            ent.insert(0, s.strip())

        menu = tk.Menu(root, tearoff=0)
        menu.add_command(label='貼り付け', command=paste)
        menu.add_command(label='全部消す', command=lambda: ent.delete(0, 'end'))
        # 右クリックでメニュー（Macでは右クリックが Button-2 に届く）
        ent.bind('<Button-3>', lambda e: menu.tk_popup(e.x_root, e.y_root))
        ent.bind('<Button-2>', lambda e: menu.tk_popup(e.x_root, e.y_root))
        if IS_MAC:
            ent.bind('<Control-Button-1>', lambda e: menu.tk_popup(e.x_root, e.y_root))

        def ok(_=None):
            v = ent.get().strip()
            if v:
                result['code'] = v
            root.destroy()

        row = tk.Frame(root, bg='#eefaf6')
        row.pack(pady=(2, 6))
        tk.Button(row, text='📋 貼り付け', command=paste,
                  font=('Meiryo UI', 10), bg='white', fg='#1f7d5e',
                  width=11).pack(side='left', padx=4)
        tk.Button(row, text='登録する', command=ok,
                  font=('Meiryo UI', 10, 'bold'), bg='#2fa27a', fg='white',
                  width=11).pack(side='left', padx=4)
        tk.Button(row, text='キャンセル', command=root.destroy,
                  font=('Meiryo UI', 10), bg='white', fg='#5c7a70',
                  width=9).pack(side='left', padx=4)
        ent.bind('<Return>', ok)

        # おためし中でセルフ延長が未使用なら、コードが無くても進める道を用意する
        if lic.can_extend_trial():
            def extend():
                result['action'] = 'extend'
                root.destroy()
            tk.Button(root, text=f'🎁 おためしを{lic.EXTEND_DAYS}日延長する（1回だけ・コード不要）',
                      command=extend, font=('Meiryo UI', 10, 'bold'),
                      bg='#fff6e6', fg='#b5761f').pack(pady=(4, 16))
        else:
            tk.Frame(root, bg='#eefaf6', height=12).pack()

        root.eval('tk::PlaceWindow . center')
        root.mainloop()
        return result
    except Exception:
        return {'code': None, 'action': None}


def license_check_interactive():
    """停止中なら、その場でコード入力を促す。続行してよければ True"""
    try:
        import apomi_license as lic
        s = lic.status()
    except Exception:
        return True
    if s['state'] != 'stopped':
        return True
    res = ask_license_code()
    if res.get('action') == 'extend':
        ok, msg = lic.extend_trial()
        say(msg, kind='info' if ok else 'error')
        if ok and lic.status()['state'] != 'stopped':
            return True
    elif res.get('code'):
        ok, msg = lic.register_code(res['code'])
        say(msg, kind='info' if ok else 'error')
        if ok and lic.status()['state'] != 'stopped':
            return True
    import watch_patrol as w
    w.license_gate(force_notice=True)   # 案内ページを開く
    return False


def run_check():
    """取り込みフォルダの最新ファイルをチェックする"""
    import watch_patrol as w
    if not license_check_interactive():
        return
    w.ensure_inbox()
    if w.maybe_apply_config_drop():   # 設定ファイルが入っていたら先に適用
        return
    if w.maybe_apply_shift_drop() or w.maybe_apply_offmemo_drop():
        return                        # シフト表・臨時休メモの登録だけで完結
    files = (glob.glob(os.path.join(w.INBOX, '*.csv'))
             + glob.glob(os.path.join(w.INBOX, '*.xls'))
             + glob.glob(os.path.join(w.INBOX, '*.xlsx'))
             + glob.glob(os.path.join(w.INBOX, '*.pdf')))
    files = [f for f in files if not w._is_special_name(os.path.basename(f))]
    if not files:
        say('取り込みフォルダに予約一覧がありません。\n\n'
            '予約システムから書き出したCSVまたはPDFを、\n'
            f'次のフォルダに入れてください:\n{w.INBOX}\n\n'
            '（フォルダを開きます）')
        open_path(w.INBOX)
        return
    newest = max(files, key=os.path.getmtime)
    w.process(newest)     # チェック→レポートをブラウザで表示→済みへ移動


def main():
    args = [a.lower() for a in sys.argv[1:]]
    try:
        if '--watch' in args:
            setup(quiet=True)
            import watch_patrol
            watch_patrol.main()
            return 0
        if '--setup' in args:
            setup()
            return 0
        if '--license' in args:
            import apomi_license as lic
            res = ask_license_code()
            if res.get('action') == 'extend':
                ok, msg = lic.extend_trial()
                say(msg, kind='info' if ok else 'error')
            elif res.get('code'):
                ok, msg = lic.register_code(res['code'])
                say(msg, kind='info' if ok else 'error')
            return 0

        made = setup(quiet=True)
        if made:
            # ここが初回。見張り役を動かし始めて、「ようこそ」画面を開く
            import watch_patrol as w
            start_watcher()
            welcome = os.path.join(data_dir(), 'ようこそ.html')
            if os.path.exists(welcome):
                open_path(welcome)          # アポミちゃん入りの案内をブラウザで
            else:
                say('apomiの準備ができました！\n\n'
                    '作成したもの:\n・' + '\n・'.join(made) + '\n\n'
                    '予約一覧（CSVまたはPDF）を、デスクトップの\n'
                    '「apomi_取込」フォルダに入れてください。\n'
                    '数秒後に自動でチェックし、結果がブラウザで開きます。')
            return 0

        run_check()
        return 0
    except Exception:
        say('エラーが発生しました。\n\n' + traceback.format_exc()[-1500:],
            title='apomi エラー', kind='error')
        return 1


if __name__ == '__main__':
    sys.exit(main())
