# -*- coding: utf-8 -*-
"""非常用の予約表（控え）。

予約ソフトが開かない朝（ネット障害・システム障害・停電あけ）に、
「最後にアポチェックしたとき」の予約を紙に出して応急処置できるようにする。

- チェックのたびに、読み込んだ予約を医院のパソコンの中に保存する（日付ごとに最新で上書き）
- 同時に、日ごと・チェアごとの印刷向けの表（非常用予約表.html）を作り直す
- 保存先は医院のPCの中だけ。どこにも送らない（利用規約・プライバシーポリシーの記載どおり）

控えは「日付ごと」に持つ。今日のチェックが1週間先までなら、その1週間ぶんだけを新しい内容に
差し替え、それより先の日付は前回（週初め・月初のチェック）の内容をそのまま残す。
だから毎日1週間しか読まない医院でも、月初に読んだ4か月ぶんが控えとして残り続ける。
Genifixから直接読む医院（当院）は毎日4か月先まで読むので、控えは常に新しい。

限界（表の一番上にも大きく書く）:
  入っているのは「その日付を最後に読んだ時点」の予約だけ。以後の変更は反映されない。
  予約ソフトのバックアップの代わりにはならない。
"""
import os, re, json, html, datetime

from apomi_paths import data_dir
from apomi_settings import S as SETTINGS

SNAPSHOT_FILE = 'apomi_非常用控え.json'
SHEET_FILE = '非常用予約表.html'
WEEKDAYS = ['月', '火', '水', '木', '金', '土', '日']
# 控えに残す項目（これ以外は持たない。紙の予約表に要るものだけ）
KEEP = ['予約日', '開始', '終了', '患者No', '氏名', 'スタッフ', 'チェア', '処置名', '主訴']
# 表に最初から出す日数（印刷しすぎを防ぐ。ボタンで1か月・すべてに広げられる）
DEFAULT_SHOW_DAYS = 7
# テストから置き場を差し替えるための穴。None なら本番の data_dir()。
# （拷問テストが watch_patrol.process を通すと本物の控えを試験データで上書きしてしまう。2026-09-28 に実際に起きた）
DATA_DIR = None


def _dir():
    return DATA_DIR or data_dir()


def snapshot_path():
    return os.path.join(_dir(), SNAPSHOT_FILE)


def sheet_path():
    return os.path.join(_dir(), SHEET_FILE)


def _ymd(datestr):
    """令和8.07.04 → (2026, 7, 4)。読めなければ None"""
    m = re.search(r'令和(\d+)\.(\d+)\.(\d+)', datestr or '')
    if not m:
        return None
    try:
        y, mo, d = 2018 + int(m.group(1)), int(m.group(2)), int(m.group(3))
        datetime.date(y, mo, d)
    except ValueError:
        return None
    return (y, mo, d)


def _to_date(datestr):
    t = _ymd(datestr)
    return datetime.date(*t) if t else None


def to_reiwa(d):
    """date → 令和8.07.04"""
    return f'令和{d.year - 2018}.{d.month:02d}.{d.day:02d}'


def _to_min(hm):
    m = re.match(r'(\d{1,2}):(\d{2})', hm or '')
    return int(m.group(1)) * 60 + int(m.group(2)) if m else None


def _esc(s):
    return html.escape(str(s if s is not None else ''))


# ===== 保存 =====

def _empty():
    return {'version': 2, 'saved_at': '', 'days': {}}


def load_snapshot():
    """控えを読む。無い・壊れているときは None。旧形式（全体で1つ）は日付ごとの形式に直す"""
    try:
        with open(snapshot_path(), encoding='utf-8') as f:
            snap = json.load(f)
    except Exception:
        return None
    if not isinstance(snap, dict):
        return None
    if 'days' not in snap and isinstance(snap.get('records'), list):
        days = {}
        for r in snap['records']:
            days.setdefault(r.get('予約日', ''), {'saved_at': snap.get('saved_at', ''),
                                                  'src': snap.get('src', ''), 'records': []})['records'].append(r)
        snap = {'version': 2, 'saved_at': snap.get('saved_at', ''), 'days': days}
    if not isinstance(snap.get('days'), dict):
        return None
    return snap


def count_records(snap):
    return sum(len(v.get('records', [])) for v in (snap or {}).get('days', {}).values())


def save_snapshot(recs, src='', start=None, end=None, today=None):
    """読み込んだ予約を控えに足し（読んだ範囲の日付は差し替え）、印刷向けの表を作り直す。

    start/end: 読んだ範囲（date）。省略時は予約の最小日〜最大日。範囲内で予約が0件の日は消える
    （＝その日は空、が正しい）。範囲外の日付は前回の控えをそのまま残す。
    失敗しても本体（アポチェック）は止めない。戻り値は表のパス（失敗時は '')"""
    try:
        today = today or datetime.date.today()
        rows = []
        for r in recs:
            if not _to_date(r.get('予約日', '')):
                continue
            rows.append({k: str(r.get(k, '') or '') for k in KEEP})
        if not rows and (start is None or end is None):
            # 1件も読めず範囲も分からないチェックで、前回の良い控えを消さない
            return sheet_path() if os.path.exists(sheet_path()) else ''
        dates = [_to_date(r['予約日']) for r in rows]
        start = start or min(dates)
        end = end or max(dates)
        if end < start:
            start, end = end, start

        snap = load_snapshot() or _empty()
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
        # 読んだ範囲の日付は前回分を捨てて差し替える
        for key in list(snap['days']):
            d = _to_date(key)
            if d is None or start <= d <= end or d < today:
                del snap['days'][key]      # 過ぎた日も捨てる（非常用に要るのは今日以降だけ）
        for r in rows:
            d = _to_date(r['予約日'])
            if d < today or not (start <= d <= end):
                continue
            snap['days'].setdefault(r['予約日'], {'saved_at': now, 'src': src, 'records': []})['records'].append(r)
        for v in snap['days'].values():
            v['records'].sort(key=lambda r: (_to_min(r['開始']) or 0, r['チェア']))
        snap['saved_at'] = now
        snap['version'] = 2

        tmp = snapshot_path() + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(snap, f, ensure_ascii=False)
        os.replace(tmp, snapshot_path())       # 書きかけの控えを残さない
        return build_sheet(snap)
    except Exception:
        return ''


# ===== 表を描く =====

def _day_label(datestr):
    y, m, d = _ymd(datestr)
    wd = WEEKDAYS[datetime.date(y, m, d).weekday()]
    return f'{y}年{m}月{d}日（{wd}）'


def _stamp_short(saved_at):
    """2026-10-01 07:12 → 10/01 07:12"""
    m = re.match(r'\d{4}-(\d{2})-(\d{2}) (\d{2}:\d{2})', saved_at or '')
    return f'{int(m.group(1))}/{m.group(2)} {m.group(3)}' if m else (saved_at or '')


def _columns(recs):
    """列の並び: 設定のチェア → カウンセリング室 → それ以外に出てきた名前"""
    cols = list(getattr(SETTINGS, 'treatment_chairs', []) or [])
    for c in getattr(SETTINGS, 'counseling_rooms', []) or []:
        if c not in cols:
            cols.append(c)
    for r in recs:
        c = r.get('チェア', '') or '（チェアなし）'
        if c not in cols:
            cols.append(c)
    return cols


def _day_table(datestr, day, cols, slot):
    """1日ぶんの表。行=時刻（slot分きざみ）、列=チェア。予約は縦につなげる"""
    recs = day.get('records', [])
    open_hours = getattr(SETTINGS, 'open_hours', None) or [('09:00', '17:30')]
    t0 = min(_to_min(a) for a, _ in open_hours)
    t1 = max(_to_min(b) for _, b in open_hours)
    starts = [_to_min(r['開始']) for r in recs if _to_min(r['開始']) is not None]
    ends = [_to_min(r['終了']) for r in recs if _to_min(r['終了']) is not None]
    if starts:
        t0 = min(t0, min(starts))
    if ends:
        t1 = max(t1, min(24 * 60, max(ends)))
    t0 -= t0 % slot
    times = list(range(t0, t1, slot)) or [t0]

    # grid[col][time] = ('head', rowspan, html) / ('skip', head_time) / None
    grid = {c: {} for c in cols}
    for r in recs:
        c = r.get('チェア', '') or '（チェアなし）'
        s, e = _to_min(r['開始']), _to_min(r['終了'])
        if s is None:
            continue
        if e is None or e <= s:
            e = s + slot
        s -= s % slot
        n = max(1, (e - s + slot - 1) // slot)
        head = s
        cell = grid[c]
        # 2行に収める（1行目=番号と氏名、2行目=処置と担当）。縦向き印刷で1日1枚に入れるため
        line2 = ' '.join(x for x in (f'<span class="tx">{_esc(r["処置名"])}</span>' if r.get('処置名') else '',
                                     f'<span class="st">{_esc(r["スタッフ"])}</span>' if r.get('スタッフ') else '') if x)
        txt = f'<b>{_esc(r["患者No"])}</b> {_esc(r["氏名"])}' + (f'<br>{line2}' if line2 else '')
        if head in cell and cell[head][0] == 'head':
            # 同じ時刻に二重に入っている（重複予約）。消さずに同じマスへ併記する
            cell[head] = ('head', cell[head][1], cell[head][2] + f'<div class="dup">⚠ 重複: {txt}</div>')
            continue
        if head in cell and cell[head][0] == 'skip':
            # 前の予約の途中から始まる（重なり）。前の予約のマスへ併記する
            owner = cell[head][1]
            cell[owner] = ('head', cell[owner][1], cell[owner][2] + f'<div class="dup">⚠ 重なり {r["開始"]}〜: {txt}</div>')
            continue
        span = 0
        for k in range(n):
            t = head + k * slot
            if t in cell or t >= t1:
                break
            span += 1
        span = max(1, span)
        cell[head] = ('head', span, txt)
        for k in range(1, span):
            cell[head + k * slot] = ('skip', head)

    d = _to_date(datestr)
    out = [f'<section class="day" data-date="{d.isoformat()}">'
           f'<h2>{_esc(_day_label(datestr))}　<span class="cnt">予約 {len(recs)}件</span>'
           f'<span class="stamp">〔{_esc(_stamp_short(day.get("saved_at", "")))} 時点〕</span></h2>']
    out.append('<table><thead><tr><th class="time">時刻</th>')
    for c in cols:
        out.append(f'<th>{_esc(c)}</th>')
    out.append('</tr></thead><tbody>')
    for t in times:
        hh, mm = divmod(t, 60)
        out.append(f'<tr class="{"hour" if mm == 0 else ""}"><td class="time">{hh:02d}:{mm:02d}</td>')
        for c in cols:
            v = grid[c].get(t)
            if v is None:
                out.append('<td class="free"></td>')
            elif v[0] == 'head':
                out.append(f'<td class="apo" rowspan="{v[1]}">{v[2]}</td>')
            # skip は前のマスが縦に伸びているので何も出さない
        out.append('</tr>')
    out.append('</tbody></table></section>')
    return ''.join(out)


def render_sheet(snap, today=None):
    today = today or datetime.date.today()
    days = snap.get('days', {})
    keys = sorted((k for k in days if _to_date(k)), key=_to_date)
    all_recs = [r for k in keys for r in days[k].get('records', [])]
    cols = _columns(all_recs)
    slot = int(getattr(SETTINGS, 'slot_min', 15) or 15)
    days_html = ''.join(_day_table(k, days[k], cols, slot) for k in keys)
    if not keys:
        days_html = '<p class="none">控えに予約が入っていません。先にアポチェックを実行してください。</p>'
    stamps = sorted({days[k].get('saved_at', '') for k in keys})
    newest = _esc(snap.get('saved_at', '') or (stamps[-1] if stamps else ''))
    oldest = _esc(stamps[0] if stamps else '')
    period = f'{_esc(_day_label(keys[0]))} 〜 {_esc(_day_label(keys[-1]))}' if keys else '（なし）'
    mixed = ('<li>日付によって取り込んだ時点が違います（最も古いものは <b>' + oldest + '</b>）。'
             '各日の見出しに「〔○/○ ○:○ 時点〕」を出しているので、必ずそれを見てください。</li>') if len(stamps) > 1 else ''
    clinic = _esc(getattr(SETTINGS, 'clinic_name', ''))
    n_days = len(keys)
    return f'''<!DOCTYPE html>
<html lang="ja"><head><meta charset="utf-8">
<title>非常用予約表（{newest} 時点の控え）</title>
<style>
  body {{ font-family:'Segoe UI','Yu Gothic UI','Hiragino Sans',sans-serif; color:#222; margin:16px; }}
  .warn {{ border:3px solid #d32f2f; background:#fff3f3; border-radius:10px; padding:12px 16px; margin:0 0 12px; }}
  .warn .big {{ font-size:20px; font-weight:800; color:#b71c1c; }}
  .warn .age {{ font-size:15px; font-weight:700; color:#b71c1c; margin-top:4px; }}
  .warn ul {{ margin:6px 0 0; padding-left:20px; font-size:13px; line-height:1.6; }}
  .meta {{ font-size:12px; color:#555; margin-bottom:8px; }}
  .tools {{ margin:8px 0 6px; display:flex; gap:10px; flex-wrap:wrap; align-items:center; }}
  .tools button {{ font-size:15px; padding:8px 18px; border-radius:8px; border:1px solid #888; background:#fff; cursor:pointer; }}
  .tools button.on {{ background:#00695c; color:#fff; border-color:#00695c; }}
  .tools .hint {{ font-size:12px; color:#666; }}
  .tools .print {{ background:#fff8e1; border-color:#f9a825; font-weight:700; }}
  section.day {{ margin-top:6px; }}
  section.day.hide {{ display:none; }}
  h2 {{ font-size:17px; margin:14px 0 6px; padding:4px 8px; background:#eceff1; border-left:6px solid #00695c; }}
  h2 .cnt {{ font-size:13px; color:#555; font-weight:400; }}
  h2 .stamp {{ float:right; font-size:13px; color:#b71c1c; font-weight:700; }}
  table {{ border-collapse:collapse; width:100%; table-layout:fixed; font-size:11px; }}
  th, td {{ border:1px solid #999; vertical-align:top; padding:2px 3px; overflow-wrap:anywhere; }}
  td.apo b {{ white-space:nowrap; }}   /* 診察券番号を途中で折り返さない */
  th {{ background:#e0f2f1; font-size:12px; }}
  th.time, td.time {{ width:44px; text-align:center; color:#555; font-size:11px; background:#fafafa; }}
  tr.hour td {{ border-top:2px solid #444; }}
  td.free {{ background:#fff; height:14px; }}
  td.apo {{ background:#fffde7; }}
  td.apo b {{ font-size:12px; }}
  .tx {{ color:#00695c; }}
  .st {{ color:#666; }}
  .dup {{ margin-top:2px; padding:1px 3px; background:#ffcdd2; border-radius:3px; }}
  .none {{ font-size:15px; color:#b71c1c; }}
  footer {{ margin-top:14px; font-size:11px; color:#666; line-height:1.6; }}
  /* 縦向き: 文字を小さくして1日を1枚に収める */
  body.portrait table {{ font-size:8px; }}
  body.portrait th, body.portrait td {{ padding:1px 2px; line-height:1.15; }}
  body.portrait th {{ font-size:9px; }}
  body.portrait th.time, body.portrait td.time {{ width:30px; font-size:8px; }}
  body.portrait td.free {{ height:9px; }}
  body.portrait td.apo b {{ font-size:8.5px; }}
  body.portrait h2 {{ font-size:14px; margin:8px 0 4px; }}
  @page {{ size: A4 landscape; margin: 8mm; }}
  @media print {{
    body {{ margin:0; }}
    .tools {{ display:none; }}
    .warn {{ padding:6px 10px; margin-bottom:6px; }}
    .warn .big {{ font-size:15px; }}
    .warn .age {{ font-size:12px; }}
    .warn ul {{ font-size:10px; line-height:1.4; }}
    .meta {{ font-size:10px; }}
    section.day {{ break-before: page; }}
    section.day.first {{ break-before: auto; }}
    table {{ page-break-inside: auto; }}
    tr {{ page-break-inside: avoid; }}
    td.apo {{ -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
  }}
</style></head><body>
<div class="warn">
  <div class="big">⚠ これは予約の「控え」です（最新の取り込み: {newest}）</div>
  <div class="age" id="age"></div>
  <ul>
    <li>取り込んだ後に入った予約・変更・キャンセルは<b>入っていません</b>。予約ソフトが復旧したら、必ず予約ソフトの内容を正としてください。</li>
    <li>控えにある日付: <b>{period}</b>（{n_days}日分）。それより先の日付はありません。</li>{mixed}
    <li>空いているマスは「控えの時点で予約が無かった枠」です。紙の上で次回予約を取ったら、復旧後に予約ソフトへ入れ直してください。</li>
  </ul>
</div>
<div class="meta">{clinic} ｜ 列 {len(cols)}（設定のチェア＋カウンセリング室）｜ 予約 {count_records(snap)}件</div>
<div class="tools">
  <span class="hint">表示する日:</span>
  <button id="rng-1" onclick="setRange(1)">今日だけ</button>
  <button id="rng-7" onclick="setRange(7)">今日から1週間</button>
  <button id="rng-31" onclick="setRange(31)">今日から1か月</button>
  <button id="rng-0" onclick="setRange(0)">すべて（{n_days}日）</button>
  <span class="hint" id="shown"></span>
</div>
<div class="tools">
  <span class="hint">用紙の向き:</span>
  <button id="btn-l" onclick="setOrient('landscape')">横向き（読みやすい）</button>
  <button id="btn-p" onclick="setOrient('portrait')">縦向き（1日を1枚に）</button>
  <button class="print" onclick="window.print()">🖨 表示中の日を印刷（1日1ページ）</button>
  <span class="hint">向きは次回も覚えています</span>
</div>
{days_html}
<footer>apomi 非常用予約表 ｜ この控えは医院のパソコンの中だけに保存され、外部には送られません。<br>
控えの内容は確認を補助するための目安です。予約の最終確認は医院の責任で行ってください（利用規約 第7条）。</footer>
<script>
// 用紙の向き。@page は後から入れた <style> で上書きできる（Chrome/Edge/Safari で確認）
var pageStyle = document.createElement('style');
document.head.appendChild(pageStyle);
function setOrient(o) {{
  var portrait = (o === 'portrait');
  document.body.classList.toggle('portrait', portrait);
  pageStyle.textContent = '@page {{ size: A4 ' + (portrait ? 'portrait' : 'landscape') + '; margin: 6mm; }}';
  document.getElementById('btn-l').classList.toggle('on', !portrait);
  document.getElementById('btn-p').classList.toggle('on', portrait);
  try {{ localStorage.setItem('apomi_sheet_orient', o); }} catch (e) {{}}
}}
// 表示する日の範囲（今日から n 日。0=すべて）。印刷しすぎを防ぐため、開いたときは1週間だけ
function setRange(n) {{
  var today = new Date(); today.setHours(0,0,0,0);
  var last = new Date(today); last.setDate(last.getDate() + n - 1);
  var shown = 0, first = true;
  document.querySelectorAll('section.day').forEach(function(s) {{
    var d = new Date(s.getAttribute('data-date') + 'T00:00:00');
    var show = (n === 0) || (d >= today && d <= last) || (n !== 0 && d < today);
    s.classList.toggle('hide', !show);
    s.classList.toggle('first', show && first);
    if (show) {{ shown++; first = false; }}
  }});
  [1, 7, 31, 0].forEach(function(k) {{ document.getElementById('rng-' + k).classList.toggle('on', k === n); }});
  document.getElementById('shown').textContent = '＝ ' + shown + '日分を表示中（印刷も ' + shown + ' ページ）';
}}
(function(){{
  var o = 'landscape';
  try {{ o = localStorage.getItem('apomi_sheet_orient') || o; }} catch (e) {{}}
  setOrient(o);
  setRange({DEFAULT_SHOW_DAYS});
}})();
(function(){{
  var s = "{newest}".replace(' ', 'T');
  var t = Date.parse(s);
  if (isNaN(t)) return;
  var h = Math.floor((Date.now() - t) / 3600000);
  var txt = h < 1 ? '1時間以内' : (h < 48 ? h + '時間前' : Math.floor(h/24) + '日前');
  txt = '＝ 最新の取り込みは いまから ' + txt;
  if (h >= 48) txt += '（古いので、特に注意して使ってください）';
  document.getElementById('age').textContent = txt;
}})();
</script>
</body></html>'''


def build_sheet(snap=None):
    """控えから印刷向けの表を作り直す。戻り値はパス（失敗時は ''）"""
    try:
        snap = snap or load_snapshot()
        if not snap:
            return ''
        out = sheet_path()
        with open(out, 'w', encoding='utf-8-sig') as f:
            f.write(render_sheet(snap))
        return out
    except Exception:
        return ''


if __name__ == '__main__':
    # 手で開きたいとき: python apomi_backup.py
    p = build_sheet()
    if p:
        from apomi_paths import open_path
        open_path(p)
        print(f'非常用予約表を開きました: {p}')
    else:
        print('控えがまだありません。先にアポチェックを実行してください。')
