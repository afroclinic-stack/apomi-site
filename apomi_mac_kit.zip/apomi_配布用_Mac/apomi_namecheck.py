# -*- coding: utf-8 -*-
"""「似た名前の注意」を本体につなぐ係。

本体からはこの1つを呼ぶだけ:
    issues = apomi_namecheck.run(recs, source='file' | 'genifix')

やること:
  1. 設定（医院設定の similar_names）がオフなら何もしない
  2. アポ表（recs）を、照合の部品（apomi_names）が読める形に直す
  3. 照らし合わせる相手を用意する
       - どの医院も: 同じ日のアポ表の中
       - 予約ソフトに直接つないでいる医院（Genifix）: その日の患者さんのよみ・生年月日と、
         登録のある患者さんのうち同じよみの人。毎回その場で読み、**どこにも保存しない**
  4. 部品が返した注意を、ほかのチェックと同じ形（重要度, 分類, 文）にして返す

患者さんの情報はこの関数の中（メモリの上）だけで使い、ファイルには書かない。
うまくいかなくても本体（アポチェック）は止めない。
"""
import datetime
import re

from apomi_settings import S as SETTINGS
import apomi_names

LAST_NOTE = ''      # 直近の実行のひとことメモ（結果ページの参考情報・ログ用）


def _to_date(reiwa):
    m = re.search(r'令和(\d+)\.(\d+)\.(\d+)', reiwa or '')
    try:
        return datetime.date(2018 + int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None
    except ValueError:
        return None


def enabled():
    try:
        return bool(getattr(SETTINGS, 'similar_names', {}).get('enabled'))
    except Exception:
        return False


def _appts(recs):
    out = []
    for r in recs or []:
        out.append({'date': r.get('予約日', ''), 'start': r.get('開始', ''), 'end': r.get('終了', ''),
                    'chair': r.get('チェア', ''), 'no': r.get('患者No', ''), 'name': r.get('氏名', ''),
                    'kana': r.get('カナ', ''), 'birth': r.get('生年月日', ''), 'age': r.get('年齢', '')})
    return out


def _genifix_info(appts, today):
    """Genifix から、よみ・生年月日と、登録にいる同じよみの患者さんを読む（保存しない）。
    戻り値: (よみ等を補ったappts, 登録の相手の一覧, ひとことメモ)"""
    import genifix_api
    dates = sorted({d for d in (_to_date(a['date']) for a in appts) if d and d >= today})
    if not dates:
        return appts, [], ''
    n_reg = int(getattr(SETTINGS, 'similar_names', {}).get('registered_days', 2) or 0)
    reg_dates = set(dates[:n_reg])
    info = genifix_api.fetch_patient_info([d.isoformat() for d in dates], [])
    by_no = {}
    for plist in info.get('datePatients', {}).values():
        for p in plist:
            if p.get('patientNo'):
                by_no[str(p['patientNo']).strip()] = p
    for a in appts:
        p = by_no.get(str(a['no']).strip())
        if p:
            a['kana'] = a['kana'] or (p.get('fname') or '')
            a['birth'] = a['birth'] or (p.get('birthOfDate') or '')
    # 登録の相手: 近い日（registered_days）の患者さんについて、同じよみ・同じ漢字の人を探す
    texts = set()
    for a in appts:
        d = _to_date(a['date'])
        if d in reg_dates:
            # よみで探せば「同じ漢字」「旧字体ちがい」「漢字ちがい」の全部が見つかる（1人1回で済む）。
            # よみが無い人だけ、漢字の氏名で探す
            y = apomi_names.key_yomi(a['kana'])
            texts.add(y or apomi_names.key_raw(a['name']))
    texts.discard('')
    regs = []
    if texts:
        found = genifix_api.fetch_patient_info([], sorted(texts)).get('searches', {})
        seen = set()
        for plist in found.values():
            for p in plist:
                no = str(p.get('patientNo') or '').strip()
                if no and no not in seen:
                    seen.add(no)
                    regs.append({'no': no, 'name': p.get('name') or '', 'kana': p.get('fname') or '',
                                 'birth': p.get('birthOfDate') or '', 'age': p.get('age') or ''})
    note = (f'似た名前: よみ・生年月日を{len(dates)}日分、登録との照合を{len(reg_dates)}日分'
            f'（検索{len(texts)}回・相手{len(regs)}人）。患者さんの一覧は保存していません')
    return appts, regs, note


def run(recs, source='file', today=None):
    """似た名前の注意を (重要度, 分類, 文) の一覧で返す。あわせて結果ページ用のカードを登録する。"""
    global LAST_NOTE
    LAST_NOTE = ''
    try:                                  # 前回のカードを残さない（見張り役は動き続けるため）
        import report_html
        report_html.EXTRA_CARD_HTML.clear()
        report_html.EXTRA_CSS = ''
    except Exception:
        pass
    if not enabled():
        return []
    try:
        today = today or datetime.date.today()
        appts = _appts(recs)
        regs = []
        if source == 'genifix':
            try:
                appts, regs, LAST_NOTE = _genifix_info(appts, today)
            except Exception as e:      # つながらない日は、同じ日のアポ表の中だけで続ける
                LAST_NOTE = f'似た名前: 登録との照合はお休み（{type(e).__name__}）。同じ日のアポ表の中だけ見ました'
                regs = []
        # 登録との照合は「近い日」だけ（遠い日まで出すと多すぎて見られなくなる）
        n_reg = int(getattr(SETTINGS, 'similar_names', {}).get('registered_days', 2) or 0)
        dates = sorted({d for d in (_to_date(a['date']) for a in appts) if d and d >= today})
        reg_dates = set(dates[:n_reg])
        alerts = apomi_names.find_similar(appts, regs)
        alerts = [al for al in alerts
                  if al['kind'] == 'same_day' or _to_date(al['date']) in reg_dates]
        issues, cards = apomi_names.to_issues(alerts)
        try:
            import report_html
            if cards:
                report_html.EXTRA_CARD_HTML.update(cards)
                report_html.EXTRA_CSS = apomi_names.CARD_CSS
        except Exception:
            pass
        return issues
    except Exception:
        return []
