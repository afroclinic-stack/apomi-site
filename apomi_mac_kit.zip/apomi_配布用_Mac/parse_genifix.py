# -*- coding: utf-8 -*-
"""Genifix「予約一覧」印刷PDFをパースして予約レコードに変換する"""
import sys, json, re
import pdfplumber

# 列の右端x座標（ヘッダー解析から決定）
COLUMNS = [
    ('予約日',      60),
    ('予約時間',   116),
    ('区分',       140),
    ('患者No',     179),
    ('氏名',       206.5),
    ('かな氏名',   234.5),
    ('性別',       258),
    ('年齢',       285),
    ('メール',     338),
    ('電話番号',   371.5),
    ('スタッフ',   400),
    ('チェア',     425),
    ('処置名',     455),
    ('主訴',       480),
    ('アポ指示日', 507),
    ('リコール月', 534),
    ('特記事項',   560),
    ('要注意',     9999),
]

def parse_pdf(path):
    records = []
    with pdfplumber.open(path) as pdf:
        for pageno, page in enumerate(pdf.pages, 1):
            hlines = sorted(set(round(l['top'], 1) for l in page.lines
                                if abs(l['top'] - l['bottom']) < 0.5))
            if len(hlines) < 2:
                continue
            chars = page.chars
            # 各ページの行帯 = 罫線と罫線の間。ただしページ最終行は下の区切り線が
            # 次ページに落ちて印字されないことがあるため、最後の罫線からページ番号
            # フッターの手前までも1行として読む
            bands = [(hlines[i], hlines[i + 1]) for i in range(1, len(hlines) - 1)]
            bands.append((hlines[-1], page.height - 55))
            for top, bottom in bands:
                band = [c for c in chars if top <= (c['top'] + c['bottom']) / 2 <= bottom]
                if not band:
                    continue
                rec = {}
                for name, _ in COLUMNS:
                    rec[name] = []
                # 半角文字（数字・英字・半角カナ）は連続するかたまり単位で列を判定する。
                # セル幅より長い半角文字列が隣の列にはみ出して印字されるため。
                def is_half(ch):
                    o = ord(ch)
                    return o < 0x2E80 or 0xFF61 <= o <= 0xFF9F
                band.sort(key=lambda c: (round(c['top'], 0), c['x0']))
                clusters = []
                for c in band:
                    if (clusters and is_half(c['text']) and clusters[-1]['half']
                            and round(c['top'], 0) == clusters[-1]['top']
                            and c['x0'] - clusters[-1]['x1'] < 2.5):
                        clusters[-1]['chars'].append(c)
                        clusters[-1]['x1'] = c['x1']
                    else:
                        clusters.append({'chars': [c], 'half': is_half(c['text']),
                                         'top': round(c['top'], 0),
                                         'x0': c['x0'], 'x1': c['x1']})
                for cl in clusters:
                    cx = (cl['x0'] + cl['x1']) / 2
                    for name, right in COLUMNS:
                        if cx <= right:
                            rec[name].extend(cl['chars'])
                            break
                row = {}
                for name, _ in COLUMNS:
                    cs = sorted(rec[name], key=lambda c: (round(c['top'], 0), c['x0']))
                    row[name] = ''.join(c['text'] for c in cs).strip()
                if re.search(r'\d{1,2}:\d{2}～\d{1,2}:\d{2}', row['予約時間']):
                    row['page'] = pageno
                    records.append(row)
    return records

def clean(records):
    out = []
    last_date = ''
    for r in records:
        m = re.search(r'(\d{1,2}:\d{2})～(\d{1,2}:\d{2})', r['予約時間'])
        # 予約日 例: "令和8.07.04"（同一日は先頭行のみ印字されるため前方補完）
        d = re.sub(r'\s', '', r['予約日'])
        if d:
            last_date = d
        else:
            d = last_date
        # 患者No.の末尾桁が氏名列にはみ出すことがある → 氏名中のASCII数字を患者Noへ戻す
        name = r['氏名']
        stray = ''.join(ch for ch in name if ch.isascii() and ch.isdigit())
        name = ''.join(ch for ch in name if not (ch.isascii() and ch.isdigit())).strip()
        pno = (r['患者No'] + stray).strip()
        # チェア名の半角カナを正規化
        chair = r['チェア']
        cm = re.search(r'ｶ?ｳﾝｾﾘﾝｸﾞ?(\d)', chair)
        if cm:
            chair = 'カウンセリング' + cm.group(1)
        r = dict(r, 氏名=name, 患者No=pno, チェア=chair)
        out.append({
            '予約日': d,
            '開始': m.group(1), '終了': m.group(2),
            '区分': r['区分'],
            '患者No': r['患者No'],
            '氏名': r['氏名'],
            '性別': r['性別'], '年齢': r['年齢'],
            'スタッフ': r['スタッフ'],
            'チェア': r['チェア'],
            '処置名': r['処置名'],
            '主訴': r['主訴'],
            '特記事項': r['特記事項'],
            '要注意': r['要注意'],
        })
    # 安全網: 同じ日付の中で時刻が大きく巻き戻っていたら、日付の読み取り漏れの
    # 可能性が高い（別の日が合算されている）ので印を付ける
    def mins(hm):
        h, mm = hm.split(':')
        return int(h) * 60 + int(mm)
    for i in range(1, len(out)):
        a, b = out[i - 1], out[i]
        if a['予約日'] == b['予約日'] and mins(b['開始']) < mins(a['開始']) - 120:
            b['日付要確認'] = True
    return out

if __name__ == '__main__':
    recs = clean(parse_pdf(sys.argv[1]))
    print('total:', len(recs))
    chairs = sorted(set(r['チェア'] for r in recs))
    print('チェア一覧:', chairs)
    print(json.dumps(recs[:8], ensure_ascii=False, indent=1))
    if len(sys.argv) > 2:
        with open(sys.argv[2], 'w', encoding='utf-8') as f:
            json.dump(recs, f, ensure_ascii=False, indent=1)
