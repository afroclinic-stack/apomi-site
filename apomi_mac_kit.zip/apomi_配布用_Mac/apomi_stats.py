# -*- coding: utf-8 -*-
"""月ごとの集計（エラー・警告・注意の件数、埋まり率、空き時間、売れ残り金額、飛び地）。

ルール（院長と決めたもの・2026-09-28）:
  - 数える月は「予約日」の月（チェックした日ではない）
  - 同じ問題は何度チェックに出ても1件（同一の判定＝予約日＋分類＋本文）。
    直して消えた問題も「その月に起きた問題」として残る。予約を動かして本文が変わると別の1件になる（許容）
  - 空き枠（埋まり率・空き時間・飛び地）は、日付ごとに「その日を最後にチェックしたときの値」を採用する。
    毎日1週間先を見ているので、実質「前日朝の状態」が確定値になる
  - 売れ残り金額＝空き時間 × 単価（医院設定.json の unit_price_per_hour。無ければ集計ページで入力）
  - 記録は医院のパソコンの中だけ（apomi_月次集計.json）。患者名は持たない（本文は持つので院外に出さない）
"""
import os, re, json, html, datetime, csv, io

from apomi_paths import data_dir
from apomi_settings import S as SETTINGS

STATS_FILE = 'apomi_月次集計.json'
PAGE_FILE = 'apomi月次集計.html'
CSV_FILE = 'apomi月次集計.csv'
LEVELS = ['エラー', '警告', '注意']
RANK = {'エラー': 0, '警告': 1, '注意': 2}
KEEP_MONTHS = 25          # これより古い月は捨てる（ファイルが育ち続けないように）
DATA_DIR = None           # テストから置き場を差し替える穴（本物の集計を試験データで汚さない）


def _dir():
    return DATA_DIR or data_dir()


def stats_path():
    return os.path.join(_dir(), STATS_FILE)


def page_path():
    return os.path.join(_dir(), PAGE_FILE)


def csv_path():
    return os.path.join(_dir(), CSV_FILE)


def _to_date(s):
    m = re.search(r'令和(\d+)\.(\d+)\.(\d+)', s or '')
    if not m:
        return None
    try:
        return datetime.date(2018 + int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def _esc(s):
    return html.escape(str(s if s is not None else ''))


def unit_price():
    """医院設定の単価（円/時間）。未設定・不正なら 0"""
    try:
        v = (getattr(SETTINGS, 'raw', {}) or {}).get('unit_price_per_hour', 0)
        v = int(float(str(v).replace(',', '')))
        return v if v > 0 else 0
    except (TypeError, ValueError):
        return 0


# ===== 記録 =====

def load():
    try:
        with open(stats_path(), encoding='utf-8') as f:
            d = json.load(f)
        if isinstance(d, dict) and isinstance(d.get('issues'), dict) and isinstance(d.get('days'), dict):
            return d
    except Exception:
        pass
    return None


def _gap_by_date(infos):
    """infos の「飛び地の空き枠（…計N分）」から {令和日付: (分, 枠数)}"""
    out = {}
    for title, lines in infos or []:
        m = re.match(r'\s*(令和\d+\.\d+\.\d+)\s*飛び地の空き枠.*?計(\d+)分', title or '')
        if m:
            out[m.group(1)] = (int(m.group(2)), len(lines or []))
    return out


def record(issues, infos, stats, src='', today=None):
    """1回のチェック結果を集計に足し、集計ページを作り直す。失敗しても本体は止めない。
    戻り値は集計ページのパス（失敗時は ''）"""
    try:
        today = today or datetime.date.today()
        data = load() or {'version': 1, 'issues': {}, 'days': {}}
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')

        for lv, cat, msg in issues or []:
            m = re.match(r'\s*(令和\d+\.\d+\.\d+)\s*(.*)', msg or '', re.S)
            if not m or not _to_date(m.group(1)) or lv not in RANK:
                continue            # 予約日の分からない問題は月に振り分けられないので数えない
            date = m.group(1)
            body = re.sub(r'\s+', ' ', m.group(2)).strip()
            key = f'{date}|{cat}|{body}'
            cur = data['issues'].get(key)
            if cur is None:
                data['issues'][key] = {'date': date, 'level': lv, 'cat': cat, 'first': now, 'src': src}
            elif RANK[lv] < RANK.get(cur.get('level'), 9):
                cur['level'] = lv       # 同じ問題が重くなったら重いほうで数える

        gaps = _gap_by_date(infos)
        slot = int(getattr(SETTINGS, 'slot_min', 15) or 15)
        for date, slots in (stats or {}).items():
            if not _to_date(date):
                continue
            cap = sum(s.get('cap', 0) for s in slots if not s.get('lunch'))
            book = sum(min(s.get('book', 0), s.get('cap', 0)) for s in slots if not s.get('lunch'))
            g = gaps.get(date, (0, 0))
            # その日を最後にチェックしたときの値で上書き（後のチェックほど実際に近い）
            data['days'][date] = {'saved_at': now, 'src': src, 'cap_min': cap * slot,
                                  'book_min': book * slot, 'gap_min': g[0], 'gap_n': g[1]}

        # 古い月を捨てる
        limit = datetime.date(today.year - (KEEP_MONTHS // 12), today.month, 1)
        for k in [k for k, v in data['issues'].items() if (_to_date(v.get('date')) or today) < limit]:
            del data['issues'][k]
        for k in [k for k in data['days'] if (_to_date(k) or today) < limit]:
            del data['days'][k]

        data['saved_at'] = now
        tmp = stats_path() + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, stats_path())
        return build_page(data, today)
    except Exception:
        return ''


# ===== 集計 =====

def summarize(data, today=None):
    """{'2026-09': {...}} を月の新しい順で返す"""
    today = today or datetime.date.today()
    months = {}

    def mon(d):
        ym = f'{d.year}-{d.month:02d}'
        if ym not in months:
            months[ym] = {'ym': ym, 'year': d.year, 'month': d.month,
                          'count': {lv: 0 for lv in LEVELS}, 'cats': {},
                          'days': 0, 'cap_min': 0, 'book_min': 0, 'gap_min': 0, 'gap_n': 0,
                          'last_day': d, 'late': 0}
        return months[ym]

    for it in (data or {}).get('issues', {}).values():
        d = _to_date(it.get('date'))
        if not d:
            continue
        m = mon(d)
        lv = it.get('level')
        if lv in m['count']:
            m['count'][lv] += 1
            m['cats'].setdefault((lv, it.get('cat', '')), 0)
            m['cats'][(lv, it.get('cat', ''))] += 1
    for date, v in (data or {}).get('days', {}).items():
        d = _to_date(date)
        if not d:
            continue
        m = mon(d)
        m['days'] += 1
        for k in ('cap_min', 'book_min', 'gap_min', 'gap_n'):
            m[k] += int(v.get(k, 0) or 0)
        if str(v.get('src', '')).startswith('後から'):
            m['late'] += 1
    for m in months.values():
        y, mo = m['year'], m['month']
        last = datetime.date(y + (mo == 12), mo % 12 + 1, 1) - datetime.timedelta(days=1)
        m['final'] = last < today
        m['empty_min'] = max(0, m['cap_min'] - m['book_min'])
        m['fill'] = (100.0 * m['book_min'] / m['cap_min']) if m['cap_min'] else None
    return [months[k] for k in sorted(months, reverse=True)]


def _hm(minutes):
    h, mi = divmod(int(minutes), 60)
    return f'{h}時間{mi:02d}分' if h else f'{mi}分'


def build_csv(rows, price):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(['月', '状態', '集計した診療日', 'エラー', '警告', '注意', '埋まり率(%)',
                '空き時間(分)', '売れ残り金額(円)', '飛び地(分)', '飛び地(枠)'])
    for m in rows:
        w.writerow([m['ym'], '確定' if m['final'] else '途中', m['days'],
                    m['count']['エラー'], m['count']['警告'], m['count']['注意'],
                    f'{m["fill"]:.1f}' if m['fill'] is not None else '',
                    m['empty_min'], int(m['empty_min'] / 60 * price + 0.5) if price else '',
                    m['gap_min'], m['gap_n']])
    return buf.getvalue()


def render_page(data, today=None):
    today = today or datetime.date.today()
    rows = summarize(data, today)
    price = unit_price()
    trs = []
    details = []
    for m in rows:
        fill = f'{m["fill"]:.1f}%' if m['fill'] is not None else '—'
        amount = (f'約{int(m["empty_min"] / 60 * price + 0.5):,}円' if price else '—')
        state = '確定' if m['final'] else '途中経過'
        late = ' <span class="late" title="この月は、あとからまとめて計算した日を含みます。当日より前に直された問題は数えていません">後から計算を含む</span>' if m['late'] else ''
        trs.append(
            f'<tr><th>{m["year"]}年{m["month"]}月</th><td class="st {"fin" if m["final"] else "mid"}">{state}{late}</td>'
            f'<td>{m["days"]}日</td>'
            f'<td class="n err">{m["count"]["エラー"]}</td><td class="n warn">{m["count"]["警告"]}</td>'
            f'<td class="n note">{m["count"]["注意"]}</td>'
            f'<td class="n">{fill}</td><td class="n">{_hm(m["empty_min"])}</td>'
            f'<td class="n amt" data-min="{m["empty_min"]}">{amount}</td>'
            f'<td class="n">{m["gap_min"]}分（{m["gap_n"]}枠）</td></tr>')
        if m['cats']:
            items = ''.join(f'<li><span class="lv lv{RANK.get(lv, 2)}">{_esc(lv)}</span> {_esc(cat)}: {n}件</li>'
                            for (lv, cat), n in sorted(m['cats'].items(), key=lambda x: (RANK.get(x[0][0], 9), -x[1])))
            details.append(f'<details><summary>{m["year"]}年{m["month"]}月の内訳</summary><ul>{items}</ul></details>')
    table = ''.join(trs) or '<tr><td colspan="10" class="none">まだ記録がありません。アポチェックを実行すると、ここに月ごとに積み上がります。</td></tr>'
    price_txt = str(price) if price else ''   # type=number はカンマ入りを受け付けない（空欄になる）
    clinic = _esc(getattr(SETTINGS, 'clinic_name', ''))
    return f'''<!DOCTYPE html>
<html lang="ja"><head><meta charset="utf-8"><title>apomi 月ごとの集計</title>
<style>
  body {{ font-family:'Segoe UI','Yu Gothic UI','Hiragino Sans',sans-serif; color:#263238; margin:20px; background:#f7fbfa; }}
  h1 {{ font-size:22px; color:#00695c; margin:0 0 6px; }}
  .sub {{ color:#607d8b; font-size:13px; margin-bottom:14px; }}
  table {{ border-collapse:collapse; width:100%; background:#fff; font-size:14px; }}
  th, td {{ border:1px solid #cfd8dc; padding:6px 8px; }}
  thead th {{ background:#e0f2f1; font-size:13px; }}
  tbody th {{ text-align:left; white-space:nowrap; }}
  td.n {{ text-align:right; white-space:nowrap; }}
  td.err {{ color:#c62828; font-weight:700; }} td.warn {{ color:#ef6c00; font-weight:700; }} td.note {{ color:#1565c0; }}
  td.st.fin {{ color:#2e7d32; }} td.st.mid {{ color:#8d6e63; }}
  .late {{ display:inline-block; font-size:11px; color:#6d4c41; background:#efebe9; border-radius:8px; padding:0 6px; margin-left:4px; }}
  .price {{ margin:14px 0; background:#fff; border:1px solid #cfd8dc; border-radius:10px; padding:10px 14px; font-size:14px; }}
  .price input {{ width:110px; font-size:15px; padding:3px 6px; }}
  .rules {{ margin-top:16px; background:#fff; border-radius:10px; padding:10px 16px; font-size:13px; line-height:1.7; color:#455a64; }}
  details {{ background:#fff; border:1px solid #e0e0e0; border-radius:8px; margin:6px 0; padding:4px 12px; font-size:13px; }}
  summary {{ cursor:pointer; font-weight:600; }}
  .lv {{ display:inline-block; min-width:34px; text-align:center; border-radius:6px; font-size:11px; color:#fff; padding:0 4px; }}
  .lv0 {{ background:#c62828; }} .lv1 {{ background:#ef6c00; }} .lv2 {{ background:#1565c0; }}
  .none {{ text-align:center; color:#90a4ae; padding:18px; }}
  footer {{ margin-top:16px; font-size:12px; color:#78909c; line-height:1.6; }}
  a.dl {{ display:inline-block; margin-top:8px; font-size:13px; color:#00695c; }}
</style></head><body>
<h1>📊 月ごとの集計</h1>
<div class="sub">{clinic} ｜ 予約枠は医院の在庫。売れ残りを金額で見る表です ｜ 最終更新 {_esc(data.get("saved_at", "") if data else "")}</div>
<div class="price">売れ残り金額の単価: <input type="number" id="price" min="0" step="10" value="{price_txt}" placeholder="例 15000"> 円／1時間
  <span style="color:#78909c;font-size:12px">（医院設定の単価が入っています。ここで変えると、このパソコンで表示するときだけ使います）</span></div>
<table><thead><tr><th>月</th><th>状態</th><th>集計した診療日</th><th>エラー</th><th>警告</th><th>注意</th>
<th>埋まり率</th><th>空き時間（売れ残り）</th><th>売れ残り金額</th><th>飛び地の空き</th></tr></thead>
<tbody>{table}</tbody></table>
<a class="dl" href="{CSV_FILE}">⬇ Excelで開ける形（{CSV_FILE}）</a>
{''.join(details)}
<div class="rules"><b>数え方</b><br>
・月は<b>予約日</b>の月です（チェックした日ではありません）。<br>
・同じ問題（予約日・分類・内容が同じもの）は、何回チェックに出ても<b>1件</b>です。直して消えた問題も、その月に起きた問題として数えます。予約を動かして内容が変わると、別の1件になります。<br>
・埋まり率・空き時間・飛び地は、日付ごとに<b>その日を最後にチェックしたときの値</b>です。昼休み帯は含みません。まだ終わっていない月は「途中経過」です。<br>
・売れ残り金額＝空き時間×単価の<b>概算</b>です。</div>
<footer>この集計は医院のパソコンの中だけに保存され、外部には送られません。<br>
apomiの件数・時間・金額は、取り込んだデータと設定から機械的に計算した目安です。経営上の判断は医院の責任で行ってください（利用規約 第7条）。</footer>
<script>
(function(){{
  var inp = document.getElementById('price');
  try {{ var s = localStorage.getItem('apomi_monthly_price'); if (s && !inp.value) inp.value = s; }} catch (e) {{}}
  function upd(){{
    var p = parseFloat(inp.value);
    document.querySelectorAll('td.amt').forEach(function(td){{
      var m = parseFloat(td.getAttribute('data-min'));
      td.textContent = (p > 0) ? ('約' + Math.round(m / 60 * p).toLocaleString() + '円') : '—';
    }});
    try {{ if (p > 0) localStorage.setItem('apomi_monthly_price', String(p)); }} catch (e) {{}}
  }}
  inp.addEventListener('input', upd);
  upd();
}})();
</script>
</body></html>'''


def build_page(data=None, today=None):
    try:
        data = data or load()
        if data is None:
            return ''
        rows = summarize(data, today)
        with open(page_path(), 'w', encoding='utf-8-sig') as f:
            f.write(render_page(data, today))
        with open(csv_path(), 'w', encoding='utf-8-sig', newline='') as f:
            f.write(build_csv(rows, unit_price()))
        return page_path()
    except Exception:
        return ''


if __name__ == '__main__':
    p = build_page()
    if p:
        from apomi_paths import open_path
        open_path(p)
        print(f'月ごとの集計を開きました: {p}')
    else:
        print('まだ記録がありません。先にアポチェックを実行してください。')
