# -*- coding: utf-8 -*-
"""apomi のライセンス（使用期限）管理。

設計（2026-08-03 決定仕様）:
- コード形式: APOMI-XXXX-XXXX-XXXX-XXXX（読み間違えにくい32文字アルファベット）
  中身 = 医院番号(16bit) + 期限日(16bit) + 電子署名(48bit)。ネット接続なしで検証できる。
- 期限を書き換えると署名が合わなくなり無効（改ざん対策）。
- 時計の巻き戻し対策: 最後に動いた日を記録し、日付は決して巻き戻らない扱いにする。
- はじめての起動から7日間は試用期間として動く（コード未登録でも使える）。
- 予告は、契約中=期限の14日前から／試用中=残り3日から、レポート上に表示。
  期限後7日間は猶予 → その後チェック停止。
- 停止しても設定・データは消えない。コード登録で即再開。
"""
import os
import json
import hmac
import hashlib
import datetime

from apomi_paths import data_dir

# ===== 基本設定 =====
EPOCH = datetime.date(2024, 1, 1)   # 日数の起点
TRIAL_DAYS = 7                       # 試用期間（2026-08-08 30日→7日に短縮）
EXTEND_DAYS = 7                      # セルフ延長の日数（お客様が自分で1回だけ押せる。事務対応ゼロ）
GRACE_DAYS = 7                       # 期限後の猶予
WARN_DAYS = 14                       # 契約中: この日数前から予告を出す
TRIAL_WARN_DAYS = 3                  # 試用中: 残りこの日数から予告（初日から急かさない）

# 発行側と検証側で共有する署名鍵（変更するとすべての既発行コードが無効になる）
_K1 = 'zK7mQ2vXeR9tYw4uPnB1'
_K2 = 'cJ6dHs8fLg3aZx5oWi0E'
SECRET = (_K1 + _K2).encode('utf-8')

# 読み間違えにくい32文字（Crockford Base32: I L O U を除外）
ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'
_REV = {c: i for i, c in enumerate(ALPHABET)}

LICENSE_FILE = '.apomi_license.json'


# ===== 符号化 =====

def _b32_encode(data: bytes) -> str:
    n = int.from_bytes(data, 'big')
    chars = []
    for _ in range(len(data) * 8 // 5):
        chars.append(ALPHABET[n & 31])
        n >>= 5
    return ''.join(reversed(chars))


def _b32_decode(s: str, nbytes: int) -> bytes:
    n = 0
    for c in s:
        n = (n << 5) | _REV[c]
    return n.to_bytes(nbytes, 'big')


def _mac(clinic_id: int, expiry_day: int) -> bytes:
    msg = b'APOMI1' + clinic_id.to_bytes(2, 'big') + expiry_day.to_bytes(2, 'big')
    return hmac.new(SECRET, msg, hashlib.sha256).digest()[:6]


def make_code(clinic_id: int, expiry: datetime.date) -> str:
    """発行側: 医院番号と期限からライセンスコードを作る"""
    if not (0 < clinic_id < 65536):
        raise ValueError('医院番号は1〜65535')
    day = (expiry - EPOCH).days
    if not (0 < day < 65536):
        raise ValueError('期限が範囲外です')
    payload = clinic_id.to_bytes(2, 'big') + day.to_bytes(2, 'big') + _mac(clinic_id, day)
    raw = _b32_encode(payload)          # 16文字
    return 'APOMI-' + '-'.join(raw[i:i + 4] for i in range(0, 16, 4))


def normalize(code: str) -> str:
    """入力ゆれを吸収（小文字・全角・ハイフン・紛らわしい文字）"""
    import unicodedata
    s = unicodedata.normalize('NFKC', code or '').upper()
    s = ''.join(c for c in s if c.isalnum())
    if s.startswith('APOMI'):
        s = s[5:]
    s = s.replace('O', '0').replace('I', '1').replace('L', '1').replace('U', 'V')
    return s


def parse_code(code: str):
    """検証側: コード → (医院番号, 期限日付)。無効なら None"""
    s = normalize(code)
    if len(s) != 16 or any(c not in _REV for c in s):
        return None
    payload = _b32_decode(s, 10)
    clinic_id = int.from_bytes(payload[0:2], 'big')
    day = int.from_bytes(payload[2:4], 'big')
    if not hmac.compare_digest(payload[4:10], _mac(clinic_id, day)):
        return None
    return clinic_id, EPOCH + datetime.timedelta(days=day)


# ===== 状態の保存 =====

def _int(v, default=0):
    """状態ファイルが手で書き換えられて型が壊れていても落ちないための変換"""
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def _path():
    return os.path.join(data_dir(), LICENSE_FILE)


def _load():
    try:
        with open(_path(), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save(st):
    try:
        with open(_path(), 'w', encoding='utf-8') as f:
            json.dump(st, f, ensure_ascii=False)
    except OSError:
        pass


def can_extend_trial() -> bool:
    """セルフ延長（1回だけ）がまだ使えるか。試用中で未使用のときだけ True"""
    st = _load()
    return not st.get('code') and not st.get('trial_extended')


def extend_trial():
    """試用期間をのばす（1回だけ）。押した日から必ず EXTEND_DAYS 日使えることを保証する。
    戻り値 (成功?, メッセージ)"""
    st = _load()
    if st.get('code'):
        return False, 'すでにライセンス登録済みのため、延長は不要です。'
    if st.get('trial_extended'):
        return False, ('おためしの延長は1回までです。\n'
                       'ご継続をご希望の場合は、お渡ししているご案内からお手続きください。')
    today = (datetime.date.today() - EPOCH).days
    eff = max(today, _int(st.get('last_seen_day')))
    base_end = _int(st.get('first_run_day'), eff) + TRIAL_DAYS
    st['trial_extended'] = True
    st['trial_expiry_day'] = max(base_end, eff) + EXTEND_DAYS
    _save(st)
    s = status()
    return True, (f'おためし期間を{EXTEND_DAYS}日のばしました！🎁\n'
                  f'新しい期限: {s["expiry"]:%Y年%m月%d日} まで\n'
                  'そのまま今までどおりお使いいただけます。')


def register_code(code: str):
    """コードを登録する。戻り値 (成功?, メッセージ)"""
    parsed = parse_code(code)
    if not parsed:
        return False, 'コードが正しくありません。打ち間違いがないかご確認ください。'
    clinic_id, expiry = parsed
    st = _load()
    if st.get('clinic_id') and st['clinic_id'] != clinic_id:
        return False, 'このコードは別の医院向けに発行されたものです。'
    st['clinic_id'] = clinic_id
    st['expiry_day'] = (expiry - EPOCH).days
    st['code'] = normalize(code)
    _save(st)
    return True, f'登録しました。使用期限: {expiry:%Y年%m月%d日} まで'


# ===== 状態判定 =====

def status(today: datetime.date = None):
    """現在の状態を返す。
    state: 'ok' | 'warn' | 'grace' | 'stopped'
    mode:  'trial'（試用中） | 'licensed'
    """
    st = _load()
    real_today = ((today or datetime.date.today()) - EPOCH).days
    eff = max(real_today, _int(st.get('last_seen_day')))   # 時計の巻き戻りは無視
    changed = (eff != st.get('last_seen_day')) or ('first_run_day' not in st)
    st['last_seen_day'] = eff
    st.setdefault('first_run_day', eff)
    if changed:
        _save(st)

    lic_day = _int(st.get('expiry_day'))
    if lic_day:
        mode, expiry_day = 'licensed', lic_day
    else:
        mode = 'trial'
        expiry_day = _int(st.get('trial_expiry_day')) or (
            _int(st.get('first_run_day'), eff) + TRIAL_DAYS)

    left = expiry_day - eff
    expiry = EPOCH + datetime.timedelta(days=expiry_day)
    warn_days = WARN_DAYS if mode == 'licensed' else TRIAL_WARN_DAYS
    if left > warn_days:
        state = 'ok'
    elif left >= 0:
        state = 'warn'
    elif left >= -GRACE_DAYS:
        state = 'grace'
    else:
        state = 'stopped'

    label = '試用期間' if mode == 'trial' else '使用期限'
    if state == 'warn':
        msg = f'{label}はあと{left}日（{expiry:%m月%d日}まで）です。'
    elif state == 'grace':
        msg = (f'{label}が切れています（{expiry:%m月%d日}まで）。'
               f'猶予はあと{GRACE_DAYS + left}日です。')
    elif state == 'stopped':
        msg = f'{label}が切れたため、チェック機能を停止しています。'
    else:
        msg = ''
    return {'mode': mode, 'state': state, 'days_left': left,
            'expiry': expiry, 'message': msg}


# ===== 表示部品 =====

def banner_html(s=None):
    """レポート先頭に差し込む予告バナー。ok のときは空文字"""
    s = s or status()
    if s['state'] == 'ok':
        return ''
    if s['state'] == 'warn':
        bg, bd, fg = '#fff6e6', '#e2953b', '#7a5416'
        head = '⏳ ' + ('お試し期間のお知らせ' if s['mode'] == 'trial' else '更新のお知らせ')
    else:
        bg, bd, fg = '#fdecec', '#d9534f', '#a02622'
        head = '⚠️ もうすぐ止まります'
    return (f'<div style="position:sticky;top:0;z-index:998;background:{bg};'
            f'border-bottom:2px solid {bd};padding:8px 14px;font-size:13.5px;'
            f'color:{fg};text-align:center;font-family:sans-serif">'
            f'<b>{head}</b>　{s["message"]}'
            '　ご継続のお手続きは、お渡ししているご案内からどうぞ。</div>')


def inject_banner(html, s=None):
    b = banner_html(s)
    if not b:
        return html
    import re
    return re.sub(r'(<body[^>]*>)', lambda m: m.group(1) + b, html, count=1)


def _extend_offer_html():
    """試用中でセルフ延長が未使用なら、その案内（最優先の次の一手）を返す"""
    if not can_extend_trial():
        return ''
    return ('<div class="how" style="border-color:#7cc6a6;background:#eefaf6">'
            f'<b>🎁 まずはこちら：おためしを{EXTEND_DAYS}日のばせます（1回だけ・連絡不要）</b><br>'
            '① デスクトップの「アポチェック」をダブルクリック<br>'
            f'② 出てきた画面の「<b>おためしを{EXTEND_DAYS}日延長する</b>」ボタンを押す → すぐ再開します</div>')


def notice_page_html(s=None):
    """停止中に表示する案内ページ"""
    s = s or status()
    label = '試用期間' if s['mode'] == 'trial' else '使用期限'
    return f'''<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>apomi ｜ {label}が終了しました</title><style>
 body{{font-family:-apple-system,"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif;
   color:#274b40;margin:0;line-height:1.9;background:linear-gradient(180deg,#fff6e6,#f4fbf8 45%,#fff)}}
 .wrap{{max-width:640px;margin:0 auto;padding:30px 18px 60px;text-align:center}}
 .card{{background:#fff;border:2px solid #e2953b;border-radius:20px;padding:26px 22px}}
 h1{{font-size:22px;color:#b5761f;margin:8px 0}}
 p{{font-size:14.5px;text-align:left}}
 .ok{{background:#eefaf6;border:1px solid #cfe8dd;border-radius:12px;padding:12px 14px;
   font-size:14px;color:#1f7d5e;text-align:left;margin-top:14px}}
 .how{{background:#f7faf9;border:1px solid #cfe8dd;border-radius:12px;padding:12px 16px;
   font-size:14px;text-align:left;margin-top:14px}}
</style></head><body><div class="wrap"><div class="card">
<div style="font-size:44px">⏸️</div>
<h1>{label}が終了しました</h1>
<p>いつもapomiをご利用いただき、ありがとうございます。<br>
{label}（{s['expiry']:%Y年%m月%d日}）と猶予期間が終了したため、チェック機能をいったんお休みしています。</p>
<div class="ok">🦷 <b>設定やこれまでの結果は消えていません。</b><br>
ライセンスコードを登録すると、そのままの設定ですぐに再開できます。</div>
{_extend_offer_html()}
<div class="how"><b>再開のしかた</b><br>
① ご継続のお手続きをどうぞ：📧 <b>apomi.dental@gmail.com</b>（返信は平日・2営業日以内が目安）
／ ☎ 050-1809-0279（平日10:00〜16:00）<br>
　「apomiを継続したい」の一言と医院名だけでOK。ライセンスコード（APOMI-△△△△-…）をお送りします<br>
② デスクトップの「アポチェック」をダブルクリック<br>
③ 表示される入力画面にコードを貼り付け → すぐに再開します</div>
</div></div></body></html>'''
