# -*- coding: utf-8 -*-
"""apomi: Genifix APIから予約を直接取得してアポパトロールを実行する（PDF不要）。

使い方:
  python run_apomi.py           … 今日のチェック範囲を自動判定して実行
  python run_apomi.py 30        … 30日先までを指定して実行
"""
import os, sys, glob, datetime, traceback

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import genifix_api
from parse_shift import parse_shift
from apo_patrol import patrol
from report_html import render_html

from apomi_paths import desktop_dir, open_path
DESKTOP = desktop_dir()

def newest_shift():
    files = glob.glob(os.path.join(DESKTOP, '*勤務予定表*.pdf'))
    if not files:
        files = glob.glob(os.path.join(BASE, '*勤務予定表*.pdf'))
    return max(files, key=os.path.getmtime) if files else None

def scope_days(today=None):
    """朝のお知らせ（watch_patrol.choose_scope）と同じ判定を使う。
    月初の診療日=4か月先 / 週初めの診療日=1か月先 / それ以外=1週間先"""
    today = today or datetime.date.today()
    shift_pdf = newest_shift()
    shift = None
    if shift_pdf:
        try:
            shift = parse_shift(shift_pdf)
        except Exception:
            pass
    import watch_patrol
    scope, end, _ = watch_patrol.choose_scope(today, shift)
    return (end - today).days, scope

def main():
    import watch_patrol
    if not watch_patrol.license_gate(force_notice=True):
        print('使用期限が切れているため、チェックをお休みしています（案内を開きました）。')
        return 3
    days = int(sys.argv[1]) if len(sys.argv) > 1 else None
    if days:
        label = f'{days}日先まで（手動指定）'
    else:
        days, label = scope_days()

    if not genifix_api.is_ready():
        print('Genifixのログイン情報が未登録です。')
        print('「はじめての設定.bat」を実行して登録してください。')
        input('Enterで終了')
        return 2

    print(f'Genifixから予約を取得中… {label}')
    data = genifix_api.fetch(datetime.date.today().isoformat(), days)
    recs = genifix_api.to_records(data)
    print(f'  {len(recs)}件 / {len(data["dateInfos"])}日分を取得しました')

    # 出勤情報もGenifixから直接取る（勤務予定表PDFの差し替えが不要）
    shift = genifix_api.to_shift(data)
    shift_src = ''
    if shift:
        print(f'  出勤情報もGenifixから取得しました（{len(shift["byDate"])}日分）')
        shift_src = 'Genifixから直接取得'
    else:
        # 万一APIから取れないときは、従来どおり勤務予定表PDFを使う
        shift_pdf = newest_shift()
        if shift_pdf:
            try:
                shift = parse_shift(shift_pdf)
                shift_src = os.path.basename(shift_pdf)
                print(f'  出勤情報: {shift_src}')
            except Exception:
                print('  シフト表の読み込みに失敗しました（出勤チェックは省略します）')

    issues, infos, stats = patrol(recs, shift)
    body = render_html(recs, issues, infos, shift, stats,
                       src_yoyaku=f'Genifixから直接取得（{label}）',
                       src_shift=shift_src)
    try:
        import apomi_license as lic
        body = lic.inject_banner(body)
    except Exception:
        pass
    stamp = f'{datetime.datetime.now():%Y%m%d_%H%M%S}'
    out = os.path.join(BASE, f'アポパトロール結果_{stamp}.html')
    with open(out, 'w', encoding='utf-8-sig') as f:
        f.write(body)
    open_path(out)
    n_err = sum(1 for l, _, _ in issues if l == 'エラー')
    print(f'完了！ エラー{n_err}件。結果をブラウザで開きました。')
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except genifix_api.GenifixError as e:
        if 'SETUP_REQUIRED' in str(e):
            print('ログイン情報が未登録です。「はじめての設定.bat」を実行してください。')
        else:
            print(f'エラー: {e}')
        input('Enterで終了')
        sys.exit(1)
    except Exception:
        print('予期しないエラーが発生しました:')
        traceback.print_exc()
        input('Enterで終了')
        sys.exit(1)
