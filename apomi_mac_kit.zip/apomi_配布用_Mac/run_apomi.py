# -*- coding: utf-8 -*-
"""apomi: Genifix APIから予約を直接取得してアポパトロールを実行する（PDF不要）。

使い方:
  python run_apomi.py           … 今日のチェック範囲を自動判定して実行
  python run_apomi.py 30        … 30日先までを指定して実行
"""
import os, sys, glob, datetime, traceback

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import genifix_api
from parse_shift import parse_shift
from apo_patrol import patrol
import report_html
from report_html import render_html

from apomi_paths import desktop_dir, open_path
DESKTOP = desktop_dir()
# 非常用の控えのために毎日読む日数（月初の4か月チェックと同じ長さ）
BACKUP_DAYS = 122


def reiwa_to_date(s):
    """令和8.10.01 → date。読めなければ None"""
    import re
    m = re.search(r'令和(\d+)\.(\d+)\.(\d+)', s or '')
    try:
        return datetime.date(2018 + int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None
    except ValueError:
        return None

def newest_shift():
    files = glob.glob(os.path.join(DESKTOP, '*勤務予定表*.pdf'))
    if not files:
        files = glob.glob(os.path.join(BASE, '*勤務予定表*.pdf'))
    return max(files, key=os.path.getmtime) if files else None

def scope_days(today=None):
    """朝のお知らせ（watch_patrol.choose_scope）と同じ判定を使う。
    月初の診療日=4か月先 / 週初めの診療日=1か月先 / それ以外=1週間先"""
    today = today or datetime.date.today()
    shift_pdf = newest_shift()
    shift = None
    if shift_pdf:
        try:
            shift = parse_shift(shift_pdf)
        except Exception:
            pass
    import watch_patrol
    scope, end, _ = watch_patrol.choose_scope(today, shift)
    return (end - today).days, scope

def main():
    import watch_patrol
    if not watch_patrol.license_gate(force_notice=True):
        print('使用期限が切れているため、チェックをお休みしています（案内を開きました）。')
        return 3
    days = int(sys.argv[1]) if len(sys.argv) > 1 else None
    if days:
        label = f'{days}日先まで（手動指定）'
    else:
        days, label = scope_days()

    if not genifix_api.is_ready():
        print('Genifixのログイン情報が未登録です。')
        print('「はじめての設定.bat」を実行して登録してください。')
        input('Enterで終了')
        return 2

    # 予約は毎日「非常用の控え」のぶん（4か月先）まで読む。チェックの範囲（1週間/1か月/4か月）は
    # 従来どおりで、読んだうちの範囲内だけをチェックにかける。4か月ぶんは実測14秒・約3,200件
    today = datetime.date.today()
    fetch_days = max(days, BACKUP_DAYS)
    print(f'Genifixから予約を取得中… チェックは{label}／控えは{fetch_days}日先まで')
    try:
        data = genifix_api.fetch(today.isoformat(), fetch_days)
        backup_ok = True
    except genifix_api.GenifixError:
        if fetch_days == days:
            raise
        # 長い範囲で失敗したら、今日のチェックだけは通す（控えの更新は次回に回す）
        print('  4か月ぶんの取得に失敗したので、今日のチェック範囲だけ読み直します')
        data = genifix_api.fetch(today.isoformat(), days)
        backup_ok = False
    recs_all = genifix_api.to_records(data)
    end = today + datetime.timedelta(days=days)
    recs = [r for r in recs_all if (reiwa_to_date(r['予約日']) or end) < end]
    print(f'  {len(recs_all)}件 / {len(data["dateInfos"])}日分を取得し、{len(recs)}件をチェックします')

    # 出勤情報もGenifixから直接取る（勤務予定表PDFの差し替えが不要）
    shift = genifix_api.to_shift(data)
    shift_src = ''
    if shift:
        print(f'  出勤情報もGenifixから取得しました（{len(shift["byDate"])}日分）')
        shift_src = 'Genifixから直接取得'
    else:
        # 万一APIから取れないときは、従来どおり勤務予定表PDFを使う
        shift_pdf = newest_shift()
        if shift_pdf:
            try:
                shift = parse_shift(shift_pdf)
                shift_src = os.path.basename(shift_pdf)
                print(f'  出勤情報: {shift_src}')
            except Exception:
                print('  シフト表の読み込みに失敗しました（出勤チェックは省略します）')

    issues, infos, stats = patrol(recs, shift)
    report_html.record_history(recs, issues, stats, src=f'Genifix（{label}）')
    # 非常用の控え（予約ソフトが開かない日に紙で出すための予約表）を最新にする
    try:
        import apomi_backup
        if backup_ok:
            backup_sheet = apomi_backup.save_snapshot(
                recs_all, src=f'Genifixから直接取得（{fetch_days}日先まで）',
                start=today, end=today + datetime.timedelta(days=fetch_days - 1))
        else:
            backup_sheet = apomi_backup.build_sheet()   # 前回の控えのまま
    except Exception:
        backup_sheet = ''
    body = render_html(recs, issues, infos, shift, stats,
                       src_yoyaku=f'Genifixから直接取得（{label}）',
                       src_shift=shift_src,
                       backup_sheet=backup_sheet)
    try:
        import apomi_license as lic
        body = lic.inject_banner(body)
    except Exception:
        pass
    stamp = f'{datetime.datetime.now():%Y%m%d_%H%M%S}'
    out = os.path.join(BASE, f'アポパトロール結果_{stamp}.html')
    with open(out, 'w', encoding='utf-8-sig') as f:
        f.write(body)
    open_path(out)
    n_err = sum(1 for l, _, _ in issues if l == 'エラー')
    print(f'完了！ エラー{n_err}件。結果をブラウザで開きました。')
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except genifix_api.GenifixError as e:
        if 'SETUP_REQUIRED' in str(e):
            print('ログイン情報が未登録です。「はじめての設定.bat」を実行してください。')
        else:
            print(f'エラー: {e}')
        input('Enterで終了')
        sys.exit(1)
    except Exception:
        print('予期しないエラーが発生しました:')
        traceback.print_exc()
        input('Enterで終了')
        sys.exit(1)
