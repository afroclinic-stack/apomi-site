# -*- coding: utf-8 -*-
"""医院ごとの設定（チェア構成・診療時間・上限など）を読み込む。

- 同じフォルダの「医院設定.json」があればそれを使う。
- 無い/一部だけの場合は、足りない項目を内蔵の初期値（いいづか歯科医院）で補う。

これにより、apomi本体のコードを書き換えずに、医院ごとの設定だけ差し替えられる。
納品先ではこの「医院設定.json」を編集（将来は設定画面で編集）するだけでよい。
"""
import os
import json

from apomi_paths import data_dir, bundle_dir
BASE = data_dir()                                   # 医院ごとの設定を置く場所
SETTINGS_PATH = os.path.join(BASE, '医院設定.json')

# ===== 内蔵の初期値（いいづか歯科医院） =====
# 医院設定.json が無いとき・項目が足りないときのフォールバック。
DEFAULTS = {
    "clinic_name": "いいづか歯科医院",
    "open_hours": [["09:00", "17:30"]],   # 診療時間（複数帯なら [["09:00","12:00"],["14:00","18:00"]]）
    "lunch_window": ["11:30", "14:30"],    # 交代で昼休みを取る帯（この帯の空き枠は参考扱い）。無ければ null
    "slot_min": 15,                         # チェックの粒度（分）
    "max_treatment": 9,                     # 同時治療の上限（これを超えたらエラー）
    "max_counseling": 2,                    # カウンセリング同時の上限
    "counseling_rooms": ["カウンセリング1", "カウンセリング2"],
    # 治療チェアを役割グループで定義。役割は出勤照合と定員計算に使う。
    # 役割の区別が無い医院は 1グループ（role を "" など）にまとめてよい。
    "chair_groups": [
        {"role": "DH", "chairs": ["DH1", "DH2", "DH3", "DH4", "DH5", "DH6", "DH7"]},
        {"role": "Dr", "chairs": ["Dr1", "Dr2"]}
    ],
    # シフト表の名前 → 予約システムのスタッフ名 の対応（姓の前方一致で自動照合。特例だけ書く）
    "staff_alias": {"院長": ["飯塚", "院長"], "TC": ["ＴＣ", "TC"]},
    # 初診連携（外側の枠の中に内側の枠が収まり、片方に keyword を含むなら重複を正常扱い）
    # この運用が無い医院は enabled:false にする（その場合は普通の二重予約として検出）
    "shoshin_link": {"enabled": True, "outer_role": "DH", "inner_role": "Dr", "keyword": "初診"},
    # 曜日ごとに「必ず出勤しているべきスタッフ」。診療日なのにいなければエラーにする。
    # 例: 水曜は中野DHが必須 → {"weekday":"水","name":"中野","role":"DH"}
    # weekday は 月火水木金土日 のいずれか。無ければ [] （チェックしない）。
    "required_staff": [],
    # 担当の固定休。「桑野さんは毎週木曜休み」のような規則的な休みを登録すると、
    # その曜日にその人の担当予約が入っていたら知らせる（シフト表が無くても使える）。
    # rules は {"名前": ["木"]} 形式（名前は前方一致・曜日は 月火水木金土日）。
    "staff_fixed_off": {"enabled": False, "level": "エラー", "rules": {}},
    # 同じスタッフが同じ時間に2つの予約に入っている（人は2か所に居られない）。
    # 医院によっては歯科医師が複数チェアを行き来する運用があるため、
    # level を "警告" にしたり、ignore_staff にその人を入れて除外できる。
    # 同一患者の重なりは「患者二重予約」「初診連携」で扱うのでここでは報告しない。
    # parallel_staff = 並列（掛け持ち）がOKな人と同時上限（前方一致）。例 {"桑野": 2}
    #   上限内の並列は「注意（参考）」で表示（消さない＝故意の並列も見える）、超えたらエラー。
    #   ignore_staff は完全非表示（TCのように並列が日常で、表示も不要な役職向け）。
    "staff_double_booking": {"enabled": True, "level": "エラー",
                             "ignore_staff": [], "parallel_staff": {}},
    # 同じ患者が同じ時間に2つの予約に入っている。
    # 予約表が「担当者ごとの列」になっているシステム（EPARK歯科台帳など）では、
    # 1人の患者に歯科医師と衛生士が同時につくと、正常なのに重複に見える。
    # そういう医院は enabled:false にする。
    "patient_double_booking": {"enabled": True},
    # 出勤者が誰もいない日（休診日）なのに予約が入っている。
    # 出勤情報がその日をカバーしている場合だけ判定する（データが無い日は判定しない）。
    "closed_day_booking": {"enabled": True, "level": "エラー"},
    # 同じチェアの予約と予約の間に、片付け・消毒の時間を何分空けるか。
    # 間隔がこれ未満なら指摘する。使う医院だけ enabled:true にする。
    # ※ 重なっている場合は「チェア相乗り」で報告するのでここでは扱わない。
    # ※ 同じ患者さんの連続予約は片付け不要なので対象外。
    "chair_buffer": {"enabled": False, "minutes": 5, "level": "警告"},
    # 処置ごとの標準時間。予約の長さが標準と違えば指摘する（時間の取り違え検出）。
    # rules の keyword が処置名に含まれていれば、その minutes と比べる。
    # 複数一致する場合は「より具体的（長い）keyword」を優先。
    # tolerance は許容誤差（分）。0なら完全一致を求める。
    "treatment_minutes": {"enabled": False, "level": "警告", "tolerance": 0, "rules": []},
    # 処置ごとの「できる人・使える場所」の制約。
    # rules の各項目で、必要なものだけ指定する（指定しないものは自由）。
    #   keyword        … 処置名にこの文字が含まれる予約が対象
    #   allowed_chairs … その処置を行えるチェア（例: インプラントはDr1のみ）
    #   allowed_roles  … その処置を行える役割（例: 抜歯はDrのみ）※出勤情報がある日だけ判定
    #   allowed_staff  … その処置を行える人の名前（例: 矯正は院長のみ）
    # 1件の予約に複数担当が入っている場合は、誰か1人が条件を満たせばOKとする。
    "treatment_constraints": {"enabled": False, "level": "エラー", "rules": []},
    # カウンセリング室の「長い予約」＝そこで治療をしているサイン。
    # カウンセリング室は治療チェアと別に数えるので、そこで治療をされると、
    # 実際には定員いっぱい＋1人を同時に診ていても、治療の同時件数は上限内のままになる。
    # 相談・説明の標準時間（minutes）より長い予約があれば知らせる。
    # ※「minutes を超えたら」なので、minutes ちょうどの予約は鳴らない。
    "counseling_long": {"enabled": False, "minutes": 15, "level": "警告"},
    # 飛び地の空き枠＝前後が予約で埋まっていて、短いために売りにくい穴。
    # max_minutes 以下の穴を「売りにくい枠」として一覧に出す。
    "isolated_gap": {"enabled": False, "max_minutes": 30},
    # チェア稼働の偏り＝その日いちばん使われたチェアと、いちばん少ないチェアの差。
    # 差が max_diff_minutes 以上なら偏りとして一覧に出す（実際に使われたチェアだけで比較）。
    "chair_balance": {"enabled": False, "max_diff_minutes": 120}
}


class Settings:
    def __init__(self, d):
        self.raw = d
        self.clinic_name = d.get("clinic_name", "")
        self.open_hours = [tuple(x) for x in d["open_hours"]]
        lw = d.get("lunch_window")
        self.lunch_window = tuple(lw) if lw else None
        self.slot_min = int(d["slot_min"])
        self.max_treatment = int(d["max_treatment"])
        self.max_counseling = int(d["max_counseling"])
        self.counseling_rooms = list(d.get("counseling_rooms", []))
        self.chair_groups = [
            {"role": g["role"], "chairs": list(g["chairs"])} for g in d["chair_groups"]
        ]
        self.treatment_chairs = [c for g in self.chair_groups for c in g["chairs"]]
        self.chairs_by_role = {}
        for g in self.chair_groups:
            self.chairs_by_role.setdefault(g["role"], []).extend(g["chairs"])
        self.staff_alias = dict(d.get("staff_alias", {}))
        sl = dict(d.get("shoshin_link", {"enabled": False}))
        sl.setdefault("enabled", False)
        self.shoshin_link = sl
        self.required_staff = list(d.get("required_staff", []))
        self.staff_fixed_off = dict(d.get("staff_fixed_off", {}))
        sdb = dict(d.get("staff_double_booking", {}))
        sdb.setdefault("enabled", False)
        sdb.setdefault("level", "エラー")
        sdb.setdefault("ignore_staff", [])
        self.staff_double_booking = sdb
        pdb = dict(d.get("patient_double_booking", {}))
        pdb.setdefault("enabled", True)     # 既定は今までどおり検出する
        self.patient_double_booking = pdb
        cdb = dict(d.get("closed_day_booking", {}))
        cdb.setdefault("enabled", False)
        cdb.setdefault("level", "エラー")
        self.closed_day_booking = cdb
        cb = dict(d.get("chair_buffer", {}))
        cb.setdefault("enabled", False)
        cb.setdefault("minutes", 0)
        cb.setdefault("level", "警告")
        self.chair_buffer = cb
        tm = dict(d.get("treatment_minutes", {}))
        tm.setdefault("enabled", False)
        tm.setdefault("level", "警告")
        tm.setdefault("tolerance", 0)
        tm.setdefault("rules", [])
        self.treatment_minutes = tm
        tc = dict(d.get("treatment_constraints", {}))
        tc.setdefault("enabled", False)
        tc.setdefault("level", "エラー")
        tc.setdefault("rules", [])
        self.treatment_constraints = tc
        cl = dict(d.get("counseling_long", {}))
        cl.setdefault("enabled", False)
        cl.setdefault("minutes", 15)
        cl.setdefault("level", "警告")
        self.counseling_long = cl
        ig = dict(d.get("isolated_gap", {}))
        ig.setdefault("enabled", False)
        ig.setdefault("max_minutes", 30)
        self.isolated_gap = ig
        cbal = dict(d.get("chair_balance", {}))
        cbal.setdefault("enabled", False)
        cbal.setdefault("max_diff_minutes", 120)
        self.chair_balance = cbal

    def open_hours_text(self):
        return "／".join(f"{o}～{c}" for o, c in self.open_hours)

    def lunch_window_text(self):
        if not self.lunch_window:
            return ""
        return f"{self.lunch_window[0]}〜{self.lunch_window[1]}"


def reload():
    """医院設定.json を読み直して、S をその場で更新する。
    S を参照しているモジュール（apo_patrol / report_html 等）も即座に新設定になる。
    見張り役が再起動なしで設定を切り替えるために使う。"""
    S.__init__(load().raw)
    return S


def load(path=None):
    """設定を読み込んで Settings を返す。JSONが壊れていても初期値で動く。"""
    path = path or SETTINGS_PATH
    data = json.loads(json.dumps(DEFAULTS))  # ディープコピー
    try:
        if os.path.exists(path):
            with open(path, encoding='utf-8-sig') as f:
                user = json.load(f)
            for k, v in user.items():
                if not str(k).startswith('_'):   # "_メモ" のような説明キーは無視
                    data[k] = v
    except Exception as e:
        print(f'医院設定.json の読み込みに失敗したため初期値で動作します: {e}')
    return Settings(data)


# モジュール読み込み時に一度だけ読む（1インストール＝1医院を想定）
S = load()
