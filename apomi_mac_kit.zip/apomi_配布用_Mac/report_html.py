# -*- coding: utf-8 -*-
"""アポパトロール結果をポップなHTMLレポートに変換する（空き枠ダッシュボード中心）"""
import re, html, datetime, os, base64
from apomi_settings import S as SETTINGS

# ===== これまでの記録（成果の見える化）=====
# チェックのたびに1行ずつ残し、「使ってきてどうだったか」が分かるようにする。
# 医院のパソコンの中だけに保存し、どこにも送らない。
HISTORY_FILE = 'apomi履歴.csv'
HISTORY_HEAD = ['日時', '対象期間', '日数', '予約件数', 'エラー', '警告', '注意',
                '埋まり率', '空き時間（分）', '取り込み元']


def _history_path():
    try:
        from apomi_paths import data_dir
        return os.path.join(data_dir(), HISTORY_FILE)
    except Exception:
        return ''


def record_history(recs, issues, stats, src=''):
    """1回ぶんのチェック結果を履歴に足す（失敗しても本体は止めない）"""
    path = _history_path()
    if not path:
        return
    try:
        import csv
        slot = getattr(SETTINGS, 'slot_min', 15)
        book = cap = 0
        for slots in (stats or {}).values():
            for s in slots:
                book += s.get('book', 0)
                cap += s.get('cap', 0)
        dates = sorted(set(r['予約日'] for r in recs))
        row = [datetime.datetime.now().strftime('%Y-%m-%d %H:%M'),
               (dates[0] + '〜' + dates[-1]) if dates else '',
               len(stats or {}),
               len(recs),
               sum(1 for l, _, _ in issues if l == 'エラー'),
               sum(1 for l, _, _ in issues if l == '警告'),
               sum(1 for l, _, _ in issues if l == '注意'),
               f'{100.0 * book / cap:.1f}' if cap else '',
               (cap - book) * slot,
               src]
        new = not os.path.exists(path)
        with open(path, 'a', encoding='utf-8-sig', newline='') as f:
            w = csv.writer(f)
            if new:
                w.writerow(HISTORY_HEAD)
            w.writerow(row)
    except Exception:
        pass          # 記録できなくても、チェック結果は必ず出す


def _history_rows(limit=0):
    path = _history_path()
    if not path or not os.path.exists(path):
        return []
    try:
        import csv
        with open(path, encoding='utf-8-sig') as f:
            rows = [r for r in csv.DictReader(f) if r.get('日時')]
        return rows[-limit:] if limit else rows
    except Exception:
        return []


def history_block():
    """レポートの下に出す「これまでの記録」。まだ2回目未満なら何も出さない。"""
    rows = _history_rows()
    if len(rows) < 2:
        return ''

    def num(r, k):
        try:
            return float(r.get(k) or 0)
        except ValueError:
            return 0.0

    n_err = int(sum(num(r, 'エラー') for r in rows))
    n_warn = int(sum(num(r, '警告') for r in rows))
    first = rows[0]['日時'][:10]
    pcts = [(r['日時'][5:10], num(r, '埋まり率')) for r in rows if r.get('埋まり率')]
    spark = ''
    if len(pcts) >= 2:
        recent = pcts[-12:]
        bars = ''.join(
            f'<span class="hb" style="height:{max(4, p * 0.6):.0f}px" '
            f'title="{d} {p:.1f}%"></span>' for d, p in recent)
        diff = recent[-1][1] - recent[0][1]
        arrow = ('▲ +' if diff > 0 else ('▼ ' if diff < 0 else '→ ')) + f'{abs(diff):.1f}'
        cls = 'up' if diff > 0 else ('down' if diff < 0 else '')
        spark = (f'<div class="hist-graph"><div class="hbars">{bars}</div>'
                 f'<div class="hist-note">埋まり率の推移（直近{len(recent)}回）'
                 f'　<b class="{cls}">{arrow}ポイント</b></div></div>')
    return f'''
<h2>📈 これまでの記録 <span class="sub">〜 apomiを使ってきた積み重ね 〜</span></h2>
<div class="histbox">
  <div class="hist-nums">
    <div class="hn"><div class="n">{len(rows)}</div><div class="t">チェックした回数</div></div>
    <div class="hn"><div class="n">{n_err}</div><div class="t">見つけた要修正</div></div>
    <div class="hn"><div class="n">{n_warn}</div><div class="t">見つけた要確認</div></div>
  </div>
  {spark}
  <div class="hist-foot">{first} から記録しています。
    この記録は<b>このパソコンの中だけ</b>に保存され、どこにも送信されません
    （apomi履歴.csv）。<br>
    ※ 埋まり率は季節や医院の取り組みでも変わります。apomiの効果だけを示すものではありません。</div>
</div>'''


# ===== アポミちゃん（マスコット画像）=====
from apomi_paths import bundle_dir
ASSET_DIR = os.path.join(bundle_dir(), 'アポミちゃん', 'web')
APOMI = {
    'normal':  'アポミちゃん_ver5.jpg',                     # にっこり＋チェックリスト
    'perfect': 'アポミちゃん（喜び座り）.jpg',               # ガッツポーズ（座り）
    'party':   'アポミちゃん（めっちゃ喜び立ち）.jpg',       # 大喜び（立ち）
    'alert':   'アポミちゃん（怒り＋バインダー）.jpg',       # ミス発見！
    'angry':   'アポミちゃん（怒りバージョン）.jpg',         # 怒り飛行
    'sad':     'アポミちゃん（悲しみバージョン）.jpg',       # しょんぼり（売れ残り多め）
    'fly':     'アポミちゃん（歯ブラシ跨り）.jpg',           # パトロール飛行
    'patrol':  'アポミちゃん（立ち＋歯ブラシ下向き）.jpg',   # 出動ポーズ
    'patrol2': 'アポミちゃん（立ち＋歯ブラシ上向き）.jpg',
}

def apomi_img(kind, cls='apomi'):
    """アポミちゃん画像をbase64で埋め込む（レポートを1ファイル完結に保つため）。
    画像が無い環境でもレポート自体は壊れないよう、失敗時は空文字を返す"""
    try:
        p = os.path.join(ASSET_DIR, APOMI[kind])
        b64 = base64.b64encode(open(p, 'rb').read()).decode()
        return f'<img class="{cls}" src="data:image/jpeg;base64,{b64}" alt="アポミちゃん">'
    except Exception:
        return ''

SLOT_MIN = 15
FILL_GOOD = 90   # 埋まり率がこれ以上なら緑
FILL_MID = 75    # これ以上なら黄、未満は赤
WEEKDAYS = ['月', '火', '水', '木', '金', '土', '日']

CAT_EMOJI = {
    '患者二重予約': '👥', '患者同日複数予約': '🗑️', 'チェア相乗り': '🪑',
    '治療予約数': '🚨', 'カウンセリング数': '🚨',
    '担当が休み': '🏖️', '担当が勤務時間外': '⏰',
    '担当者ダブルブッキング': '🙋', '休診日に予約': '🚫',
    '必須スタッフ欠勤': '📌',
    '担当者未設定': '❓', '処置未設定': '❓',
    '診療時間外': '🌙', '時間異常': '⏰', '要注意患者': '⚠️',
    '人手不足の時間帯': '🆘', '日付読み取り不確か': '❗',
    '予約間のバッファ不足': '🧹', '処置時間の不一致': '📏',
    '処置とチェアの不一致': '🚧', '処置と担当の不一致': '👤',
}

def esc(s):
    return html.escape(str(s))


def render_error_html(filename, detail='', inbox=''):
    """読み取りに失敗したときの案内ページ。
    技術的な内容をそのまま見せず、「何をすればいいか」を先に伝える。
    詳しい情報は、問い合わせ用に折りたたんで最後に置く。"""
    detail_block = ''
    if detail:
        detail_block = (
            '<details class="tech"><summary>くわしい情報（お問い合わせのときに使います）</summary>'
            f'<pre>{esc(detail)}</pre></details>')
    inbox_line = (f'<div class="path">{esc(inbox)}</div>') if inbox else ''
    return f'''<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>apomi ｜ 読み取れませんでした</title><style>
 body{{font-family:-apple-system,"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif;
   color:#274b40;margin:0;line-height:1.8;background:linear-gradient(180deg,#fff6e6,#f4fbf8 45%,#fff);}}
 .wrap{{max-width:680px;margin:0 auto;padding:26px 18px 60px}}
 .head{{text-align:center;padding:22px;border-radius:22px;background:#fff;border:2px solid #e2953b}}
 .head img{{width:104px;height:104px;border-radius:50%;object-fit:cover;border:4px solid #fff;
   box-shadow:0 5px 16px rgba(226,149,59,.25);background:#fff}}
 .t{{font-size:23px;font-weight:900;color:#b5761f;margin:10px 0 4px}}
 .f{{font-size:14px;color:#5c7a70;word-break:break-all}}
 h2{{font-size:18px;color:#1f7d5e;margin:28px 0 10px}}
 .card{{background:#fff;border:1px solid #cfe8dd;border-radius:14px;padding:14px 16px;margin:10px 0}}
 .card b{{color:#1f7d5e}}
 ol{{padding-left:22px}} ol li{{margin:8px 0}}
 .path{{font-size:13px;background:#eefaf6;border:1px dashed #cfe8dd;border-radius:8px;
   padding:8px 10px;margin-top:8px;word-break:break-all;color:#5c7a70}}
 .tech{{margin-top:26px;background:#f7faf9;border:1px solid #cfe8dd;border-radius:12px;padding:10px 14px}}
 .tech summary{{cursor:pointer;color:#7c968c;font-size:13px}}
 .tech pre{{white-space:pre-wrap;font-size:11.5px;color:#6b8f83;max-height:260px;overflow:auto}}
 .ok{{background:#eefaf6;border:1px solid #cfe8dd;border-radius:12px;padding:12px 14px;
   margin-top:18px;font-size:14px;color:#1f7d5e}}
</style></head><body><div class="wrap">
<div class="head">
  {apomi_img('sad')}
  <div class="t">読み取れませんでした</div>
  <div class="f">{esc(filename)}</div>
</div>

<h2>よくある原因は、この3つです</h2>
<div class="card"><b>① 予約システムの書き出し形式が、まだapomiに登録されていない</b><br>
  はじめて使う形式のファイルだと、読み方が分からず止まります。<br>
  → いちばん多い原因です。下の「してほしいこと」の②へ。</div>
<div class="card"><b>② ファイルが途中までしか保存されていない</b><br>
  書き出しの途中でコピーされた場合など。もう一度書き出すと直ることがあります。</div>
<div class="card"><b>③ 予約一覧ではないファイルが入っていた</b><br>
  別の書類のCSV・PDFが、まちがってフォルダに入っていませんか？</div>

<h2>してほしいこと</h2>
<div class="card">
<ol>
  <li><b>もう一度、予約一覧を書き出して入れ直してみてください。</b><br>
      これで直ることがよくあります。</li>
  <li>それでも同じなら、<b>このファイルを添えてご連絡ください。</b><br>
      読み方を追加すれば使えるようになります（設定を追加するだけです）。<br>
      📧 <b>apomi.dental@gmail.com</b>（返信は平日・2営業日以内が目安）<br>
      <span style="font-size:12.5px;color:#7c968c">※患者さんのお名前が入っている場合は、
      分かる範囲で消してから送ってください。一番下の「くわしい情報」の文面も一緒に貼ってもらえると早いです。</span></li>
</ol>
<div style="background:#fff6e6;border:1px solid #f0d9a8;border-radius:10px;padding:10px 12px;margin-top:8px;font-size:13.5px">
🆓 <b>動くまで、費用はかかりません。</b>
読み方を追加してお返しし、この画面ではなく<b>結果の画面が出ることを確かめてから</b>お申し込みいただきます。
それまでは無料の試用期間を延ばしたコードをお送りします。対応できなかった場合も、費用は一切かかりません。
</div>
<b>読み取れなかったファイルの場所</b>（「エラー」フォルダに移してあります）
{inbox_line}
</div>

<div class="ok">🦷 予約データが壊れたり、消えたりはしていません。安心してください。<br>
このファイルは読み飛ばしただけなので、次のファイルからは通常どおり動きます。</div>

{detail_block}
</div></body></html>'''

def reiwa_to_date(datestr):
    m = re.search(r'令和(\d+)\.(\d+)\.(\d+)', datestr)
    if not m:
        return None
    try:
        return datetime.date(2018 + int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None

def fmt_min(mins):
    return f'{mins//60:02d}:{mins%60:02d}'

def day_label(datestr):
    d = reiwa_to_date(datestr)
    if not d:
        return datestr
    return f'{d.month}/{d.day}（{WEEKDAYS[d.weekday()]}）'

def hours_txt(units):
    h = units * SLOT_MIN / 60
    return f'{h:g}時間'

def _day_summary(slots):
    """非昼休み帯の 埋まり数/枠数、昼休み帯の空き数 を集計"""
    cap = sum(s['cap'] for s in slots if not s['lunch'])
    book = sum(min(s['book'], s['cap']) for s in slots if not s['lunch'])
    lunch_cap = sum(s['cap'] for s in slots if s['lunch'])
    lunch_book = sum(min(s['book'], s['cap']) for s in slots if s['lunch'])
    return cap, book, lunch_cap, lunch_book

def _fill_cls(pct):
    return 'good' if pct >= FILL_GOOD else ('mid' if pct >= FILL_MID else 'bad')

def _slot_row(s):
    dots = ('<span class="dot on">●</span>' * min(s['book'], s['cap'])
            + '<span class="dot off">●</span>' * max(0, s['cap'] - s['book']))
    free = ', '.join(s['free'][:max(0, s['cap'] - s['book'])])
    freetxt = f'<span class="free">空き: {esc(free)}</span>' if free else ''
    return (f'<div class="slot"><span class="time">{fmt_min(s["t"])}〜{fmt_min(s["t"]+SLOT_MIN)}</span>'
            f'<span class="dots">{dots}</span>'
            f'<span class="cnt">{s["book"]}/{s["cap"]}</span>{freetxt}</div>')

# 売れ残り金額の概算計算機（クリックで開く。金額は押した人にだけ見せる設計）
# __HOURS__=空き時間(時間), __PERIOD__=期間表示 を差し込んで使う。
# 単価・収入・時間・表示のオンオフは localStorage に記憶（そのPCの中だけ・送信なし）。
_URNK_TMPL = '''
<div id="urnk-panel" class="urnk-panel" style="display:none">
  <div class="urnk-head">売れ残り金額の概算<span class="urnk-pclose" id="urnk-pclose" title="閉じる">✕</span></div>
  <div class="urnk-row">チェア1台・1時間あたりの売上
    <input id="urnk-rate" type="number" step="100" value="8000"> 円</div>
  <div class="urnk-note">初期値は全国平均の目安（出典：第24回医療経済実態調査をもとにした概算）</div>
  <div class="urnk-sec">
    <div>あなたの医院の単価を計算 <span class="urnk-note">— 入力すると上の単価に自動で反映されます</span></div>
    <div class="urnk-row">1か月の医業収入 <input id="urnk-rev" type="number"> 万円
      1か月の予約可能時間 <input id="urnk-cap" type="number"> 時間</div>
    <div class="urnk-note">予約可能時間の目安：ユニット台数 × 1日の診療時間 × 診療日数</div>
  </div>
  <div class="urnk-row" style="margin-top:10px">
    <button class="urnk-go" id="urnk-go">概算を計算</button>
    <span class="urnk-res" id="urnk-res"></span>
  </div>
  <div class="urnk-note">※あくまで概算です。実際の収入額を保証・予測するものではありません。</div>
</div>
<script>
(function(){
  var HOURS = __HOURS__;
  var PERIOD = '__PERIOD__';
  function $(i){ return document.getElementById(i); }
  function num(v){ var x = parseFloat(v); return isNaN(x) ? 0 : x; }
  function fmt(yen){
    var man = yen / 10000;
    if (man >= 10000) return (man / 10000).toFixed(2) + '億円';
    return (man >= 100 ? Math.round(man).toLocaleString() : man.toFixed(1)) + '万円';
  }
  function get(k){ try { return localStorage.getItem(k); } catch(e){ return null; } }
  function set(k, v){ try { localStorage.setItem(k, v); } catch(e){} }
  var computed = false;
  function showBadge(rate){
    if (!(rate > 0)) return;
    $('urnk-amt').textContent = fmt(HOURS * rate);
    $('urnk-p2').textContent = PERIOD;
    $('urnk-badge').style.display = 'inline-flex';
  }
  var saved = num(get('apomi_単価'));
  if (saved > 0) $('urnk-rate').value = saved;
  if (get('apomi_収入')) $('urnk-rev').value = get('apomi_収入');
  if (get('apomi_時間')) $('urnk-cap').value = get('apomi_時間');
  if (saved > 0 && get('apomi_金額表示') === 'on') showBadge(saved);
  function sync(){
    set('apomi_収入', $('urnk-rev').value);
    set('apomi_時間', $('urnk-cap').value);
    var r = num($('urnk-rev').value), c = num($('urnk-cap').value);
    if (r > 0 && c > 0) $('urnk-rate').value = Math.round(r * 10000 / c);
  }
  $('urnk-rev').addEventListener('input', sync);
  $('urnk-cap').addEventListener('input', sync);
  $('urnk-open').addEventListener('click', function(){ $('urnk-panel').style.display = 'block'; });
  $('urnk-pclose').addEventListener('click', function(){
    $('urnk-panel').style.display = 'none';
    if (computed){ set('apomi_金額表示', 'on'); showBadge(num($('urnk-rate').value)); }
  });
  $('urnk-go').addEventListener('click', function(){
    var rate = num($('urnk-rate').value);
    if (!(rate > 0)){ alert('単価を入れてください。'); return; }
    set('apomi_単価', String(rate));
    $('urnk-res').innerHTML = '売れ残り 約<b>' + fmt(HOURS * rate) + '</b>' +
      '<span style="font-size:11.5px">' + PERIOD + '</span>';
    $('urnk-res').style.display = 'inline-block';
    computed = true;
  });
  $('urnk-close').addEventListener('click', function(){
    $('urnk-badge').style.display = 'none';
    set('apomi_金額表示', 'off');
  });
})();
</script>'''


def _dashboard(stats):
    if not stats:
        return ''
    total_cap = total_book = 0
    day_cards = []
    ranking = []
    for date in sorted(stats.keys()):
        slots = stats[date]
        cap, book, lcap, lbook = _day_summary(slots)
        total_cap += cap
        total_book += book
        pct = 100.0 * book / cap if cap else 100.0
        empty = cap - book
        cls = _fill_cls(pct)
        ranking.append((empty, date, pct))
        gap_rows = ''.join(_slot_row(s) for s in slots
                           if not s['lunch'] and s['book'] < s['cap'])
        lunch_rows = ''.join(_slot_row(s) for s in slots
                             if s['lunch'] and s['book'] < s['cap'])
        lunch_html = ''
        if lunch_rows:
            lunch_html = (f'<div class="lunch-sub">🍱 昼休み帯 {SETTINGS.lunch_window_text()}（交代休憩のため参考）'
                          f'<span class="lunch-note">空き {hours_txt(lcap - lbook)}</span></div>{lunch_rows}')
        body = gap_rows if gap_rows else '<div class="line">空き枠なし！完売です 🎉</div>'
        day_cards.append(
            f'<details class="day {cls}"><summary>'
            f'<span class="d-date">{esc(day_label(date))}</span>'
            f'<span class="d-bar"><span class="d-fill {cls}" style="width:{pct:.0f}%"></span></span>'
            f'<span class="d-pct {cls}">{pct:.0f}%</span>'
            f'<span class="d-empty">{"空き " + hours_txt(empty) if empty else "満枠✨"}</span>'
            f'</summary><div class="day-body">{body}{lunch_html}</div></details>')
    total_pct = 100.0 * total_book / total_cap if total_cap else 100.0
    total_empty = total_cap - total_book
    tcls = _fill_cls(total_pct)
    mood = {'good': 'party', 'mid': 'fly', 'bad': 'sad'}[tcls]
    dts = sorted(stats.keys())
    _short = lambda d: day_label(d).split('（')[0]
    urnk = (_URNK_TMPL
            .replace('__HOURS__', f'{total_empty * SLOT_MIN / 60:.2f}')
            .replace('__PERIOD__',
                     f'（{_short(dts[0])}〜{_short(dts[-1])}・実診療日{len(dts)}日分）'))
    ranking.sort(key=lambda x: -x[0])
    worst = [r for r in ranking[:3] if r[0] > 0]
    worst_html = ''
    if worst:
        worst_html = ('<div class="worst">🚩 空きが多い日: ' + '　'.join(
            f'<b>{esc(day_label(d))}</b> {hours_txt(e)}（{p:.0f}%）'
            for e, d, p in worst) + '</div>')
    return f'''
<h2>🈳 空き枠ダッシュボード <span class="sub">〜 予約枠は医院の在庫。売れ残りゼロを目指そう！〜</span></h2>
<div class="fillbox {tcls}">
  <div class="fill-main">
    <div class="fill-pct">{total_pct:.1f}<span class="pct-unit">%</span></div>
    <div class="fill-label">期間全体の予約埋まり率</div>
  </div>
  <div class="fill-detail">
    <div>🪑 埋まっている枠: <b>{hours_txt(total_book)}</b></div>
    <div>🕳️ 空いている枠（売れ残り）: <b>{hours_txt(total_empty)}</b>
      <span id="urnk-badge" class="urnk-badge" style="display:none">💴 売れ残り 約<b id="urnk-amt"></b><span id="urnk-p2" class="urnk-small"></span><span class="urnk-x" id="urnk-close" title="この表示を消す">✕</span></span>
      <span class="urnk-link" id="urnk-open">売れ残り金額の概算を計算する ⇨</span></div>
  </div>
  {apomi_img(mood, 'apomi apomi-fill')}
</div>
{urnk}
{worst_html}
<div class="days">{''.join(day_cards)}</div>'''

def _info_block(title, lines):
    t = re.sub(r'令和[\d.]+', lambda m: day_label(m.group(0)), title)
    if '初診連携' in t:
        emoji = '🤝'
    elif '飛び地' in t:
        emoji = '🧩'
    elif '相乗り' in t:
        emoji = '🪑'
    elif '特殊枠' in t:
        emoji = '🚑'
    else:
        emoji = 'ℹ️'
    body = ''.join(f'<div class="line">{esc(ln.strip())}</div>' for ln in lines)
    return (f'<details class="info"><summary>{emoji} {esc(t)}'
            f'<span class="badge">{len(lines)}</span></summary>'
            f'<div class="info-body">{body}</div></details>')

def render_html(recs, issues, infos, shift=None, stats=None,
                src_yoyaku='', src_shift='', auto=False):
    dates = sorted(set(r['予約日'] for r in recs)) or ['—']
    period = day_label(dates[0]) + (f' 〜 {day_label(dates[-1])}' if len(dates) > 1 else '')
    n_err = sum(1 for l, _, _ in issues if l == 'エラー')
    n_warn = sum(1 for l, _, _ in issues if l == '警告')
    n_note = sum(1 for l, _, _ in issues if l == '注意')

    if n_err == 0 and n_warn == 0 and n_note == 0:
        banner = (f'<div class="banner perfect">{apomi_img("perfect")}<div class="banner-txt">'
                  '<div class="big">🎉 予約ミスなし！</div>'
                  '<div>あとは空き枠チェック。下のダッシュボードへ！🦷✨</div></div></div>')
    elif n_err == 0:
        banner = (f'<div class="banner good">{apomi_img("normal")}<div class="banner-txt">'
                  f'<div class="big">😊 エラーはゼロ！</div>'
                  f'<div>確認しておきたい項目が {n_warn + n_note} 件あります。</div></div></div>')
    else:
        banner = (f'<div class="banner alert">{apomi_img("alert")}<div class="banner-txt">'
                  f'<div class="big">🔍 発見！ {n_err} 件</div>'
                  f'<div>修正が必要な予約がありそうです。カードをチェック！</div></div></div>')

    cards = []
    order = {'エラー': 0, '警告': 1, '注意': 2}
    for lv, cat, msg in sorted(issues, key=lambda x: order.get(x[0], 9)):
        emoji = CAT_EMOJI.get(cat, '🔔')
        cls = {'エラー': 'err', '警告': 'warn', '注意': 'note'}.get(lv, 'note')
        dm = re.match(r'(令和[\d.]+)\s*(.*)', msg, re.S)
        datebadge = f'<span class="date">{esc(day_label(dm.group(1)))}</span>' if dm else ''
        body = dm.group(2) if dm else msg
        cards.append(f'<div class="card {cls}"><div class="card-head">'
                     f'<span class="emoji">{emoji}</span><span class="cat">{esc(cat)}</span>'
                     f'{datebadge}<span class="lv lv-{cls}">{esc(lv)}</span></div>'
                     f'<div class="card-body">{esc(body).replace(chr(10), "<br>")}</div></div>')
    cards_html = ''.join(cards) if cards else '<div class="nocard">問題カードはありません 🎈</div>'

    dashboard = _dashboard(stats)
    # 空き枠はダッシュボードで表示するため、参考情報からは除外
    # 旧式の「空き枠一覧」はダッシュボードに置き換えたので出さない。
    # ただし「飛び地の空き枠」は独自情報なので表示する。
    other_infos = [(t, ls) for t, ls in infos
                   if '空き枠' not in t or '飛び地' in t]
    info_html = ''.join(_info_block(t, ls) for t, ls in other_infos)

    now = f'{datetime.datetime.now():%Y-%m-%d %H:%M}'
    autotxt = '（自動実行）' if auto else ''
    shift_chip = f'📋 シフト表: あり' if shift else '📋 シフト表: なし'

    return f'''<!DOCTYPE html>
<html lang="ja"><head><meta charset="utf-8">
<title>🦷 アポパトロール {esc(period)}</title>
<style>
  * {{ box-sizing: border-box; }}
  body {{ margin:0; font-family:'Segoe UI','Yu Gothic UI','Hiragino Sans',sans-serif;
         background:linear-gradient(160deg,#e0f7fa 0%,#fff3e0 100%); min-height:100vh; }}
  .wrap {{ max-width:900px; margin:0 auto; padding:24px 16px 60px; }}
  header {{ background:linear-gradient(135deg,#26c6da,#66bb6a); color:#fff;
            border-radius:20px; padding:22px 26px; box-shadow:0 6px 20px rgba(38,198,218,.35); }}
  header h1 {{ margin:0 0 6px; font-size:26px; }}
  .chips {{ display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }}
  .chip {{ background:rgba(255,255,255,.25); border-radius:999px; padding:4px 14px; font-size:13px; }}
  .banner {{ margin:18px 0; border-radius:20px; padding:16px 26px;
             box-shadow:0 4px 14px rgba(0,0,0,.08);
             display:flex; align-items:center; gap:22px; }}
  .banner-txt {{ flex:1; text-align:center; }}
  .banner .big {{ font-size:26px; font-weight:700; margin-bottom:6px; }}
  img.apomi {{ width:112px; height:112px; border-radius:50%; object-fit:cover;
               object-position:top; box-shadow:0 4px 12px rgba(0,0,0,.15);
               border:4px solid rgba(255,255,255,.8); flex-shrink:0; }}
  img.apomi-fill {{ width:96px; height:96px; margin-left:auto; }}
  .perfect {{ background:linear-gradient(135deg,#fff9c4,#c8e6c9); color:#2e7d32; }}
  .good    {{ background:linear-gradient(135deg,#e1f5fe,#fff9c4); color:#0277bd; }}
  .alert   {{ background:linear-gradient(135deg,#ffebee,#fff3e0); color:#c62828; }}
  .histbox {{ background:#fff; border:1.5px solid #cfe8dd; border-radius:16px;
    padding:16px 18px; margin:10px 4px 6px; }}
  .hist-nums {{ display:flex; gap:14px; flex-wrap:wrap; }}
  .hist-nums .hn {{ flex:1 1 120px; background:#f4fbf8; border-radius:12px;
    padding:10px 8px; text-align:center; }}
  .hist-nums .n {{ font-size:26px; font-weight:900; color:#1f7d5e; line-height:1.2; }}
  .hist-nums .t {{ font-size:12px; color:#5c7a6f; }}
  .hist-graph {{ margin-top:14px; }}
  .hbars {{ display:flex; align-items:flex-end; gap:4px; height:64px;
    padding:0 2px; border-bottom:2px solid #cfe8dd; }}
  .hb {{ flex:1 1 auto; background:linear-gradient(180deg,#7cc6a6,#2fa27a);
    border-radius:4px 4px 0 0; min-width:6px; }}
  .hist-note {{ font-size:12.5px; color:#5c7a6f; margin-top:6px; }}
  .hist-note .up {{ color:#1f7d5e; }} .hist-note .down {{ color:#c07a1b; }}
  .hist-foot {{ font-size:11.5px; color:#7c968c; margin-top:10px; line-height:1.7; }}
  .counts {{ display:flex; gap:12px; margin:14px 0 18px; }}
  .count {{ flex:1; background:#fff; border-radius:16px; padding:12px; text-align:center;
            box-shadow:0 3px 10px rgba(0,0,0,.06); }}
  .count .n {{ font-size:26px; font-weight:700; }}
  .count.err .n {{ color:#e53935; }} .count.warn .n {{ color:#fb8c00; }} .count.note .n {{ color:#8e24aa; }}
  .count .t {{ font-size:12px; color:#777; }}
  .card {{ background:#fff; border-radius:16px; padding:14px 18px; margin:10px 0;
           box-shadow:0 3px 10px rgba(0,0,0,.07); border-left:8px solid #ccc; }}
  .card.err  {{ border-left-color:#e53935; }}
  .card.warn {{ border-left-color:#fb8c00; }}
  .card.note {{ border-left-color:#8e24aa; }}
  .card-head {{ display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:6px; }}
  .card-head .emoji {{ font-size:22px; }}
  .card-head .cat {{ font-weight:700; }}
  .date {{ background:#eceff1; border-radius:999px; padding:2px 10px; font-size:12px; color:#546e7a; }}
  .lv {{ margin-left:auto; border-radius:999px; padding:2px 12px; font-size:12px; color:#fff; }}
  .lv-err {{ background:#e53935; }} .lv-warn {{ background:#fb8c00; }} .lv-note {{ background:#8e24aa; }}
  .card-body {{ color:#37474f; line-height:1.7; }}
  .nocard {{ text-align:center; color:#78909c; padding:14px; }}
  h2 {{ font-size:19px; color:#00695c; margin:30px 4px 12px; }}
  h2 .sub {{ font-size:12px; color:#80cbc4; font-weight:400; }}
  .fillbox {{ display:flex; align-items:center; gap:24px; background:#fff; border-radius:20px;
              padding:18px 26px; box-shadow:0 4px 14px rgba(0,0,0,.08); margin-bottom:10px;
              border-top:6px solid #ccc; flex-wrap:wrap; }}
  .fillbox.good {{ border-top-color:#43a047; }}
  .fillbox.mid  {{ border-top-color:#fb8c00; }}
  .fillbox.bad  {{ border-top-color:#e53935; }}
  .fill-pct {{ font-size:44px; font-weight:800; color:#00695c; line-height:1; }}
  .pct-unit {{ font-size:20px; }}
  .fill-label {{ font-size:12px; color:#78909c; margin-top:4px; }}
  .fill-detail {{ font-size:14px; color:#455a64; line-height:2; }}
  .worst {{ background:#fff3e0; border-radius:14px; padding:10px 18px; margin:10px 0;
            color:#e65100; font-size:14px; box-shadow:0 2px 8px rgba(0,0,0,.05); }}
  .urnk-link {{ font-size:12.5px; color:#1e88e5; cursor:pointer; text-decoration:underline;
                margin-left:8px; white-space:nowrap; }}
  .urnk-badge {{ display:inline-flex; align-items:center; gap:6px; background:#fff8e1;
                 border:1px solid #f0c36d; border-radius:10px; padding:2px 10px; margin-left:8px;
                 font-size:13px; color:#8a5a00; }}
  .urnk-badge b {{ font-size:15px; }}
  .urnk-small {{ font-size:11.5px; }}
  .urnk-x {{ cursor:pointer; color:#b08a3e; font-weight:700; margin-left:2px; }}
  .urnk-panel {{ background:#fff; border:1.5px solid #e2953b; border-radius:14px;
                 padding:14px 18px; margin:10px 0; font-size:13.5px; color:#455a64;
                 box-shadow:0 2px 8px rgba(0,0,0,.06); }}
  .urnk-panel input {{ width:100px; text-align:right; font-size:14px; padding:4px 6px;
                       border:1px solid #cfd8dc; border-radius:8px; }}
  .urnk-row {{ display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin:6px 0; }}
  .urnk-note {{ font-size:11px; color:#90a4ae; }}
  .urnk-sec {{ border-top:1px solid #eceff1; margin-top:10px; padding-top:10px; }}
  .urnk-go {{ background:#2fa27a; color:#fff; border:none; border-radius:10px;
              padding:8px 18px; font-size:14px; cursor:pointer; }}
  .urnk-res {{ display:none; background:#fff8e1; border-radius:10px; padding:6px 14px;
               margin-left:10px; color:#8a5a00; font-size:13.5px; }}
  .urnk-res b {{ font-size:18px; }}
  .urnk-head {{ display:flex; justify-content:space-between; align-items:center;
                font-weight:700; color:#37474f; margin-bottom:6px; }}
  .urnk-pclose {{ cursor:pointer; color:#90a4ae; font-size:16px; }}
  .days {{ margin-top:8px; }}
  details.day {{ background:#fff; border-radius:14px; margin:6px 0;
                 box-shadow:0 2px 8px rgba(0,0,0,.06); overflow:hidden; }}
  details.day summary {{ cursor:pointer; padding:10px 16px; list-style:none;
                         display:flex; align-items:center; gap:12px; }}
  details.day summary::-webkit-details-marker {{ display:none; }}
  .d-date {{ width:84px; font-weight:700; color:#37474f; }}
  .d-bar {{ flex:1; height:14px; background:#eceff1; border-radius:999px; overflow:hidden; }}
  .d-fill {{ display:block; height:100%; border-radius:999px; }}
  .d-fill.good {{ background:linear-gradient(90deg,#66bb6a,#26c6da); }}
  .d-fill.mid  {{ background:linear-gradient(90deg,#ffca28,#fb8c00); }}
  .d-fill.bad  {{ background:linear-gradient(90deg,#ef5350,#e53935); }}
  .d-pct {{ width:48px; text-align:right; font-weight:700; }}
  .d-pct.good {{ color:#43a047; }} .d-pct.mid {{ color:#fb8c00; }} .d-pct.bad {{ color:#e53935; }}
  .d-empty {{ width:110px; text-align:right; font-size:12px; color:#78909c; }}
  .day-body {{ padding:4px 18px 14px; border-top:1px dashed #eceff1; }}
  .lunch-sub {{ margin-top:10px; padding-top:8px; border-top:1px dashed #eceff1;
                font-size:13px; color:#8d6e63; font-weight:600; }}
  .lunch-note {{ font-weight:400; color:#bcaaa4; margin-left:8px; font-size:12px; }}
  details.info {{ background:#fff; border-radius:14px; margin:8px 0;
                  box-shadow:0 2px 8px rgba(0,0,0,.06); overflow:hidden; }}
  details.info summary {{ cursor:pointer; padding:12px 18px; font-weight:600; color:#37474f;
                          list-style:none; display:flex; align-items:center; gap:8px; }}
  details.info summary::-webkit-details-marker {{ display:none; }}
  .badge {{ background:#eceff1; color:#546e7a; border-radius:999px; padding:1px 10px; font-size:12px; }}
  .info-body {{ padding:4px 18px 14px; }}
  .line {{ font-size:13px; color:#455a64; padding:3px 0; }}
  .slot {{ display:flex; align-items:center; gap:10px; font-size:13px; padding:2px 0; }}
  .slot .time {{ width:96px; color:#607d8b; }}
  .dot.on  {{ color:#26c6da; }}
  .dot.off {{ color:#ffab91; }}
  .slot .cnt {{ color:#90a4ae; width:44px; }}
  .slot .free {{ color:#b0bec5; font-size:12px; }}
  footer {{ text-align:center; color:#90a4ae; font-size:12px; margin-top:30px; }}
  .qa-link {{ display:inline-block; background:#fff; color:#00695c; text-decoration:none;
              border-radius:999px; padding:8px 20px; font-size:13px; font-weight:600;
              margin-bottom:12px; box-shadow:0 2px 8px rgba(0,0,0,.08); }}
  .qa-link:hover {{ background:#e0f7fa; }}
</style></head><body><div class="wrap">
<header>
  <h1>🦷 アポパトロール結果</h1>
  <div class="chips">
    <span class="chip">📅 {esc(period)}</span>
    <span class="chip">🗂️ 予約 {len(recs)}件</span>
    <span class="chip">{shift_chip}</span>
    <span class="chip">🕐 {now} {autotxt}</span>
  </div>
</header>
{banner}
<div class="counts">
  <div class="count err"><div class="n">{n_err}</div><div class="t">エラー（要修正）</div></div>
  <div class="count warn"><div class="n">{n_warn}</div><div class="t">警告（要確認）</div></div>
  <div class="count note"><div class="n">{n_note}</div><div class="t">注意（参考）</div></div>
</div>
{cards_html}
{dashboard}
{history_block()}
<h2>📎 参考情報（正常な運用など）</h2>
{info_html}
<footer>
  <a class="qa-link" href="アポミちゃんのQ&amp;A.html">🦷 わからないことは「アポミちゃんのQ&amp;A」へ</a>
  <div>{esc(SETTINGS.clinic_name)} アポパトロール ｜ 予約一覧: {esc(src_yoyaku)} ｜ シフト表: {esc(src_shift) or 'なし'}</div>
</footer>
</div></body></html>'''
