# -*- coding: utf-8 -*-
"""apomi の更新パッケージ（zip）を受け取って、自分自身を新しくする。

なぜ必要か
----------
apomiは「フォルダの中の .py を差し替える」以外に新しくする手段が無かった。
そのため更新のたびに「apomiがどのフォルダにあるか」を人間が知る必要があり、
実際に受付PCで入れ先を間違える事故が起きた（2026-09-04）。
お客様（歯科医院の事務の方）に同じことをお願いするのは無理がある。

そこで「apomi_取込 に zip を入れるだけ」で更新できるようにする。
お客様はすでに毎日そのフォルダを使っているので、新しい手順を覚えなくてよい。

更新パッケージの形
------------------
  apomi更新_20260904.zip
    ├ apomi更新.json     ← 中身の一覧・版・署名
    ├ apo_patrol.py
    ├ apomi_settings.py
    └ ...（差し替えるファイル）

安全のために守っていること
--------------------------
* **医院ごとのファイルは絶対に上書きしない**（医院設定.json、ログイン情報、ライセンス、台帳）
* 置けるのは決まった拡張子だけ。フォルダを掘るような名前（.. や \\ 付き）は拒否する
* 中身のハッシュを1つずつ照合する（壊れたzipを弾く）
* 先に控えを取り、**全部成功したときだけ確定**。途中で失敗したら元に戻す

署名について
------------
**公開鍵方式（RSA-2048 + SHA-256）**を使う。
更新パッケージには apomi.exe そのものが入りうる＝「パッケージを作れる」は
「お客様のPCで好きなプログラムを動かせる」と同じ意味なので、共通鍵では足りない。

  ・このファイルに入っているのは**公開鍵**。検証しかできない（偽造には使えない）
  ・パッケージを作れるのは、**秘密鍵を持つ販売側の1台だけ**（apomi_署名鍵.json・社外秘）
  ・検証は pow() だけで書けるので、お客様側に追加のライブラリは要らない

これで「取り違え・壊れたzip」だけでなく「偽のパッケージ」も止められる。
"""
import hashlib
import io
import json
import os
import shutil
import zipfile

MANIFEST_NAME = 'apomi更新.json'
PACKAGE_PREFIX = 'apomi更新'

# 更新パッケージの署名を確かめるための公開鍵（2026-09-04 作成）
# ※ 公開鍵なので、配布物に入って構わない。秘密鍵は apomi_署名鍵.json（社外秘）。
PUBLIC_N = 28176709859150941902841769852578556954808389417324608171821363213751891502636590674191623346450103370058347175830112499966551370579973998180526349134564369542006564985346865856102137955598863518126159107485031034436555476059953319879663159504468216678800275840819026233147345102187280473484220908086355476196871827042018754392906528996979615581491299849629038220799278367525087299359905009462276239095561014617442815515266915565056796124595125597379751959237544267677286711065821800049949741348561644755558210916516345149052922855295278848029043417903427325515682556613416634299953982536459284678443330458322062130451
PUBLIC_E = 65537

# 置き換えてよい拡張子
# .exe は「1つにまとめた実行ファイル版」を丸ごと差し替えるために必要。
# ただし置けるのは EXE_NAME（apomi.exe）だけに絞る（_check_name 参照）。
ALLOWED_EXT = {'.py', '.html', '.txt', '.json', '.bat', '.command', '.exe', '.zip'}
EXE_NAME = 'apomi.exe'          # Windows版の本体
APP_NAME = 'apomi.app'          # Mac版の本体（中身がフォルダの塊）
APP_ARCHIVE = 'apomi.app.zip'   # Mac版はフォルダなので、zipのまま入れて中で展開する

# 医院ごとのファイル。更新で絶対に上書きしない
PROTECTED = {
    '医院設定.json',            # その医院の設定
    '.genifix_cred.xml',        # ログイン情報（DPAPI暗号化）
    '.apomi_license.json',      # ライセンス
    'apomi_メール設定.json',
    'ライセンス台帳.csv', 'ap台帳.csv', '返金台帳.csv',
    'apomi履歴.csv',            # これまでの記録
    '.watch_state.json',
}


class UpdateError(Exception):
    """更新できないときに投げる。メッセージはそのままお客様に見せる前提で書くこと。"""


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def manifest_body(version, files):
    """署名の対象になる文字列。並び順で結果が変わらないよう名前でソートする。"""
    return version + '\n' + '\n'.join(f'{k}:{files[k]}' for k in sorted(files))


# SHA-256 の DigestInfo（PKCS#1 v1.5）。ハッシュの種類を表す決まった前置き。
_SHA256_PREFIX = bytes.fromhex('3031300d060960864801650304020105000420')


def _pkcs1_encode(body, k):
    """PKCS#1 v1.5 の署名対象バイト列を作る（署名・検証で同じものを使う）。"""
    h = hashlib.sha256(body.encode('utf-8')).digest()
    t = _SHA256_PREFIX + h
    if k < len(t) + 11:
        raise UpdateError('鍵が短すぎます')
    return b'\x00\x01' + b'\xff' * (k - len(t) - 3) + b'\x00' + t


def verify_signature(version, files, sig_hex, n=None, e=None):
    """公開鍵で署名を確かめる。追加ライブラリは使わない（pow だけ）。"""
    n = n or PUBLIC_N
    e = e or PUBLIC_E
    k = (n.bit_length() + 7) // 8
    try:
        s = int(sig_hex, 16)
    except ValueError:
        return False
    if not (0 <= s < n):
        return False
    m = pow(s, e, n)
    got = m.to_bytes(k, 'big')
    return got == _pkcs1_encode(manifest_body(version, files), k)


def sign_manifest(version, files, d, n):
    """秘密鍵で署名する（販売側だけで使う）。"""
    k = (n.bit_length() + 7) // 8
    m = int.from_bytes(_pkcs1_encode(manifest_body(version, files), k), 'big')
    return format(pow(m, d, n), 'x').zfill(k * 2)


def _check_name(name):
    """置き換え先として安全な名前か。フォルダを掘る名前・想定外の拡張子を拒否する。"""
    if name != os.path.basename(name) or name in ('', '.', '..'):
        raise UpdateError(f'置き場所として使えない名前です: {name}')
    if '\\' in name or '/' in name or os.path.isabs(name):
        raise UpdateError(f'置き場所として使えない名前です: {name}')
    if os.path.splitext(name)[1].lower() not in ALLOWED_EXT:
        raise UpdateError(f'この種類のファイルは更新できません: {name}')
    if name.lower().endswith('.exe') and name != EXE_NAME:
        # 実行ファイルは apomi 本体だけ。他の名前の .exe は置かせない
        raise UpdateError(f'この実行ファイルは更新できません: {name}')
    if name.lower().endswith('.zip') and name != APP_ARCHIVE:
        # zip を許すのは Mac 本体の入れ物だけ（中身を展開するため）
        raise UpdateError(f'このzipは更新に使えません: {name}')
    if name in PROTECTED:
        raise UpdateError(f'この医院だけのファイルなので上書きしません: {name}')


def read_package(path):
    """zipを読み、中身を検証して (版, メモ, {名前: バイト列}) を返す。

    ここでは**ファイルを1つも書き換えない**（検証だけ）。
    """
    if not zipfile.is_zipfile(path):
        raise UpdateError('zipファイルとして開けませんでした（壊れている可能性があります）')
    with zipfile.ZipFile(path) as z:
        try:
            raw = z.read(MANIFEST_NAME)
        except KeyError:
            raise UpdateError('apomiの更新パッケージではありません（中身の一覧がありません）')
        try:
            man = json.loads(raw.decode('utf-8-sig'))
        except Exception:
            raise UpdateError('中身の一覧を読み取れませんでした')
        version = str(man.get('version') or '')
        note = str(man.get('note') or '')
        files = man.get('files')
        sig = str(man.get('sig') or '')
        if not version or not isinstance(files, dict) or not files:
            raise UpdateError('中身の一覧の形式が違います')
        if not verify_signature(version, files, sig):
            raise UpdateError('apomiが発行した更新パッケージではないようです（署名が合いません）')

        data = {}
        for name, want in files.items():
            _check_name(name)
            try:
                blob = z.read(name)
            except KeyError:
                raise UpdateError(f'パッケージの中に {name} が入っていません')
            if _sha256(blob) != want:
                raise UpdateError(f'{name} の中身が壊れています（ハッシュが合いません）')
            data[name] = blob
    return version, note, data


def apply_package(path, base, backup_root=None):
    """更新パッケージを base フォルダに適用する。

    戻り値: (版, メモ, 置き換えたファイル名の一覧, 控えフォルダのパス)
    途中で失敗したら**すべて元に戻して** UpdateError を投げる。
    """
    import datetime
    version, note, data = read_package(path)

    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup = os.path.join(backup_root or base, f'更新前の控え_{stamp}')
    os.makedirs(backup, exist_ok=True)

    written = []
    try:
        for name in sorted(data):
            dst = os.path.join(base, name)
            if os.path.exists(dst):
                shutil.copy2(dst, os.path.join(backup, name))
            tmp = dst + '.new'
            with open(tmp, 'wb') as f:
                f.write(data[name])
            os.replace(tmp, dst)      # 置き換えは最後の一瞬だけ（中途半端な状態を作らない）
            written.append(name)
    except Exception as e:
        # 1つでも失敗したら、書いた分をすべて戻す
        for name in written:
            src = os.path.join(backup, name)
            dst = os.path.join(base, name)
            try:
                if os.path.exists(src):
                    shutil.copy2(src, dst)
                else:
                    os.remove(dst)    # もともと無かったファイル
            except OSError:
                pass
        for junk in (os.path.join(base, n + '.new') for n in data):
            try:
                os.remove(junk)
            except OSError:
                pass
        raise UpdateError(f'更新の途中で失敗したため、元に戻しました（{e}）')

    return version, note, written, backup


def apply_exe(path, exe_path):
    """「1つにまとめた実行ファイル版」を丸ごと差し替える。

    Windowsは**実行中のexeを消したり上書きしたりできないが、名前は変えられる**。
    その性質を使って、動いたまま入れ替える。

      ① 今のexeを apomi.exe.old_日時 にリネーム（＝場所が空く）
      ② 新しいexeを apomi.exe として書く
      ③ 呼び出し側が起動しなおす（古い方は次回起動時に掃除する）

    失敗したら①を戻すので、apomiが消えることはない。
    ショートカットやスタートアップは「apomi.exe」を指したままなので、張り替え不要。
    """
    import datetime
    version, note, data = read_package(path)
    if EXE_NAME not in data:
        raise UpdateError('このパッケージに apomi.exe が入っていません')

    folder = os.path.dirname(os.path.abspath(exe_path))
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    old = os.path.join(folder, f'{EXE_NAME}.old_{stamp}')

    try:
        os.replace(exe_path, old)          # ① 動いたままでも名前は変えられる
    except OSError as e:
        raise UpdateError(f'今のapomiを退避できませんでした（{e}）')
    try:
        tmp = exe_path + '.new'
        with open(tmp, 'wb') as f:         # ② 新しいexeを置く
            f.write(data[EXE_NAME])
        os.replace(tmp, exe_path)
    except Exception as e:
        try:
            os.replace(old, exe_path)      # 失敗したら元に戻す
        except OSError:
            pass
        for junk in (exe_path + '.new',):
            try:
                os.remove(junk)
            except OSError:
                pass
        raise UpdateError(f'新しいapomiを置けませんでした。元に戻しました（{e}）')

    return version, note, [EXE_NAME], old


def cleanup_old_exe(folder):
    """前回の更新で残った apomi.exe.old_* を掃除する（起動時に呼ぶ）。

    更新直後は古いexeがまだ動いているので消せない。次の起動なら消せる。
    """
    import glob as _glob
    removed = []
    for p in _glob.glob(os.path.join(folder, EXE_NAME + '.old_*')):
        try:
            os.remove(p)
            removed.append(os.path.basename(p))
        except OSError:
            pass      # まだ使用中なら、次の機会に消す
    return removed


def apply_app(path, app_path, run=None):
    """Mac版（apomi.app）を丸ごと差し替える。

    Windowsのexeと考え方は同じ（今のものを別名にして、空いた場所に新しいものを置く）。
    Macならではの注意が3つある。

    ① apomi.app は**フォルダの塊**なので、1ファイルとして書けない。
       パッケージには ditto で作った zip をそのまま入れておき、ここで展開する。
    ② 展開は必ず **ditto** を使う。Pythonのzip展開だと
       「実行できる印」と署名まわりが壊れて、アプリが開けなくなる。
    ③ ネットから落ちてきたファイルには macOS が「隔離の印」を付ける。
       付いたままだと『"apomi" は開いていません』と出て、
       しかも既定のボタンが**「ゴミ箱に入れる」**なので極めて危険。
       展開したあとに印を外す（2026-09-05 福島さんのMacで実機確認）。

    run … 外部コマンドの実行関数（テストで差し替えられるようにしている）
    """
    import datetime
    import subprocess
    import tempfile

    run = run or (lambda args: subprocess.run(args, capture_output=True))
    version, note, data = read_package(path)
    if APP_ARCHIVE not in data:
        raise UpdateError('このパッケージに apomi.app が入っていません')

    folder = os.path.dirname(os.path.abspath(app_path))
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    old = os.path.join(folder, f'{APP_NAME}.old_{stamp}')

    tmpzip = os.path.join(tempfile.gettempdir(), f'apomi_app_{stamp}.zip')
    with open(tmpzip, 'wb') as f:
        f.write(data[APP_ARCHIVE])

    try:
        os.rename(app_path, old)       # ① 動いたままでも名前は変えられる（実機確認済み）
    except OSError as e:
        raise UpdateError(f'今のapomiを退避できませんでした（{e}）')

    try:
        r = run(['ditto', '-x', '-k', tmpzip, folder])     # ② 必ず ditto で展開
        if getattr(r, 'returncode', 1) != 0:
            raise OSError('ditto での展開に失敗しました')
        if not os.path.isdir(app_path):
            raise OSError('展開しても apomi.app ができませんでした')
        # ③ 「落としてきた印」を外す。これをしないと開けない
        run(['xattr', '-dr', 'com.apple.quarantine', app_path])
    except Exception as e:
        shutil.rmtree(app_path, ignore_errors=True)
        try:
            os.rename(old, app_path)   # 失敗したら元に戻す
        except OSError:
            pass
        raise UpdateError(f'新しいapomiを置けませんでした。元に戻しました（{e}）')
    finally:
        try:
            os.remove(tmpzip)
        except OSError:
            pass

    return version, note, [APP_NAME], old


def cleanup_old_app(folder):
    """前回の更新で残った apomi.app.old_* を掃除する（起動時に呼ぶ）。"""
    import glob as _glob
    removed = []
    for p in _glob.glob(os.path.join(folder, APP_NAME + '.old_*')):
        try:
            shutil.rmtree(p)
            removed.append(os.path.basename(p))
        except OSError:
            pass      # まだ使用中なら、次の機会に消す
    return removed


def build_package(base, names, version, note, out_path, privkey):
    """更新パッケージを作る（販売側で使う）。

    names   … 入れるファイル名の一覧（base 直下のファイル名だけ）
    privkey … {'n':…, 'd':…}（apomi_署名鍵.json の中身・社外秘）
    """
    files, blobs = {}, {}
    for name in names:
        _check_name(name)
        p = os.path.join(base, name)
        if not os.path.exists(p):
            raise UpdateError(f'{name} が見つかりません')
        with open(p, 'rb') as f:
            blob = f.read()
        blobs[name] = blob
        files[name] = _sha256(blob)

    man = {
        'version': version,
        'note': note,
        'files': files,
        'sig': sign_manifest(version, files, int(privkey['d']), int(privkey['n'])),
    }
    with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr(MANIFEST_NAME,
                   json.dumps(man, ensure_ascii=False, indent=2).encode('utf-8'))
        for name, blob in blobs.items():
            z.writestr(name, blob)
    return out_path
