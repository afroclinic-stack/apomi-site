# -*- coding: utf-8 -*-
"""専用フォルダ（デスクトップの「apomi_取込」）を監視し、そこにCSVまたはPDFが
保存されたら、自動でアポパトロールを実行して結果をブラウザで開く常駐プログラム。
処理し終わったファイルは「済み」フォルダに移動する。
毎朝、その日にチェックすべき期間（1週間/1か月/4か月先）のお知らせも表示する。

スタートアップに登録して使う（PC起動時に自動開始）。
停止したいときは watch_stop.bat を実行する。
"""
import os, sys, re, glob, json, time, datetime, socket, traceback, shutil

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
from apomi_paths import data_dir, bundle_dir
BASE = data_dir()          # 結果HTML・ログ・状態ファイルの置き場所
from parse_genifix import parse_pdf, clean
from parse_shift import (parse_shift, is_apotool_shift, parse_apotool_shift,
                         parse_off_memo, apply_off_memo)
from apo_patrol import patrol
import report_html
from report_html import render_html, WEEKDAYS, apomi_img
import apomi_import as imp
import apomi_update as upd

from apomi_paths import desktop_dir, open_path, IS_FROZEN
DESKTOP = desktop_dir()
INBOX = os.path.join(DESKTOP, 'apomi_取込')       # ここにCSV/PDFを保存してもらう
DONE_DIR = os.path.join(INBOX, '済み')             # 処理済みはここへ移動
ERROR_DIR = os.path.join(INBOX, 'エラー')          # 読めなかったファイルはここへ
STATE_FILE = os.path.join(BASE, '.watch_state.json')
LOG_FILE = os.path.join(BASE, 'watch_log.txt')
POLL_SEC = 5

def ensure_inbox():
    os.makedirs(INBOX, exist_ok=True)
    os.makedirs(DONE_DIR, exist_ok=True)
    # フォルダの使い方をひとことメモとして置いておく
    readme = os.path.join(INBOX, 'このフォルダについて.txt')
    if not os.path.exists(readme):
        try:
            with open(readme, 'w', encoding='utf-8-sig') as f:
                f.write(
                    '🦷 apomi（アポミ）の 予約一覧おきば\n'
                    '━━━━━━━━━━━━━━━━━━━━━━━━\n'
                    '\n'
                    '【ここに入れるもの】\n'
                    '  予約システムから書き出した「予約一覧」\n'
                    '  （CSV・Excel・PDF）\n'
                    '\n'
                    '【入れたあと】\n'
                    '  何もしなくて大丈夫です。\n'
                    '  数秒で自動チェックが走り、結果がブラウザで開きます。\n'
                    '\n'
                    '【設定を変えたいとき】\n'
                    '  設定画面で保存した「医院設定.json」も、ここに入れるだけでOK。\n'
                    '  自動で新しい設定に切り替わります。\n'
                    '\n'
                    '【シフト表を入れると、もっと見つかる】\n'
                    '  予約システムから書き出したシフト表CSV（アポツール対応）を\n'
                    '  ここに入れると、「担当が休みなのに予約が入っている」\n'
                    '  「休診日に予約」も自動で見つけます。月が替わったら新しい月の分を。\n'
                    '\n'
                    '【有給などの臨時休】\n'
                    '  「お休みメモ.txt」に 1行ずつ「8/15 桑野 有給」のように書いて\n'
                    '  ここに入れると、その日その人は休み扱いでチェックします。\n'
                    '\n'
                    '【フォルダの意味】\n'
                    '  済み   … チェックが終わったファイル\n'
                    '  エラー … 読み取れなかったファイル\n'
                    '           （そのとき案内のページが開きます）\n'
                    '\n'
                    '※ このメモは消してしまっても問題ありません。\n')
        except OSError:
            pass

# ===== 設定画面・医院設定の自動化 =====
# ①設定画面HTMLは、開いた瞬間から「今の設定」が表示されるよう毎回作り直す
# ②取り込みフォルダに 医院設定*.json が置かれたら自動で適用する（再起動不要）

def refresh_settings_page():
    """今の医院設定を埋め込んだ設定画面HTMLを作り直す。
    テンプレートの /*PRELOAD*/ null /*PRELOAD_END*/ を実際の設定JSONに差し替える。"""
    src = os.path.join(bundle_dir(), 'apomi設定画面.html')
    dst = os.path.join(BASE, 'apomi設定画面.html')
    try:
        with open(src, encoding='utf-8') as f:
            html = f.read()
    except OSError:
        return
    inj = 'null'
    try:
        with open(os.path.join(BASE, '医院設定.json'), encoding='utf-8-sig') as f:
            inj = json.dumps(json.load(f), ensure_ascii=False)
    except Exception:
        pass
    new = re.sub(r'/\*PRELOAD\*/.*?/\*PRELOAD_END\*/',
                 lambda m: '/*PRELOAD*/ ' + inj + ' /*PRELOAD_END*/',
                 html, count=1, flags=re.S)
    if new != html or not os.path.exists(dst):
        try:
            with open(dst, 'w', encoding='utf-8') as f:
                f.write(new)
        except OSError:
            pass


def _config_applied_html(cfg, backup_name):
    name = cfg.get('clinic_name') or '（医院名未設定）'
    checks = [('staff_double_booking', '担当者のダブルブッキング'),
              ('closed_day_booking', '休診日に予約'),
              ('shoshin_link', '初診連携'),
              ('chair_buffer', '予約間のバッファ'),
              ('isolated_gap', '飛び地の空き枠'),
              ('chair_balance', 'チェア稼働の偏り')]
    ons = [label for key, label in checks
           if isinstance(cfg.get(key), dict) and cfg[key].get('enabled')]
    onstxt = '・'.join(ons) if ons else '（追加ルールはすべてオフ）'
    return f'''<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>apomi ｜ 設定を更新しました</title><style>
 body{{font-family:-apple-system,"Hiragino Kaku Gothic ProN","Yu Gothic",Meiryo,sans-serif;
   color:#274b40;margin:0;line-height:1.9;background:linear-gradient(180deg,#eefaf6,#fff)}}
 .wrap{{max-width:620px;margin:0 auto;padding:34px 18px 60px;text-align:center}}
 .card{{background:#fff;border:2px solid #7cc6a6;border-radius:20px;padding:26px 22px}}
 h1{{font-size:22px;color:#1f7d5e;margin:8px 0}}
 p{{font-size:14.5px}}
 .box{{background:#f7faf9;border:1px solid #cfe8dd;border-radius:12px;padding:10px 14px;
   font-size:13.5px;text-align:left;margin-top:12px}}
</style></head><body><div class="wrap"><div class="card">
<div style="font-size:44px">⚙️</div>
<h1>設定を更新しました</h1>
<p><b>{name}</b> の新しい設定に切り替えました。<br>再起動は不要です。次のチェックから反映されます。</p>
<div class="box">✅ 有効になっている追加ルール：<br>{onstxt}</div>
<div class="box">🗂️ 前の設定は「{backup_name}」として保存してあります。<br>
元に戻したいときは、そのファイルの名前を「医院設定.json」に戻して、もう一度 apomi_取込 に入れてください。</div>
</div></div></body></html>'''


def _restart_self():
    """新しいコードを読み込むため、自分を起動しなおして終わる。

    実行中のプロセスは古いコードを抱えたままなので、更新後は必ず入れ替える。
    """
    import subprocess
    try:
        if IS_FROZEN:
            args = [sys.executable]
        else:
            args = [sys.executable, '-X', 'utf8', os.path.abspath(__file__)]
        subprocess.Popen(args, close_fds=True)
        log('新しいコードで起動しなおします')
    except Exception:
        log(f'起動しなおしに失敗:\n{traceback.format_exc()}')
        return
    os._exit(0)   # 二重起動防止のポートを確実に手放すため、後始末をせず終わる


def _update_done_html(version, note, names, backup):
    lines = ''.join(f'<li>{n}</li>' for n in names)
    return (
        '<!doctype html><html lang="ja"><head><meta charset="utf-8">'
        '<title>apomi ｜ 新しくなりました</title></head>'
        '<body style="font-family:sans-serif;max-width:640px;margin:40px auto;line-height:1.9">'
        '<h2>🎉 apomi が新しくなりました</h2>'
        f'<p><b>版：{version}</b></p>'
        + (f'<p>{note}</p>' if note else '')
        + '<p>入れ替えたファイル：</p><ul style="font-size:14px">' + lines + '</ul>'
        '<p>apomiは自動で起動しなおしました。<b>このまま今までどおりお使いください。</b></p>'
        f'<p style="font-size:13px;color:#666">※ 念のため、更新前の控えを '
        f'<b>{os.path.basename(backup)}</b> に残してあります。'
        '問題がなければ、そのまま置いておいて構いません'
        '（実行ファイル版は、次に起動したときに自動で片づきます）。</p>'
        '</body></html>')


def maybe_apply_update_drop():
    """取り込みフォルダに置かれた apomi更新*.zip を適用する。処理したら True。

    お客様は「apomi_取込 に入れるだけ」でよい（apomiの置き場所を知らなくてよい）。
    """
    cands = sorted(glob.glob(os.path.join(INBOX, upd.PACKAGE_PREFIX + '*.zip')),
                   key=os.path.getmtime)
    cands = [c for c in cands if is_stable(c)]
    if not cands:
        return False
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    for old in cands[:-1]:
        move_file(old, DONE_DIR, stamp)
        log(f'更新パッケージが複数あったため古い方はスキップ: {old}')
    path = cands[-1]

    try:
        if IS_FROZEN:
            # 1つにまとめた実行ファイル版は、apomi.exe を丸ごと差し替える
            version, note, names, backup = upd.apply_exe(path, sys.executable)
        else:
            # ファイルが分かれている版は、.py などを差し替える
            version, note, names, backup = upd.apply_package(
                path, bundle_dir(), backup_root=BASE)
    except upd.UpdateError as e:
        move_file(path, ERROR_DIR, stamp)
        _simple_notice('更新できませんでした',
                       '<h2>⚠️ 更新できませんでした</h2>'
                       f'<p>{e}</p>'
                       '<p>apomiは<b>今までどおり動いています</b>。'
                       'ファイルは「エラー」フォルダに移してあります。</p>'
                       '<p>お手数ですが、もう一度ダウンロードしてお試しください。<br>'
                       'うまくいかないときは <b>apomi.dental@gmail.com</b> までどうぞ'
                       '（返信は平日・2営業日以内が目安）。</p>', stamp)
        log(f'更新の適用失敗: {path}\n{traceback.format_exc()}')
        return True
    except Exception:
        move_file(path, ERROR_DIR, stamp)
        log(f'更新の適用で想定外のエラー: {path}\n{traceback.format_exc()}')
        return True

    move_file(path, DONE_DIR, stamp)
    log(f'apomiを更新しました（版 {version} / {len(names)}ファイル）')
    out = os.path.join(BASE, f'新しくなりました_{stamp}.html')
    try:
        with open(out, 'w', encoding='utf-8-sig') as f:
            f.write(_update_done_html(version, note, names, backup))
        open_path(out)
    except OSError:
        pass
    _restart_self()
    return True


def maybe_apply_config_drop():
    """取り込みフォルダに置かれた 医院設定*.json を適用する。処理したら True。
    「医院設定 (1).json」のようにブラウザが名前を変えていても受け付ける。"""
    cands = sorted(glob.glob(os.path.join(INBOX, '医院設定*.json')), key=os.path.getmtime)
    cands = [c for c in cands if is_stable(c)]
    if not cands:
        return False
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    for old in cands[:-1]:   # 複数あるときは一番新しいものだけ使う
        move_file(old, DONE_DIR, stamp)
        log(f'医院設定が複数あったため古い方はスキップ: {old}')
    path = cands[-1]
    try:
        with open(path, encoding='utf-8-sig') as f:
            cfg = json.load(f)
        if not isinstance(cfg, dict) or 'chair_groups' not in cfg:
            raise ValueError('医院設定の形式ではありません（chair_groups がありません）')
    except Exception:
        log(f'医院設定の適用失敗: {path}\n{traceback.format_exc()}')
        move_file(path, ERROR_DIR, stamp)
        out = os.path.join(BASE, f'設定エラー_{stamp}.html')
        body = ('<!doctype html><html lang="ja"><head><meta charset="utf-8">'
                '<title>apomi ｜ 設定ファイルを読み取れませんでした</title></head>'
                '<body style="font-family:sans-serif;max-width:600px;margin:40px auto;line-height:1.9">'
                '<h2>⚠️ 設定ファイルを読み取れませんでした</h2>'
                '<p>apomi_取込 に入れた 医院設定.json が壊れているか、設定ファイルではないようです。<br>'
                'ファイルは「エラー」フォルダに移してあります。設定は<b>今まで通りのまま</b>です。</p>'
                '<p>もう一度、設定画面の「設定ファイルを保存」からやり直してみてください。<br>'
                'うまくいかないときはメールでどうぞ：<b>apomi.dental@gmail.com</b>'
                '（返信は平日・2営業日以内が目安）</p></body></html>')
        try:
            with open(out, 'w', encoding='utf-8-sig') as f:
                f.write(body)
            open_path(out)
        except OSError:
            pass
        return True
    dstcfg = os.path.join(BASE, '医院設定.json')
    backup_name = f'医院設定_backup_{stamp}.json'
    if os.path.exists(dstcfg):
        try:
            shutil.copy2(dstcfg, os.path.join(BASE, backup_name))
        except OSError:
            backup_name = '（バックアップ失敗）'
    try:
        shutil.copy2(path, dstcfg)     # 名前が違っていても正しい名前で配置される
    except OSError:
        log(f'医院設定の書き込みに失敗: {traceback.format_exc()}')
        return True
    move_file(path, DONE_DIR, stamp)
    try:
        import apomi_settings as st
        st.reload()                    # 稼働中のチェックに即反映（再起動不要）
    except Exception:
        log(f'設定の再読込に失敗（次回起動時に反映されます）:\n{traceback.format_exc()}')
    refresh_settings_page()
    out = os.path.join(BASE, f'設定更新のお知らせ_{stamp}.html')
    try:
        with open(out, 'w', encoding='utf-8-sig') as f:
            f.write(_config_applied_html(cfg, backup_name))
        open_path(out)
    except OSError:
        pass
    log(f'医院設定を更新しました（{cfg.get("clinic_name", "")}）')
    return True


SHIFT_STORE = 'シフト表_取込.csv'      # 取り込んだシフト表の保存名（BASE直下）
OFFMEMO_STORE = '臨時休メモ.txt'       # 取り込んだ臨時休メモの保存名


def _is_special_name(fn):
    """予約一覧ではない特別ファイル（シフト表・臨時休メモ）か"""
    low = fn.lower()
    return ('shift' in low or 'シフト' in fn or '休み' in fn or '臨時休' in fn)


def _simple_notice(title, body_html, stamp):
    out = os.path.join(BASE, f'{title}_{stamp}.html')
    html = (f'<!doctype html><html lang="ja"><head><meta charset="utf-8">'
            f'<title>apomi ｜ {title}</title></head>'
            f'<body style="font-family:sans-serif;max-width:640px;margin:40px auto;line-height:2">'
            f'{body_html}</body></html>')
    try:
        with open(out, 'w', encoding='utf-8-sig') as f:
            f.write(html)
        open_path(out)
    except OSError:
        pass


def maybe_apply_shift_drop():
    """取り込みフォルダに置かれたシフト表CSV（アポツール等）を登録する。処理したらTrue"""
    cands = [p for p in glob.glob(os.path.join(INBOX, '*.csv'))
             if _is_special_name(os.path.basename(p))
             and ('休み' not in os.path.basename(p)) and ('臨時休' not in os.path.basename(p))
             and is_stable(p)]
    if not cands:
        return False
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    path = max(cands, key=os.path.getmtime)
    try:
        text = imp._read_text(path, 'utf-8-sig')
        if not is_apotool_shift(text):
            raise ValueError('シフト表の形式を認識できませんでした')
        sh = parse_apotool_shift(text)
    except Exception:
        log(f'シフト表の取り込み失敗: {path}\n{traceback.format_exc()}')
        move_file(path, ERROR_DIR, stamp)
        _simple_notice('シフト表エラー',
            '<h2>⚠️ シフト表を読み取れませんでした</h2>'
            '<p>ファイルは「エラー」フォルダに移してあります。予約チェックは今まで通り動きます。<br>'
            'アポツールの「シフト表」画面から書き出したCSVをそのまま入れてください。<br>'
            'うまくいかないときはメールでどうぞ：<b>apomi.dental@gmail.com</b>'
            '（返信は平日・2営業日以内が目安）</p>', stamp)
        return True
    try:
        shutil.copy2(path, os.path.join(BASE, SHIFT_STORE))
    except OSError:
        log(f'シフト表の保存に失敗:\n{traceback.format_exc()}')
        return True
    move_file(path, DONE_DIR, stamp)
    n_staff = len({s['name'] for v in sh['byDate'].values() for s in v})
    _simple_notice('シフト表を取り込みました',
        f'<h2>🗓️ シフト表を取り込みました</h2>'
        f'<p><b>{sh["year"]}年{sh["month"]}月分・スタッフ{n_staff}名</b>の出勤情報を登録しました。<br>'
        f'これからのチェックでは、<b>「担当が休みなのに予約が入っている」「休診日に予約」</b>も自動で見ます。</p>'
        f'<p>📌 次にすること：特にありません。いつも通り予約一覧を入れるだけでOKです。<br>'
        f'月が替わったら、新しい月のシフト表をまたこのフォルダに入れてください。<br>'
        f'有給などの臨時休は「臨時休メモ」（Q&A参照）で伝えられます。</p>', stamp)
    log(f'シフト表を取り込み: {sh["year"]}年{sh["month"]}月 {n_staff}名')
    return True


def maybe_apply_offmemo_drop():
    """取り込みフォルダに置かれた臨時休メモ（.txt/.csv）を登録する。処理したらTrue"""
    cands = [p for p in glob.glob(os.path.join(INBOX, '*'))
             if os.path.isfile(p)
             and (('休み' in os.path.basename(p)) or ('臨時休' in os.path.basename(p)))
             and p.lower().endswith(('.txt', '.csv'))
             and is_stable(p)]
    if not cands:
        return False
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    path = max(cands, key=os.path.getmtime)
    try:
        memo = parse_off_memo(imp._read_text(path, 'utf-8-sig'))
        if not memo:
            raise ValueError('読める行がありません')
    except Exception:
        log(f'臨時休メモの取り込み失敗: {path}\n{traceback.format_exc()}')
        move_file(path, ERROR_DIR, stamp)
        _simple_notice('臨時休メモエラー',
            '<h2>⚠️ 臨時休メモを読み取れませんでした</h2>'
            '<p>1行に「日付 名前 理由」の順で書いてください（理由は省略OK）。<br>'
            '例：<b>8/15 桑野 有給</b><br>'
            'ファイルは「エラー」フォルダに移してあります。</p>', stamp)
        return True
    try:
        shutil.copy2(path, os.path.join(BASE, OFFMEMO_STORE))
    except OSError:
        return True
    move_file(path, DONE_DIR, stamp)
    lines = ''.join(f'<li>{e["date"]}　{e["name"]}　{e["reason"]}</li>' for e in memo[:20])
    _simple_notice('臨時休メモを取り込みました',
        f'<h2>📝 臨時休メモを取り込みました（{len(memo)}件）</h2>'
        f'<ul>{lines}</ul>'
        f'<p>この日付・この人は「お休み」としてチェックします（シフト表より優先）。<br>'
        f'📌 追加・変更したいときは、メモのファイルを直して、もう一度このフォルダに入れるだけです。</p>', stamp)
    log(f'臨時休メモを取り込み: {len(memo)}件')
    return True


def load_extra_shift():
    """取り込み済みのシフト表（＋臨時休メモ）を出勤情報として返す。無ければNone"""
    p = os.path.join(BASE, SHIFT_STORE)
    if not os.path.exists(p):
        return None
    try:
        sh = parse_apotool_shift(imp._read_text(p, 'utf-8-sig'))
    except Exception:
        log(f'保存済みシフト表の読み込み失敗:\n{traceback.format_exc()}')
        return None
    mp = os.path.join(BASE, OFFMEMO_STORE)
    if os.path.exists(mp):
        try:
            sh = apply_off_memo(sh, parse_off_memo(imp._read_text(mp, 'utf-8-sig')))
        except Exception:
            log(f'臨時休メモの適用失敗:\n{traceback.format_exc()}')
    return sh


def maybe_reload_config(state):
    """医院設定.json が直接書き換えられたとき（設定画面の上書き保存など）も、
    再起動なしで新しい設定に切り替える。"""
    p = os.path.join(BASE, '医院設定.json')
    try:
        mtime = os.path.getmtime(p)
    except OSError:
        return
    if state.get('cfg_mtime') == mtime:
        return
    first = 'cfg_mtime' not in state
    state['cfg_mtime'] = mtime
    save_state(state)
    if first:
        return                          # 初回は記録するだけ
    try:
        import apomi_settings as st
        st.reload()
        refresh_settings_page()
        log('医院設定の変更を検知し、再読込しました')
    except Exception:
        log(f'設定の再読込に失敗:\n{traceback.format_exc()}')


def choose_import_config():
    """CSV取り込みに使う設定を選ぶ。先頭が「_」の見本は除外。
    有効な設定が1つだけならそれを使う。複数あるときは state の import_config で指定。"""
    cfgs = [(n, p) for (n, p) in imp.list_configs()
            if not os.path.basename(p).startswith('_')]
    if len(cfgs) == 1:
        return cfgs[0][1]
    if cfgs:
        want = load_state().get('import_config')
        for n, p in cfgs:
            if os.path.basename(p) == want:
                return p
        return cfgs[0][1]
    return None

# ===== 毎朝のチェックお知らせ =====
# 1週間先=毎診療日 / 1か月先=毎週・週初めの診療日 / 4か月先=毎月・月初の診療日
REMIND_HOUR = 8           # この時刻以降、その日まだチェックしていなければお知らせを出す
CLOSED_WEEKDAYS = (2, 6)  # シフト表が読めないときの休診日フォールバック（水曜=2, 日曜=6）

def log(msg):
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f'{datetime.datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n')

def load_state():
    try:
        with open(STATE_FILE, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def save_state(state):
    with open(STATE_FILE, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False)

def file_sig(path):
    st = os.stat(path)
    return [st.st_size, int(st.st_mtime)]

def is_stable(path):
    """書き込み途中でないか（2秒おいてサイズが変わらないか）"""
    try:
        s1 = os.path.getsize(path)
        time.sleep(2)
        s2 = os.path.getsize(path)
        return s1 == s2 and s2 > 0
    except OSError:
        return False

def newest(pattern):
    files = glob.glob(os.path.join(DESKTOP, pattern))
    return max(files, key=os.path.getmtime) if files else None

def load_records(path):
    """取り込みファイル（CSVまたはPDF）を共通レコード形式に読み込む。
    戻り値: (records, 読み込み元の表示名)"""
    ext = os.path.splitext(path)[1].lower()
    if ext in ('.csv', '.xls', '.xlsx', '.xlsm'):
        # EPARK歯科台帳のExcelは専用の読み方をする（結合セルの行数＝所要時間）。
        # 見分けに失敗したときは、下の「取り込み設定」での読み取りに落ちるだけ。
        import parse_epark
        if parse_epark.looks_like_epark_excel(path):
            recs = parse_epark.clean(parse_epark.parse_excel(path))
            if recs:
                return recs, 'EPARK歯科台帳（' + os.path.basename(path) + '）'
        cfg_path = choose_import_config()
        if not cfg_path:
            raise RuntimeError('取り込み設定が見つかりません。'
                               '「取り込み設定」フォルダにお使いのシステムの設定(JSON)を置いてください。')
        cfg = imp.load_config(cfg_path)
        return imp.read_any(path, cfg), cfg.get('name', os.path.basename(path))
    # PDFは書式を自動で見分ける（Genifixの表形式 / EPARK歯科台帳のカレンダー形式）
    import parse_epark
    if parse_epark.looks_like_epark(path):
        recs = parse_epark.clean(parse_epark.parse_pdf(path))
        if recs:
            return recs, 'EPARK歯科台帳（' + os.path.basename(path) + '）'
    return clean(parse_pdf(path)), os.path.basename(path)

def move_file(path, folder, stamp):
    try:
        os.makedirs(folder, exist_ok=True)
        shutil.move(path, os.path.join(folder, f'{stamp}_{os.path.basename(path)}'))
    except OSError:
        pass  # 移動できなくても処理自体は続行

def license_gate(force_notice=False):
    """ライセンス上、チェックを実行してよいか。
    停止中なら案内ページを開いて False（自動監視では1日1回だけ、手動実行では毎回）。"""
    try:
        import apomi_license as lic
        s = lic.status()
    except Exception:
        return True
    if s['state'] != 'stopped':
        return True
    state = load_state()
    today = datetime.date.today().isoformat()
    if force_notice or state.get('license_notice_day') != today:
        state['license_notice_day'] = today
        save_state(state)
        out = os.path.join(BASE, '使用期限のお知らせ.html')
        try:
            with open(out, 'w', encoding='utf-8-sig') as f:
                f.write(lic.notice_page_html(s))
            open_path(out)
        except OSError:
            pass
        log('ライセンス停止中: チェックをお休みしています')
    return False


def process(path):
    stamp = f'{datetime.datetime.now():%Y%m%d_%H%M%S}'
    if not license_gate():
        return   # ファイルは動かさない（再開後にそのまま処理される）
    try:
        # 出勤情報: ①取り込んだシフト表（＋臨時休メモ） ②デスクトップの勤務予定表PDF の順
        shift = load_extra_shift()
        shift_pdf = None
        if shift is None:
            shift_pdf = newest('*勤務予定表*.pdf')
            if shift_pdf:
                try:
                    shift = parse_shift(shift_pdf)
                except Exception:
                    log(f'シフト表の読み込み失敗: {shift_pdf}\n{traceback.format_exc()}')
        recs, src_name = load_records(path)
        if not recs:
            # 1件も読めない＝ファイルの種類か取り込み設定が合っていない可能性が高い
            raise RuntimeError('予約データを1件も読み取れませんでした。'
                               'ファイルの種類（CSV/PDF）や、お使いのシステムの取り込み設定を確認してください。')
        issues, infos, stats = patrol(recs, shift,
                                      absences=list(getattr(imp, 'LAST_ABSENCES', [])),
                                      blocks=list(getattr(imp, 'LAST_BLOCKS', [])))
        out = os.path.join(BASE, f'アポパトロール結果_{stamp}.html')
        if shift_pdf:
            shift_label = os.path.basename(shift_pdf)
        elif shift and shift.get('byDate'):
            shift_label = f'取り込み済みシフト表（{shift.get("year", "")}年{shift.get("month", "")}月）'
        else:
            shift_label = ''
        # 「これまでの記録」に1行足してから描く（記録は医院のPCの中だけ）
        report_html.record_history(recs, issues, stats, src=src_name)
        body = render_html(recs, issues, infos, shift, stats,
                           src_yoyaku=src_name,
                           src_shift=shift_label,
                           auto=True)
        try:
            import apomi_license as lic
            body = lic.inject_banner(body)   # 期限の予告バナー（必要なときだけ付く）
        except Exception:
            pass
        log(f'実行完了: {os.path.basename(path)}（{len(recs)}件）→ {os.path.basename(out)}')
        with open(out, 'w', encoding='utf-8-sig') as f:
            f.write(body)
        move_file(path, DONE_DIR, stamp)
    except Exception:
        # お客様には専門用語を並べず、「何をすればいいか」を伝える案内を出す
        tb = traceback.format_exc()
        log(f'実行エラー: {path}\n{tb}')
        out = os.path.join(BASE, f'読み取れませんでした_{stamp}.html')
        from report_html import render_error_html
        body = render_error_html(os.path.basename(path), detail=tb, inbox=ERROR_DIR)
        with open(out, 'w', encoding='utf-8-sig') as f:
            f.write(body)
        move_file(path, ERROR_DIR, stamp)   # 再検出で無限ループしないよう退避
    try:
        open_path(out)
    except OSError:
        pass

# ===== 毎朝のお知らせ =====

def is_open_day(d, shift):
    """診療日かどうか。シフト表（対象月一致時）は誰か出勤していれば診療日"""
    if shift and shift['month'] == f'{d.year}-{d.month:02d}':
        return bool(shift['days'].get(d.day))
    return d.weekday() not in CLOSED_WEEKDAYS

def add_months(d, n):
    y, m = d.year, d.month + n
    y += (m - 1) // 12
    m = (m - 1) % 12 + 1
    day = min(d.day, [31, 29 if y % 4 == 0 and (y % 100 != 0 or y % 400 == 0) else 28,
                      31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1])
    return datetime.date(y, m, day)

def choose_scope(today, shift):
    """今日のチェック範囲を決める（月初=4か月 > 週初め=1か月 > 毎日=1週間）"""
    def first_open_since(start):
        d = start
        while d < today:
            if is_open_day(d, shift):
                return False
            d += datetime.timedelta(days=1)
        return True
    if first_open_since(today.replace(day=1)):
        return ('4か月先まで', add_months(today, 4), '毎月・月初の特別チェックの日')
    week_start = today - datetime.timedelta(days=today.weekday())  # 月曜
    if first_open_since(week_start):
        return ('1か月先まで', add_months(today, 1), '毎週・週初めのチェックの日')
    return ('1週間先まで', today + datetime.timedelta(days=7), 'まいにちのチェック')

def fmt_date(d):
    return f'{d.year}/{d.month:02d}/{d.day:02d}（{WEEKDAYS[d.weekday()]}）'

def reminder_html(today, scope, end, subtitle):
    # API方式が使えるPCでは「デスクトップのアポチェックを押すだけ」、
    # 使えないPCでは従来どおりPDF保存の手順を案内する
    try:
        import genifix_api
        api_ok = genifix_api.is_ready()
    except Exception:
        api_ok = False
    if api_ok:
        steps = ('<b>1.</b> デスクトップの <b>「アポチェック」</b> をダブルクリック<br>'
                 '<b>2.</b> あとは待つだけ。結果が自動で開きます ✨<br>'
                 '<span style="color:#90a4ae;font-size:13px">'
                 'Genifixから直接読み取るので、PDFの保存は要りません</span>')
    else:
        steps = ('<b>1.</b> ご利用の予約システムで、上の期間の予約一覧を書き出し（CSV／PDF）<br>'
                 '<b>2.</b> デスクトップの <b>「apomi_取込」フォルダ</b> に保存<br>'
                 '<b>3.</b> あとは待つだけ。結果が自動で開きます ✨')
    return f'''<!DOCTYPE html>
<html lang="ja"><head><meta charset="utf-8"><title>🔔 アポパトロールタイム</title>
<style>
  body {{ margin:0; font-family:'Segoe UI','Yu Gothic UI',sans-serif;
         background:linear-gradient(160deg,#fff8e1,#e0f7fa); min-height:100vh;
         display:flex; align-items:center; justify-content:center; }}
  .box {{ background:#fff; border-radius:24px; padding:36px 44px; max-width:560px;
          box-shadow:0 10px 30px rgba(0,0,0,.12); text-align:center; }}
  h1 {{ font-size:26px; color:#00695c; margin:0 0 4px; }}
  .sub {{ color:#80cbc4; font-size:13px; margin-bottom:18px; }}
  .scope {{ background:linear-gradient(135deg,#26c6da,#66bb6a); color:#fff;
            border-radius:16px; padding:16px; font-size:22px; font-weight:700;
            margin:14px 0; }}
  .steps {{ text-align:left; color:#455a64; line-height:2; margin-top:14px; }}
  .steps b {{ color:#00695c; }}
  .period {{ font-size:17px; background:#fff3e0; border-radius:12px; padding:10px;
             color:#e65100; font-weight:700; margin:10px 0; }}
  .foot {{ color:#b0bec5; font-size:12px; margin-top:18px; }}
  img.apomi {{ width:150px; height:150px; border-radius:50%; object-fit:cover;
               object-position:top; box-shadow:0 6px 16px rgba(0,0,0,.15);
               border:5px solid #fff; margin-bottom:10px; }}
  .steps b {{ color:#00695c; }}
</style></head><body><div class="box">
  {apomi_img('patrol')}
  <h1>🔔 アポパトロールタイム！</h1>
  <div class="sub">{subtitle}</div>
  <div class="scope">今日は「{scope}」をチェック 🦷</div>
  <div class="period">📅 期間: {fmt_date(today)} 〜 {fmt_date(end)}</div>
  <div class="steps">{steps}</div>
  <div class="foot">まいにち=1週間先 ／ 週初め=1か月先 ／ 月初=4か月先<br>
  予約枠は医院の在庫。売れ残りゼロを目指そう！</div>
</div></body></html>'''

def maybe_remind(state):
    now = datetime.datetime.now()
    today = now.date()
    key = f'remind_{today.isoformat()}'
    if now.hour < REMIND_HOUR or state.get(key):
        return
    if state.get('last_run') == today.isoformat():
        state[key] = True  # 今日はもうチェック済みなのでお知らせ不要
        save_state(state)
        return
    shift = None
    shift_pdf = newest('*勤務予定表*.pdf')
    if shift_pdf:
        try:
            shift = parse_shift(shift_pdf)
        except Exception:
            pass
    if not is_open_day(today, shift):
        state[key] = True  # 休診日はお知らせしない
        save_state(state)
        return
    scope, end, subtitle = choose_scope(today, shift)
    out = os.path.join(BASE, 'アポパトロールお知らせ.html')
    with open(out, 'w', encoding='utf-8-sig') as f:
        f.write(reminder_html(today, scope, end, subtitle))
    try:
        open_path(out)
    except OSError:
        pass
    state[key] = True
    save_state(state)
    log(f'お知らせ表示: {scope}（{today} 〜 {end}）')

_FAILED_SIGS = {}   # 動かせなかったファイル（ロック中など）を覚えて連続再処理を防ぐ

def poll_once(state):
    """監視ループ1周ぶん。main()から5秒おきに呼ばれる（テストからも直接呼べる）"""
    # apomi本体の更新（成功すると起動しなおすので、この先は実行されない）
    if maybe_apply_update_drop():
        return
    # 医院設定の差し替え（取り込みフォルダ経由・直接編集の両対応）
    if maybe_apply_config_drop():
        try:   # 適用済みなので、直後の変更検知が二重に走らないよう記録
            state['cfg_mtime'] = os.path.getmtime(os.path.join(BASE, '医院設定.json'))
            save_state(state)
        except OSError:
            pass
    maybe_reload_config(state)
    # シフト表・臨時休メモの取り込み
    maybe_apply_shift_drop()
    maybe_apply_offmemo_drop()
    # 取り込みフォルダ直下のCSV/PDFを処理（サブフォルダ「済み」は見ない）
    files = (glob.glob(os.path.join(INBOX, '*.csv'))
             + glob.glob(os.path.join(INBOX, '*.xls'))
             + glob.glob(os.path.join(INBOX, '*.xlsx'))
             + glob.glob(os.path.join(INBOX, '*.pdf')))
    files = [f for f in files
             if not _is_special_name(os.path.basename(f))]   # シフト等は上で処理済み
    for f in files:
        if not is_stable(f):
            continue
        sig = file_sig(f)
        if _FAILED_SIGS.get(f) == sig:
            continue   # 前回動かせなかったファイル（OneDrive同期中のロック等）。変化したら再挑戦
        state['last_run'] = datetime.date.today().isoformat()
        save_state(state)
        process(f)   # 成功すると「済み」へ移動されるので再検出されない
        if os.path.exists(f):
            _FAILED_SIGS[f] = sig
            log(f'ファイルを移動できなかったため待機します（使用中の可能性）: {os.path.basename(f)}')
        else:
            _FAILED_SIGS.pop(f, None)
    maybe_remind(state)

def main():
    # 二重起動防止（ポートを確保できなければ既に動いている）
    # ※更新後の起動しなおしでは、古いプロセスが終わるまでの一瞬だけ重なる。
    #   すぐ諦めると常駐が消えてしまうので、数秒は粘って再挑戦する。
    guard = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    for i in range(10):
        try:
            guard.bind(('127.0.0.1', 53917))
            break
        except OSError:
            time.sleep(1)
    else:
        return
    ensure_inbox()
    if IS_FROZEN:
        # 前回の更新で残った古いexeを片づける（更新直後はまだ動いていて消せない）
        gone = upd.cleanup_old_exe(os.path.dirname(os.path.abspath(sys.executable)))
        if gone:
            log(f'古いapomiを片づけました: {", ".join(gone)}')
    refresh_settings_page()   # 設定画面を「今の設定入り」で最新化
    log(f'監視を開始しました（取り込みフォルダ: {INBOX}）')
    state = load_state()
    while True:
        try:
            poll_once(state)
        except Exception:
            log(f'監視ループでエラー:\n{traceback.format_exc()}')
        time.sleep(POLL_SEC)

if __name__ == '__main__':
    main()
