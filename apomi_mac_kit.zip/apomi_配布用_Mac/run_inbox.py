# -*- coding: utf-8 -*-
"""取り込みフォルダ（デスクトップの apomi_取込）にある最新のCSV/PDFを手動でチェックする。
Windows・Mac 共通。デスクトップの「アポチェック」から呼ばれる。

ファイルが無ければ取り込みフォルダを開いて、保存を促す。
"""
import os
import sys
import glob

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
import watch_patrol as w
from apomi_paths import open_path


def main():
    if not w.license_gate(force_notice=True):
        print('使用期限が切れているため、チェックをお休みしています（案内を開きました）。')
        return
    w.ensure_inbox()
    files = (glob.glob(os.path.join(w.INBOX, '*.csv'))
             + glob.glob(os.path.join(w.INBOX, '*.xls'))
             + glob.glob(os.path.join(w.INBOX, '*.xlsx'))
             + glob.glob(os.path.join(w.INBOX, '*.pdf')))
    if not files:
        print('取り込みフォルダにCSV/PDFがありません。')
        print(f'このフォルダに予約一覧を保存してください:\n  {w.INBOX}')
        open_path(w.INBOX)     # フォルダを開いて保存を促す
        return
    newest = max(files, key=os.path.getmtime)
    print(f'処理します: {os.path.basename(newest)}')
    w.process(newest)          # チェック→レポート表示→済みへ移動
    print('完了しました。結果をブラウザで開きました。')


if __name__ == '__main__':
    main()
