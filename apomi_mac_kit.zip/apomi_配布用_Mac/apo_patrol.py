# -*- coding: utf-8 -*-
"""アポパトロール: Genifix予約一覧PDF（＋勤務予定表PDF）をチェックして問題点をレポートする

使い方:
  python apo_patrol.py 予約一覧.pdf [勤務予定表.pdf]
"""
import sys, re, unicodedata, datetime
from collections import defaultdict

# 曜日の日本語 → Python の weekday()（月=0 … 日=6）
WEEKDAY_JP = {'月': 0, '火': 1, '水': 2, '木': 3, '金': 4, '土': 5, '日': 6}
from parse_genifix import parse_pdf, clean
from parse_shift import parse_shift

# ===== 医院設定 =====
# 医院ごとの設定（チェア構成・診療時間・上限など）は「医院設定.json」で管理する。
# apomi_settings.S が現在の医院の設定。無ければいいづか初期値で動く。
from apomi_settings import S as SETTINGS

def to_min(hm):
    h, m = hm.split(':')
    return int(h) * 60 + int(m)

def fmt(mins):
    return f'{mins//60:02d}:{mins%60:02d}'

def overlaps(a, b):
    return to_min(a['開始']) < to_min(b['終了']) and to_min(b['開始']) < to_min(a['終了'])

def reiwa_to_md(datestr):
    """令和8.07.04 → (2026, 7, 4)"""
    m = re.search(r'令和(\d+)\.(\d+)\.(\d+)', datestr)
    if not m:
        return None
    return (2018 + int(m.group(1)), int(m.group(2)), int(m.group(3)))

def norm(s):
    return unicodedata.normalize('NFKC', s).replace(' ', '').replace('．', '').replace('.', '')

def split_staff(s):
    """スタッフ欄を個人名に分解する（「院長 DH.後藤」→ ['院長', 'DH.後藤']）。
    1件の予約に複数人が入っている予約システムがあるため。"""
    if not s:
        return []
    return [p for p in re.split(r'[\s、,／/・]+', s.strip()) if p]


def match_staff(app_staff, shift_list, alias=None):
    """予約のスタッフ名がシフト表のどの人か（姓の前方一致）。見つからなければNone"""
    alias = alias or {}
    a = norm(app_staff)
    if not a:
        return None
    for s in shift_list:
        names = alias.get(s['name'], [s['name']])
        for n in names:
            # シフト表は「TC杏奈」のように名のみの場合があるため部分一致で照合
            if norm(n) in a or a in norm(n):
                return s
    return None

def patrol(recs, shift=None, settings=None, absences=None, blocks=None):
    st = settings or SETTINGS
    TREATMENT_CHAIRS = st.treatment_chairs
    COUNSELING_ROOMS = st.counseling_rooms
    MAX_TREATMENT = st.max_treatment
    MAX_COUNSELING = st.max_counseling
    OPEN_HOURS = st.open_hours
    SLOT_MIN = st.slot_min

    issues = []   # (レベル, カテゴリ, メッセージ)
    infos = []
    stats = {}    # 日付 -> 15分刻みの枠情報 [{'t','book','cap','free','lunch'}]

    # 「チェアなし」の予約表への対応。
    # EPARK歯科台帳のように、列が担当者だけでユニット（チェア）の欄が無い
    # システムがある。その場合は「同じ時間にいる“患者の人数”」を使って
    # 何台埋まっているかを数える（1人の患者に医師と衛生士がつくのは1台ぶん）。
    CHAIRLESS = bool(recs) and not any((r.get('チェア') or '').strip() for r in recs)

    def patient_key(r):
        return (r.get('患者No') or '').strip() or (r.get('氏名') or '').strip() or id(r)

    def is_counseling(r):
        """チェア欄が無いときは、担当者名でカウンセリングを見分ける"""
        v = (r.get('チェア') or '') + '｜' + (r.get('スタッフ') or '')
        return any(cr and cr in v for cr in COUNSELING_ROOMS)

    by_date = defaultdict(list)
    for r in recs:
        by_date[r['予約日']].append(r)

    # 出勤情報がカバーしている期間（休診日判定に使う）。
    # データが無い日は「休診」ではなく「不明」なので判定しない。
    shift_range = None
    if shift and shift.get('byDate'):
        keys = sorted(shift['byDate'].keys())
        if keys:
            shift_range = (keys[0], keys[-1])

    for date, rows in sorted(by_date.items()):
        if CHAIRLESS:
            couns = [r for r in rows if is_counseling(r)]
            treat = [r for r in rows if not is_counseling(r)]
            other = []
        else:
            treat = [r for r in rows if r['チェア'] in TREATMENT_CHAIRS]
            couns = [r for r in rows if r['チェア'] in COUNSELING_ROOMS]
            other = [r for r in rows if r['チェア'] not in TREATMENT_CHAIRS + COUNSELING_ROOMS]

        # その日のシフト
        # byDate = Genifix APIから取った出勤情報（日付をキーに全期間ぶん持つ）
        # month/days = 勤務予定表PDFから読んだ出勤情報（1か月ぶんのみ）
        day_shift = []
        ymd = reiwa_to_md(date)
        if shift and ymd:
            y, mo, d = ymd
            if shift.get('byDate') is not None:
                day_shift = shift['byDate'].get(f'{y}-{mo:02d}-{d:02d}', [])
            elif shift.get('month') == f'{y}-{mo:02d}':
                day_shift = shift['days'].get(d, [])
            else:
                infos.append((f'{date} シフト表の対象月({shift.get("month")})と予約の月が違うため出勤チェックをスキップ', []))
        def on_duty(role, t0, t1):
            return [s for s in day_shift if s['role'] == role
                    and to_min(s['start']) <= t0 and t1 <= to_min(s['end'])]

        # --- 0-a. 休診日なのに予約が入っている ---
        # 出勤者ゼロ＝休診日。ただし出勤情報がその日をカバーしている場合のみ判定する。
        cdb = st.closed_day_booking
        if cdb.get('enabled') and not day_shift and rows and ymd:
            y, mo, d = ymd
            key = f'{y}-{mo:02d}-{d:02d}'
            covered = False
            if shift_range:
                covered = shift_range[0] <= key <= shift_range[1]
            elif shift and shift.get('month') == f'{y}-{mo:02d}':
                covered = True
            if covered:
                issues.append((cdb.get('level', 'エラー'), '休診日に予約',
                    f'{date}: この日は出勤者がいません（休診日）が、予約が{len(rows)}件入っています'))

        # --- 0-b. 担当者のダブルブッキング（同じ人が同時刻に2つの予約） ---
        # 同一患者の重なりは「患者二重予約」「初診連携」で扱うのでここでは報告しない。
        sdb = st.staff_double_booking
        if sdb.get('enabled'):
            # 除外は前方一致（「TC」と設定すれば「TC」「TC杏奈」等をまとめて除外できる）
            ignore = [norm(x) for x in sdb.get('ignore_staff', []) if norm(x)]
            # 並列OK: {"名前": 同時上限}（前方一致）。上限内は「注意」で見える化、超えたらエラー。
            plimits = {norm(k): int(v) for k, v in (sdb.get('parallel_staff') or {}).items()
                       if norm(k) and str(v).isdigit()}

            def plimit_of(key):
                for pk, lim in plimits.items():
                    if key.startswith(pk):
                        return lim
                return None

            by_staff = defaultdict(list)
            for r in rows:
                for nm in split_staff(r['スタッフ']):
                    key = norm(nm)
                    if key and not any(key.startswith(ig) for ig in ignore):
                        by_staff[key].append((nm, r))
            for key, items in sorted(by_staff.items()):
                items.sort(key=lambda x: to_min(x[1]['開始']))
                lim = plimit_of(key)
                if lim is not None:
                    # 並列OKの人: 同時本数を数える。上限内=注意（消さない）、超過=エラー。
                    starts = sorted({to_min(r['開始']) for _, r in items})
                    max_c, worst_t = 1, None
                    for t in starts:
                        c = sum(1 for _, r in items
                                if to_min(r['開始']) <= t < to_min(r['終了']))
                        if c > max_c:
                            max_c, worst_t = c, t
                    if max_c > lim:
                        at = [r for _, r in items
                              if to_min(r['開始']) <= worst_t < to_min(r['終了'])]
                        det = '、'.join(f'{r["開始"]}～{r["終了"]}[{r["チェア"]}] '
                                        f'{r["氏名"]}({r["患者No"]})' for r in at)
                        issues.append((sdb.get('level', 'エラー'), '担当者ダブルブッキング',
                            f'{date} 担当「{items[0][0]}」: '
                            f'{worst_t // 60:02d}:{worst_t % 60:02d}の時点で同時{max_c}件 —— '
                            f'並列OKの上限（{lim}件）を超えています: {det}'))
                    elif max_c >= 2:
                        issues.append(('注意', '並列稼働（設定の範囲内）',
                            f'{date} 担当「{items[0][0]}」: 同時最大{max_c}件で並列稼働'
                            f'（並列OK・上限{lim}件の範囲内です。念のため一覧に出しています）'))
                    continue
                for i in range(len(items)):
                    for j in range(i + 1, len(items)):
                        nm_a, a = items[i]
                        nm_b, b = items[j]
                        if not overlaps(a, b):
                            continue
                        if a['患者No'] == b['患者No'] and a['氏名'] == b['氏名']:
                            continue
                        issues.append((sdb.get('level', 'エラー'), '担当者ダブルブッキング',
                            f'{date} 担当「{nm_a}」: '
                            f'{a["開始"]}～{a["終了"]}[{a["チェア"]}] {a["氏名"]}({a["患者No"]}) と '
                            f'{b["開始"]}～{b["終了"]}[{b["チェア"]}] {b["氏名"]}({b["患者No"]}) '
                            f'が重なっています（同じ人が同時に2か所）'))

        # --- 1. 同一チェア・同一ルームの相乗り ---
        # 運用上は従業員が気づいていれば回せるが、属人的で見落としが起きるため
        # 「要修正」として必ず拾う（同一患者の重複は「患者二重予約」で報告するので除く）
        by_chair = defaultdict(list)
        if not CHAIRLESS:      # チェア欄が無ければ「同じチェアの相乗り」は判定できない
            for r in treat + couns:
                by_chair[r['チェア']].append(r)
        for chair, rs in by_chair.items():
            rs.sort(key=lambda r: to_min(r['開始']))
            for i in range(len(rs)):
                for j in range(i + 1, len(rs)):
                    a, b = rs[i], rs[j]
                    if not overlaps(a, b):
                        continue
                    if a['患者No'] == b['患者No'] and a['氏名'] == b['氏名']:
                        continue
                    issues.append(('エラー', 'チェア相乗り', f'{date} {chair}: '
                        f'{a["開始"]}～{a["終了"]} {a["氏名"]}({a["患者No"]}/{a["処置名"]}) と '
                        f'{b["開始"]}～{b["終了"]} {b["氏名"]}({b["患者No"]}/{b["処置名"]}) が'
                        f'同じチェアで重なっています'))

        # --- 1-b. 同じチェアの予約間のバッファ（片付け・消毒の時間）---
        cb = st.chair_buffer
        if cb.get('enabled') and int(cb.get('minutes', 0)) > 0:
            need = int(cb['minutes'])
            for chair, rs in sorted(by_chair.items()):
                seq = sorted(rs, key=lambda r: to_min(r['開始']))
                for k in range(len(seq) - 1):
                    a, b = seq[k], seq[k + 1]
                    gap = to_min(b['開始']) - to_min(a['終了'])
                    if gap < 0:
                        continue   # 重なりは「チェア相乗り」で報告済み
                    if a['患者No'] == b['患者No'] and a['氏名'] == b['氏名']:
                        continue   # 同じ患者さんの連続予約は片付け不要
                    if gap < need:
                        issues.append((cb.get('level', '警告'), '予約間のバッファ不足',
                            f'{date} {chair}: {a["氏名"]}({a["患者No"]}) が{a["終了"]}終了 → '
                            f'{b["氏名"]}({b["患者No"]}) が{b["開始"]}開始。'
                            f'間隔{gap}分（必要{need}分）'))

        # --- 2. 同時間帯の件数上限チェック ---
        def concurrent_over(rows_, limit, label, level='エラー'):
            events = []
            for r in rows_:
                events.append((to_min(r['開始']), 1))
                events.append((to_min(r['終了']), -1))
            events.sort()
            n, over_from, peak = 0, None, 0
            for t, dlt in events:
                n += dlt
                peak = max(peak, n)
                if n > limit and over_from is None:
                    over_from = t
                elif n <= limit and over_from is not None:
                    issues.append((level, label, f'{date} {fmt(over_from)}～{fmt(t)}: '
                                   f'{label}が上限{limit}を超えています（最大{peak}件）'))
                    over_from = None
        concurrent_over(treat, MAX_TREATMENT, '治療予約数')          # 10件以上でエラー
        concurrent_over(couns, MAX_COUNSELING, 'カウンセリング数')   # 3件以上でエラー

        # --- 2-b. カウンセリング室の長い予約（＝そこで治療をしているサイン） ---
        # カウンセリング室は治療チェアと別に数えるため、そこで治療をされると
        # 「治療の同時件数」は上限内のままで、実際の同時人数の超過に気づけない。
        cl = st.counseling_long
        if cl.get('enabled') and couns:
            limit = int(cl.get('minutes', 15))
            for r in sorted(couns, key=lambda r: to_min(r['開始'])):
                dur = to_min(r['終了']) - to_min(r['開始'])
                if dur <= limit:
                    continue
                # この予約の間で、治療チェアがいちばん埋まる瞬間を探す（超過の説明に使う）。
                # 開始時刻だけを見ると、途中から混む場合を見落とす。
                t0, t1 = to_min(r['開始']), to_min(r['終了'])
                moments = {t0} | {to_min(x['開始']) for x in treat
                                  if t0 < to_min(x['開始']) < t1}
                busy, worst = 0, t0
                for t in sorted(moments):
                    n = sum(1 for x in treat
                            if to_min(x['開始']) <= t < to_min(x['終了']))
                    if n > busy:
                        busy, worst = n, t
                more = (f'{fmt(worst)}の時点で治療チェア{len(TREATMENT_CHAIRS)}台が'
                        f'すべて埋まっているので、この予約と合わせて'
                        f'同時に{busy + 1}人を診ることになります。'
                        ) if busy >= MAX_TREATMENT else ''
                issues.append((cl.get('level', '警告'), 'カウンセリング室の長い予約',
                    f'{date} {r["開始"]}～{r["終了"]} [{r["チェア"]}]: '
                    f'{r["氏名"]}({r["患者No"]}) {r["処置名"]} が{dur}分。'
                    f'カウンセリング室で{limit}分を超える予約です。{more}'
                    f'治療をするならチェアへ、相談ならこの長さで合っているかご確認ください'))

        # --- 3. 同一患者の二重予約 ---
        by_pat = defaultdict(list)
        for r in rows:
            # 患者No.が未発番の新患（仮患者）は氏名で区別する
            key = r['患者No'] if r['患者No'].isdigit() else f"{r['患者No']}:{r['氏名']}"
            by_pat[key].append(r)
        shoshin_lines = []
        for pno, rs in by_pat.items():
            if len(rs) < 2:
                continue
            rs.sort(key=lambda r: to_min(r['開始']))
            for i in range(len(rs)):
                for j in range(i + 1, len(rs)):
                    if overlaps(rs[i], rs[j]):
                        a, b = rs[i], rs[j]
                        # 初診連携パターン: 外側の枠の後半に内側の枠を重ねる（担当がアシスタントで延長）
                        # のを正常運用として扱う医院向け。医院設定.jsonのshoshin_linkで有効/無効・役割を指定。
                        is_shoshin = False
                        sl = st.shoshin_link
                        if sl.get('enabled'):
                            outer_chairs = st.chairs_by_role.get(sl.get('outer_role'), [])
                            inner_chairs = st.chairs_by_role.get(sl.get('inner_role'), [])
                            kw = sl.get('keyword', '')
                            outer, inner = (a, b) if a['チェア'] in outer_chairs else (b, a)
                            is_shoshin = (outer['チェア'] in outer_chairs and inner['チェア'] in inner_chairs
                                and to_min(outer['開始']) <= to_min(inner['開始'])
                                and to_min(inner['終了']) <= to_min(outer['終了'])
                                and (kw in a['処置名'] or kw in b['処置名']))
                            if is_shoshin:
                                shoshin_lines.append(f'  {a["氏名"]}({pno}): '
                                    f'{outer["開始"]}～{outer["終了"]}[{outer["チェア"]}] + '
                                    f'{inner["開始"]}～{inner["終了"]}[{inner["チェア"]}]')
                                continue
                        if (CHAIRLESS or
                                not getattr(st, 'patient_double_booking', {}).get('enabled', True)):
                            continue   # 担当者ごとの列の予約表では、同時に複数人が
                                       # 1人の患者につくのが普通（設定でオフにできる）
                        issues.append(('エラー', '患者二重予約', f'{date} {a["氏名"]}({pno}): '
                            f'{a["開始"]}～{a["終了"]}[{a["チェア"]}/{a["処置名"]}] と '
                            f'{b["開始"]}～{b["終了"]}[{b["チェア"]}/{b["処置名"]}] が重複'))
            # 隙間なく連続する予約は一続きの来院として1ブロックに束ね、
            # ブロックが2つ以上に分かれる場合のみ警告（カウンセリング→治療の連続は正常）
            blocks = []
            for r in rs:
                if blocks and to_min(r['開始']) <= blocks[-1]['end']:
                    blocks[-1]['end'] = max(blocks[-1]['end'], to_min(r['終了']))
                    blocks[-1]['items'].append(r)
                else:
                    blocks.append({'end': to_min(r['終了']), 'items': [r]})
            if len(blocks) > 1:
                desc = ' と '.join(
                    f"{b['items'][0]['開始']}～{fmt(b['end'])}"
                    f"[{'/'.join(x['チェア'] for x in b['items'])}]" for b in blocks)
                issues.append(('警告', '患者同日複数予約', f'{date} {rs[0]["氏名"]}({pno}): '
                    f'{desc} が離れた時間に入っています（消し忘れの可能性）'))
        if shoshin_lines:
            sl = st.shoshin_link
            infos.append((f'{date} 初診連携予約（{sl.get("outer_role")}枠+{sl.get("inner_role")}枠の重なり・正常運用）',
                          shoshin_lines))

        # --- 4. 担当スタッフの出勤チェック ---
        if day_shift:
            for r in rows:
                if not r['スタッフ']:
                    continue
                s = match_staff(r['スタッフ'], day_shift, st.staff_alias)
                t0, t1 = to_min(r['開始']), to_min(r['終了'])
                if s is None:
                    issues.append(('エラー', '担当が休み', f'{date} {r["開始"]}～{r["終了"]} '
                        f'{r["氏名"]}({r["患者No"]}) [{r["チェア"]}] 担当「{r["スタッフ"]}」は'
                        f'この日のシフトにいません（休みまたは名前不一致）'))
                elif not (to_min(s['start']) <= t0 and t1 <= to_min(s['end'])):
                    issues.append(('エラー', '担当が勤務時間外', f'{date} {r["開始"]}～{r["終了"]} '
                        f'{r["氏名"]}({r["患者No"]}) [{r["チェア"]}] 担当「{r["スタッフ"]}」の'
                        f'勤務は{s["start"]}～{s["end"]}です'))

        # --- 4.5 曜日で必ず出勤しているべきスタッフのチェック ---
        # 例: 水曜は中野DHが必須。診療日（誰か出勤している日）なのに本人がいなければエラー。
        # 休診日（day_shiftが空）は判定しない。
        if day_shift and st.required_staff and ymd:
            wd = datetime.date(*ymd).weekday()
            for req in st.required_staff:
                name = req.get('name', '')
                if not name or WEEKDAY_JP.get(req.get('weekday')) != wd:
                    continue
                want = norm(name)
                found = any(want in norm(s['name']) or norm(s['name']) in want
                            for s in day_shift)
                if not found:
                    issues.append(('エラー', '必須スタッフ欠勤', f'{date}（{req.get("weekday")}曜）: '
                        f'{name}{req.get("role","")} が出勤予定に入っていません'
                        f'（{req.get("weekday")}曜は出勤必須の設定です）'))

        # --- 4.6 担当の固定休（この曜日は休みの人）---
        # シフト表が無くても、「毎週◯曜は休み」という規則だけで間違い予約を見つけられる。
        fx = getattr(st, 'staff_fixed_off', {}) or {}
        if fx.get('enabled') and fx.get('rules') and ymd:
            wd_jp = {v: k for k, v in WEEKDAY_JP.items()}[datetime.date(*ymd).weekday()]
            fx_rules = {norm(k): set(v) for k, v in fx['rules'].items() if norm(k)}
            for r in rows:
                for nm in split_staff(r['スタッフ']):
                    key = norm(nm)
                    if any(key.startswith(pk) and wd_jp in days_off
                           for pk, days_off in fx_rules.items()):
                        issues.append((fx.get('level', 'エラー'), '担当の固定休',
                            f'{date}（{wd_jp}曜） {r["開始"]}～{r["終了"]} '
                            f'{r["氏名"]}({r["患者No"]}) [{r["チェア"]}] '
                            f'担当「{nm}」は毎週{wd_jp}曜が固定休の設定です'))

        # --- 4.7 担当のお休み（予約表の日毎メモ・不在ブロックから自動読取）---
        # アポツールの書き出しに「斉藤有給」等のメモや「◯◯不在」ブロックがあれば、
        # その人（の列）に入っている予約を知らせる。名前は異体字（冨/富等）も同一視。
        if absences:
            from apomi_import import fold_name
            for a in absences:
                if a.get('日付') and a['日付'] != date:
                    continue
                nm = fold_name(a.get('名前', ''))
                if not nm:
                    continue
                for r in rows:
                    hit = (nm in fold_name(r['チェア'])
                           or any(fold_name(s).startswith(nm)
                                  for s in split_staff(r['スタッフ'])))
                    if not hit:
                        continue
                    if a.get('開始'):   # 時間つき（不在ブロック）は重なる予約だけ
                        try:
                            if not (to_min(r['開始']) < to_min(a['終了'])
                                    and to_min(r['終了']) > to_min(a['開始'])):
                                continue
                        except Exception:
                            pass
                    issues.append(('エラー', '担当のお休み',
                        f'{date} {r["開始"]}～{r["終了"]} '
                        f'{r["氏名"]}({r["患者No"]}) [{r["チェア"]}] '
                        f'「{a["名前"]}」さんはこの日お休みの予定です'
                        f'（{a["根拠"]}）。予約の移動をご検討ください'))

        # --- 5. 空き枠と人手のバランス（15分刻み）---
        occupied = defaultdict(list)
        for r in treat:
            t = to_min(r['開始'])
            while t < to_min(r['終了']):
                # チェアが無いときは患者で数える（あとで重複を1人にまとめる）
                occupied[t].append(patient_key(r) if CHAIRLESS else r['チェア'])
                t += SLOT_MIN
        # 「予約を入れない枠」（予約表で黒く塗ったマス等）は空き枠に数えない
        blocked = defaultdict(set)
        for b in (blocks or []):
            if b.get('日付') and b['日付'] != date:
                continue
            try:
                t, end = to_min(b['開始']), to_min(b['終了'])
            except Exception:
                continue
            while t < end:
                blocked[t].add(b.get('チェア', ''))
                t += SLOT_MIN
        gap_lines, lunch_gap_lines, short_lines = [], [], []
        day_slots = []
        if st.lunch_window:
            lunch0, lunch1 = to_min(st.lunch_window[0]), to_min(st.lunch_window[1])
        else:
            lunch0 = lunch1 = -1   # 昼休み帯の指定なし＝どの枠も昼休み扱いにしない
        for o, c in OPEN_HOURS:
            t = to_min(o)
            while t < to_min(c):
                in_lunch = lunch0 <= t < lunch1
                chairs_used = occupied.get(t, [])
                if CHAIRLESS:
                    # 同じ患者に何人ついていても1台。人数ぶんだけ台を使ったとみなす
                    n_patients = len(set(chairs_used))
                    chairs_used = TREATMENT_CHAIRS[:n_patients]
                n_book = len(chairs_used)
                if day_shift:
                    # チェアの役割グループごとに「出勤数」と「予約数」を突き合わせて定員を出す
                    cap = 0
                    over = []
                    for g in st.chair_groups:
                        role, gch = g['role'], g['chairs']
                        n_on = len(on_duty(role, t, t + SLOT_MIN))
                        n_bk = sum(1 for ch in chairs_used if ch in gch)
                        cap += min(len(gch), n_on)
                        # 人手より予約が多い（昼休み帯は交代で抜けるため判定しない）
                        if not in_lunch and n_bk > n_on:
                            over.append(f'{role}予約{n_bk}件/出勤{n_on}名')
                    cap = min(MAX_TREATMENT, cap)
                    if over:
                        short_lines.append(f'  {fmt(t)}～{fmt(t+SLOT_MIN)}: ' + ', '.join(over))
                else:
                    cap = MAX_TREATMENT
                off = blocked.get(t, ())
                free = [ch for ch in TREATMENT_CHAIRS
                        if ch not in chairs_used and ch not in off]
                if off:      # ブロックした分だけ、その時間に埋められる枠を減らす
                    cap = min(cap, len([ch for ch in TREATMENT_CHAIRS if ch not in off]))
                day_slots.append({'t': t, 'book': n_book, 'cap': cap,
                                  'free': free, 'lunch': in_lunch})
                if n_book < cap:
                    line = (f'  {fmt(t)}～{fmt(t+SLOT_MIN)}: 予約{n_book}件 '
                            f'(埋められる枠 {cap}) 空きチェア: {", ".join(free[:cap-n_book])}')
                    (lunch_gap_lines if in_lunch else gap_lines).append(line)
                t += SLOT_MIN
        stats[date] = day_slots
        if short_lines:
            issues.append(('警告', '人手不足の時間帯', f'{date} 予約数が出勤数を超えている時間帯:\n'
                           + '\n'.join(short_lines)))
        if gap_lines:
            infos.append((f'{date} 空き枠（人手があるのに埋まっていない時間帯）', gap_lines))
        if lunch_gap_lines:
            infos.append((f'{date} 空き枠・昼休み帯{st.lunch_window_text()}（交代休憩のため参考扱い）',
                          lunch_gap_lines))

        # --- 5-d. 空き枠の質（飛び地の穴・チェア稼働の偏り）---
        # チェアごとに、その日の予約時間帯をつなげた（重なりをまとめた）一覧を作る
        merged_by_chair = {}
        for chair in TREATMENT_CHAIRS:
            spans = sorted((to_min(r['開始']), to_min(r['終了']))
                           for r in treat if r['チェア'] == chair)
            if not spans:
                continue
            merged = [list(spans[0])]
            for s, e in spans[1:]:
                if s <= merged[-1][1]:
                    merged[-1][1] = max(merged[-1][1], e)
                else:
                    merged.append([s, e])
            merged_by_chair[chair] = merged

        ig = st.isolated_gap
        if ig.get('enabled'):
            limit = int(ig.get('max_minutes', 30))
            gap_isolated = []
            total_lost = 0
            for chair in TREATMENT_CHAIRS:
                merged = merged_by_chair.get(chair)
                if not merged:
                    continue
                for k in range(len(merged) - 1):
                    gap = merged[k + 1][0] - merged[k][1]
                    if 0 < gap <= limit:
                        total_lost += gap
                        gap_isolated.append(
                            f'  {chair}: {fmt(merged[k][1])}～{fmt(merged[k + 1][0])}（{gap}分）')
            if gap_isolated:
                infos.append((f'{date} 飛び地の空き枠（前後が埋まっていて、短いため新しい予約が入りにくい枠・計{total_lost}分）',
                              gap_isolated))

        cbal = st.chair_balance
        if cbal.get('enabled'):
            used = {c: sum(e - s for s, e in m) for c, m in merged_by_chair.items()}
            if len(used) >= 2:
                hi = max(used, key=used.get)
                lo = min(used, key=used.get)
                diff = used[hi] - used[lo]
                if diff >= int(cbal.get('max_diff_minutes', 120)):
                    lines = [f'  {c}: {v}分' for c, v in
                             sorted(used.items(), key=lambda x: -x[1])]
                    infos.append((f'{date} チェア稼働の偏り（{hi} {used[hi]}分 ⇔ {lo} {used[lo]}分・差{diff}分）',
                                  lines))

        # --- 5-b. 処置別の標準時間との乖離（時間の取り違え検出）---
        tm = st.treatment_minutes
        if tm.get('enabled') and tm.get('rules'):
            tol = int(tm.get('tolerance', 0))
            # より具体的（長い）keyword を優先して1件だけ適用する
            rules = sorted(tm['rules'],
                           key=lambda x: len(str(x.get('keyword', ''))), reverse=True)
            for r in rows:
                proc = norm(r['処置名'])
                if not proc:
                    continue
                for rule in rules:
                    kw = norm(str(rule.get('keyword', '')))
                    if not kw or kw not in proc:
                        continue
                    exp = int(rule.get('minutes', 0))
                    act = to_min(r['終了']) - to_min(r['開始'])
                    if exp > 0 and abs(act - exp) > tol:
                        issues.append((tm.get('level', '警告'), '処置時間の不一致',
                            f'{date} {r["開始"]}～{r["終了"]} {r["氏名"]}({r["患者No"]}) '
                            f'[{r["チェア"]}] {r["処置名"]}: {act}分ですが標準は{exp}分です'))
                    break

        # --- 5-c. 処置の制約（行える人・使える場所）---
        tc = st.treatment_constraints
        if tc.get('enabled') and tc.get('rules'):
            lv = tc.get('level', 'エラー')
            rules_c = sorted(tc['rules'],
                             key=lambda x: len(str(x.get('keyword', ''))), reverse=True)
            for r in rows:
                proc = norm(r['処置名'])
                if not proc:
                    continue
                for rule in rules_c:
                    kw = norm(str(rule.get('keyword', '')))
                    if not kw or kw not in proc:
                        continue
                    names = split_staff(r['スタッフ'])
                    head = (f'{date} {r["開始"]}～{r["終了"]} {r["氏名"]}({r["患者No"]}) '
                            f'{r["処置名"]}')
                    # 使えるチェアの制約
                    ac = rule.get('allowed_chairs')
                    if ac and r['チェア'] not in ac:
                        issues.append((lv, '処置とチェアの不一致',
                            f'{head}: [{r["チェア"]}] では行えません'
                            f'（行えるチェア: {"、".join(ac)}）'))
                    # 担当できる人の制約（名前）
                    al = rule.get('allowed_staff')
                    if al and names:
                        ok = any(norm(w) and (norm(w) in norm(n) or norm(n) in norm(w))
                                 for n in names for w in al)
                        if not ok:
                            issues.append((lv, '処置と担当の不一致',
                                f'{head}: 担当「{r["スタッフ"]}」では行えません'
                                f'（行える人: {"、".join(al)}）'))
                    # 役割（資格）の制約。出勤情報から役割が分かる日だけ判定する
                    ar = rule.get('allowed_roles')
                    if ar and names and day_shift:
                        roles = []
                        for n in names:
                            s = match_staff(n, day_shift, st.staff_alias)
                            if s:
                                roles.append(s['role'])
                        if roles and not any(x in ar for x in roles):
                            issues.append((lv, '処置と担当の不一致',
                                f'{head}: 担当「{r["スタッフ"]}」（{"/".join(roles)}）'
                                f'では行えません（行える役割: {"、".join(ar)}）'))
                    break

        # --- 6. その他の異常 ---
        for r in rows:
            if not r['スタッフ']:
                issues.append(('警告', '担当者未設定', f'{date} {r["開始"]}～{r["終了"]} '
                               f'{r["氏名"]}({r["患者No"]}) [{r["チェア"]}] スタッフが空欄です'))
            if not r['処置名']:
                issues.append(('警告', '処置未設定', f'{date} {r["開始"]}～{r["終了"]} '
                               f'{r["氏名"]}({r["患者No"]}) [{r["チェア"]}] 処置名が空欄です'))
            s, e = to_min(r['開始']), to_min(r['終了'])
            if e <= s:
                issues.append(('エラー', '時間異常', f'{date} {r["氏名"]}({r["患者No"]}): '
                               f'{r["開始"]}～{r["終了"]} 終了が開始より前です'))
            in_hours = any(to_min(o) <= s and e <= to_min(c) for o, c in OPEN_HOURS)
            if not in_hours:
                issues.append(('警告', '診療時間外', f'{date} {r["開始"]}～{r["終了"]} '
                               f'{r["氏名"]}({r["患者No"]}) [{r["チェア"]}] 診療時間({st.open_hours_text()})外の予約です'))
            if r['要注意']:
                issues.append(('注意', '要注意患者', f'{date} {r["開始"]}～{r["終了"]} '
                               f'{r["氏名"]}({r["患者No"]}): 要注意フラグあり'))
            if r.get('日付要確認'):
                issues.append(('エラー', '日付読み取り不確か', f'{date} {r["開始"]}～ '
                               f'{r["氏名"]}({r["患者No"]}) の行から時刻が巻き戻っています。'
                               f'PDFの日付読み取りに失敗し別の日が合算されている可能性があります。'
                               f'この日の判定は参考にせず、開発者に連絡してください'))
        if other:
            infos.append((f'{date} 特殊枠', [f'  {r["開始"]}～{r["終了"]} [{r["チェア"]}] '
                          f'{r["氏名"]}({r["患者No"]}) {r["処置名"]} {r["主訴"]}'.rstrip()
                          for r in other]))
    return issues, infos, stats

def report(recs, issues, infos, shift=None):
    lines = []
    dates = sorted(set(r['予約日'] for r in recs))
    lines.append('=' * 60)
    lines.append('アポパトロール結果')
    lines.append(f'対象: {dates[0]}' + (f' ～ {dates[-1]}' if len(dates) > 1 else '')
                 + f'　予約件数: {len(recs)}件'
                 + ('　シフト表: あり' if shift else '　シフト表: なし'))
    lines.append('=' * 60)
    order = {'エラー': 0, '警告': 1, '注意': 2}
    issues.sort(key=lambda x: order.get(x[0], 9))
    n_err = sum(1 for l, _, _ in issues if l == 'エラー')
    n_warn = sum(1 for l, _, _ in issues if l != 'エラー')
    lines.append(f'\n【問題点】エラー {n_err}件 / 警告・注意 {n_warn}件\n')
    if not issues:
        lines.append('  問題は見つかりませんでした。')
    for lv, cat, msg in issues:
        lines.append(f'  [{lv}][{cat}] {msg}')
    for title, ls in infos:
        lines.append(f'\n【{title}】')
        lines.extend(ls)
    return '\n'.join(lines)

if __name__ == '__main__':
    recs = clean(parse_pdf(sys.argv[1]))
    shift = parse_shift(sys.argv[2]) if len(sys.argv) > 2 else None
    issues, infos, stats = patrol(recs, shift)
    print(report(recs, issues, infos, shift))
