# -*- coding: utf-8 -*-
"""OSの違い（Windows / Mac）を吸収する共通処理。

- desktop_dir(): このパソコンの実際のデスクトップフォルダを返す
- open_path():   ファイル/フォルダを既定アプリで開く（レポートをブラウザで開く等）

Windows・Mac のどちらでも動くように書いてある。
"""
import os
import sys
import subprocess

IS_WIN = sys.platform.startswith('win')
IS_MAC = sys.platform == 'darwin'
# 1つの実行ファイル（exe/app）にまとめた状態で動いているか
IS_FROZEN = bool(getattr(sys, 'frozen', False))


def bundle_dir():
    """プログラムに同梱された、書き換えない資料の置き場所（アポミちゃんの画像など）。

    実行ファイル化すると中身は一時フォルダに展開されるため、そこを指す。
    """
    if IS_FROZEN:
        return getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def data_dir():
    """医院ごとの設定・結果を置く場所。

    実行ファイル化した場合は「ホームフォルダ／apomi」を使う。
    プログラム（exe）とは別の場所なので、**バージョンアップで設定が消えない**。
    開発中（.pyのまま動かす）ときは、今までどおりスクリプトと同じフォルダ。
    """
    if IS_FROZEN:
        d = os.path.join(os.path.expanduser('~'), 'apomi')
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            pass
        return d
    return os.path.dirname(os.path.abspath(__file__))


def desktop_dir():
    """このパソコンの実際のデスクトップフォルダを返す。"""
    home = os.path.expanduser('~')
    if IS_WIN:
        # Windowsに正式なデスクトップの場所を問い合わせる（OneDrive移動済みでも正しく返る）
        try:
            import ctypes
            import ctypes.wintypes
            buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
            # CSIDL_DESKTOPDIRECTORY = 0x10, SHGFP_TYPE_CURRENT = 0
            if ctypes.windll.shell32.SHGetFolderPathW(None, 0x10, None, 0, buf) == 0 \
                    and buf.value and os.path.isdir(buf.value):
                return buf.value
        except Exception:
            pass
        for cand in (os.path.join(home, 'OneDrive', 'デスクトップ'),
                     os.path.join(home, 'OneDrive', 'Desktop'),
                     os.path.join(home, 'Desktop'),
                     os.path.join(home, 'デスクトップ')):
            if os.path.isdir(cand):
                return cand
        return home
    # Mac / Linux
    for cand in (os.path.join(home, 'Desktop'),
                 os.path.join(home, 'デスクトップ')):
        if os.path.isdir(cand):
            return cand
    return home


def open_path(path):
    """ファイルまたはフォルダを、OSの既定アプリで開く。"""
    try:
        if IS_WIN:
            os.startfile(path)  # type: ignore[attr-defined]
        elif IS_MAC:
            subprocess.Popen(['open', path])
        else:
            subprocess.Popen(['xdg-open', path])
    except Exception:
        pass
