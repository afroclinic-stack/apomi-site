# -*- coding: utf-8 -*-
"""EPARK歯科台帳「予約表（カレンダー）」印刷PDFを読み取って予約レコードに変換する。

Genifix版（parse_genifix.py）が「1行1予約の表」なのに対し、EPARKは
カレンダー型：横が担当者の列、縦が30分刻みの時間。予約1件は色のついた
四角として描かれていて、四角の高さがそのまま所要時間になっている。

そのため、文字の位置ではなく「四角（rect）」を手がかりに読む。
  ・四角の左端x  → どの担当者の列か
  ・四角の上端y  → 開始時刻
  ・四角の高さ   → 所要時間（30分＝1コマ）
  ・四角の中の文字 → 患者番号 / 氏名 / 処置内容

分かっている制約（2026-08-21 実物で確認）:
  ・担当者名はEPARK側が列幅で切るため略称になる（例「眞野(」）。
    正式名で照合したいときは 医院設定.json の staff_alias で読み替える。
  ・チェア（ユニット）の情報はPDFに無い。同時に何人まで診られるかは
    医院設定の台数で見る。
  ・1ファイルは最大2日分（EPARKの書き出しの上限）。
"""
import re
import sys
import json

import pdfplumber

# 予約ではない色（空きマス・下地）
PLAIN_COLORS = {(1.0, 1.0, 1.0), (0.867, 0.867, 0.867)}
CELL_MIN_W = 20      # 予約の列幅より細いものは無視（罫線の切れ端など）
CELL_MAX_W = 40      # 列をまたぐ帯（日付見出しなど）は無視


def _lines(page):
    """罫線の座標（縦・横）を返す"""
    vs = sorted(set(round(l['x0'], 1) for l in page.lines
                    if abs(l['x0'] - l['x1']) < 0.5))
    hs = sorted(set(round(l['top'], 1) for l in page.lines
                    if abs(l['top'] - l['bottom']) < 0.5))
    return vs, hs


def looks_like_epark(path):
    """このPDFがEPARKの予約表かどうかを判定する（読み取る前の見分け）"""
    try:
        with pdfplumber.open(path) as pdf:
            page = pdf.pages[0]
            vs, hs = _lines(page)
            if len(vs) < 5 or len(hs) < 8:
                return False
            head = (page.extract_text() or '')[:200]
            return bool(re.search(r'\d{1,2}月\d{1,2}日\([月火水木金土日]\)', head))
    except Exception:
        return False


def _text_lines(chars, x0, x1, y0, y1):
    """範囲内の文字を「行」にまとめて取り出す。
    1文字ずつの座標から行を復元しないと、隣の行と混ざって
    「133709分0」のような読み違いになる。"""
    cs = [c for c in chars if x0 - 1 <= c['x0'] and c['x1'] <= x1 + 1
          and y0 - 1 <= c['top'] < y1]
    if not cs:
        return []
    cs.sort(key=lambda c: (c['top'], c['x0']))
    rows, cur, base = [], [], None
    for c in cs:
        if base is None or abs(c['top'] - base) <= 1.0:      # 同じ行とみなす
            cur.append(c)
            base = c['top'] if base is None else base
        else:
            rows.append(cur)
            cur, base = [c], c['top']
    rows.append(cur)
    out = []
    for r in rows:
        r.sort(key=lambda c: c['x0'])
        out.append(''.join(c['text'] for c in r).strip())
    return [t for t in out if t]


def _text_rows(chars, x0, x1, y0, y1):
    """範囲内の文字を行にまとめ、(行の上端y, 文字列) の一覧で返す"""
    cs = [c for c in chars if x0 - 1 <= c['x0'] and c['x1'] <= x1 + 1
          and y0 - 1 <= c['top'] < y1]
    if not cs:
        return []
    cs.sort(key=lambda c: (c['top'], c['x0']))
    rows, cur, base = [], [], None
    for c in cs:
        if base is not None and abs(c['top'] - base) <= 1.0:
            cur.append(c)
        else:
            if cur:
                rows.append(cur)
            cur, base = [c], c['top']
    if cur:
        rows.append(cur)
    out = []
    for r in rows:
        r.sort(key=lambda c: c['x0'])
        t = ''.join(c['text'] for c in r).strip()
        if t:
            out.append((min(c['top'] for c in r), t))
    return out


def _blocks(page, body_top, step, vs):
    """予約の四角を拾って、重なり（塗り＋枠線）をまとめる"""
    found = []
    for r in page.rects:
        w, h = r['x1'] - r['x0'], r['bottom'] - r['top']
        if r['top'] < body_top - 1 or not (CELL_MIN_W <= w <= CELL_MAX_W):
            continue
        color = r.get('non_stroking_color')
        if abs(h - step) < 0.4 and (color in PLAIN_COLORS or color is None):
            continue                      # ただの空きマス
        if h < step * 0.6:
            continue                      # 小さすぎる装飾
        found.append(r)
    # 同じ予約が「塗り」と「枠線」で2回描かれるのでまとめる
    uniq = []
    for r in sorted(found, key=lambda r: (r['top'], r['x0'], -(r['bottom'] - r['top']))):
        dup = False
        for u in uniq:
            if (abs(u['x0'] - r['x0']) < 2 and abs(u['top'] - r['top']) < 2
                    and abs((u['bottom'] - u['top']) - (r['bottom'] - r['top'])) < 2):
                dup = True
                break
        if not dup:
            uniq.append(r)
    return uniq


def _round_min(m, step=5):
    return int(round(m / step) * step)


def _year_of(path):
    """PDFに年が入っていないので、ファイル名か更新日時から補う。
    EPARKの書き出しは 20260821_131005_appointCalendar.pdf のような名前になる。"""
    import os
    import datetime
    m = re.search(r'(20\d{2})(\d{2})(\d{2})', os.path.basename(path))
    if m:
        return int(m.group(1))
    try:
        return datetime.date.fromtimestamp(os.path.getmtime(path)).year
    except OSError:
        return datetime.date.today().year


def _to_reiwa(year, month, day):
    """apomi共通の「令和8.08.21」形式にそろえる"""
    return f'令和{year - 2018}.{month:02d}.{day:02d}'


def parse_pdf(path):
    """EPARKの予約表PDFを読んで、生のレコード（辞書）の一覧を返す"""
    records = []
    year = _year_of(path)
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            vs, hs = _lines(page)
            if len(vs) < 3 or len(hs) < 6:
                continue
            chars = page.chars
            # 見出し3段: [0]日付 [1]担当者名 [2]枠数 → 本文はその下から
            band_date = (hs[0], hs[1])
            band_head = (hs[1], hs[2])
            body_top = hs[3]
            step = hs[5] - hs[4] if len(hs) > 5 else 30.75

            date_txt = ' '.join(_text_lines(chars, vs[0], vs[-1], *band_date))
            dm = re.search(r'(\d{1,2})月(\d{1,2})日', date_txt)
            if not dm:
                continue
            date = _to_reiwa(year, int(dm.group(1)), int(dm.group(2)))

            heads = []
            for i in range(1, len(vs) - 1):
                t = ' '.join(_text_lines(chars, vs[i], vs[i + 1], *band_head))
                heads.append(t.strip())

            # 本文の最初の時刻（時間列の1コマ目）
            first = ' '.join(_text_lines(chars, vs[0], vs[1], body_top, body_top + step))
            fm = re.search(r'(\d{1,2}):(\d{2})', first)
            start_min = int(fm.group(1)) * 60 + int(fm.group(2)) if fm else 9 * 60

            # 列ごとにまとめて処理する。文字は四角からはみ出して次のコマに
            # 描かれることがあるため、1行の文字を「どれか1つの予約」にだけ
            # 割り当てる（そうしないと次の予約が前の予約の文字を拾ってしまう）
            blocks = _blocks(page, body_top, step, vs)
            by_col = {}
            for r in blocks:
                cands = [i for i in range(1, len(vs) - 1) if vs[i] <= r['x0'] + 1]
                if not cands:
                    continue
                by_col.setdefault(min(max(cands), len(vs) - 2), []).append(r)

            page_bottom = hs[-1] if hs else page.height
            for ci, rs in by_col.items():
                rs.sort(key=lambda r: r['top'])
                staff = heads[ci - 1] if ci - 1 < len(heads) else ''
                rows = _text_rows(chars, vs[ci], vs[ci + 1], body_top, page_bottom)
                for n, r in enumerate(rs):
                    nxt = rs[n + 1]['top'] if n + 1 < len(rs) else page_bottom
                    # 文字は四角の上端より少し下から描かれる。だから「上端より下」で
                    # 切ると、前の予約からはみ出した行を次の予約が拾わずに済む
                    lines = [t for y, t in rows if r['top'] < y < nxt]
                    s = start_min + _round_min((r['top'] - body_top) / step * 30)
                    e = start_min + _round_min((r['bottom'] - body_top) / step * 30)
                    if e <= s:
                        e = s + 30
                    records.append({
                        '予約日': date, '開始分': s, '終了分': e,
                        'スタッフ': staff, '本文': lines,
                    })
    return records


# ===== Excel書き出し（PDFより情報が多く、こちらが本命） =====
# 1行=5分。予約は「結合セル」で表され、結合の行数がそのまま所要時間になる。
# セルの中身は 患者番号 / 氏名(年齢) / 処置内容 が改行で並ぶ。
# 担当者名は略さずに役職つきで入る（例「粟飯原（歯科衛生士）」）。
ROW_MIN = 5


def _open_xls(path):
    import xlrd
    return xlrd.open_workbook(path, formatting_info=True,
                              ignore_workbook_corruption=True)


def looks_like_epark_excel(path):
    """EPARKのExcel書き出しかどうかを見分ける"""
    if not path.lower().endswith('.xls'):
        return False           # EPARKの書き出しは旧Excel形式（.xls）
    try:
        sh = _open_xls(path).sheet_by_index(0)
        head = ' '.join(str(sh.cell_value(0, c)) for c in range(min(sh.ncols, 6)))
        if not re.search(r'20\d{2}年\d{1,2}月\d{1,2}日', head):
            return False
        times = [str(sh.cell_value(r, 0)).strip() for r in range(2, min(sh.nrows, 40))]
        return sum(1 for t in times if re.match(r'^\d{1,2}:\d{2}$', t)) >= 2
    except Exception:
        return False


def parse_excel(path):
    """EPARKのExcel予約表を読んで、生のレコードの一覧を返す"""
    records = []
    book = _open_xls(path)
    for sh in book.sheets():
        head = ' '.join(str(sh.cell_value(0, c)) for c in range(min(sh.ncols, 8)))
        dm = re.search(r'(20\d{2})年(\d{1,2})月(\d{1,2})日', head)
        if not dm:
            continue
        date = _to_reiwa(int(dm.group(1)), int(dm.group(2)), int(dm.group(3)))

        # 見出し行（担当者名）と、時刻の基準行を探す
        heads = {c: str(sh.cell_value(1, c)).strip() for c in range(1, sh.ncols)}
        base_row, base_min = None, None
        for r in range(2, sh.nrows):
            t = str(sh.cell_value(r, 0)).strip()
            m = re.match(r'^(\d{1,2}):(\d{2})$', t)
            if m:
                base_row = r
                base_min = int(m.group(1)) * 60 + int(m.group(2))
                break
        if base_row is None:
            continue

        for (r1, r2, c1, c2) in sorted(sh.merged_cells):
            if r1 < base_row or c1 < 1:
                continue
            text = str(sh.cell_value(r1, c1)).strip()
            if not text:
                continue
            s = base_min + (r1 - base_row) * ROW_MIN
            e = base_min + (r2 - base_row) * ROW_MIN
            records.append({
                '予約日': date, '開始分': s, '終了分': max(e, s + ROW_MIN),
                'スタッフ': heads.get(c1, ''),
                '本文': [ln.strip() for ln in text.splitlines() if ln.strip()],
                '行区切り': True,   # Excelは改行が意味の区切り（PDFは折り返しなので違う）
            })
    return records


_AGE = re.compile(r'^(.*?)\s*[（(](\d{1,3})[)）]\s*$')
_NUM_NAME = re.compile(r'^(\d{2,6})\s*/?\s*(.*)$')


def clean(records):
    """患者番号・氏名・処置に分けて、apomiの標準レコードに整える"""
    out = []
    for r in records:
        lines = r['本文']
        age = ''
        if r.get('行区切り') and len(lines) >= 2 and lines[0].isdigit():
            # Excel: 1行目=患者番号 / 2行目=氏名(年齢) / 3行目以降=処置
            pno = lines[0]
            name = lines[1]
            am = _AGE.match(name)
            if am:
                name, age = am.group(1).strip(), am.group(2)
            proc = ' '.join(lines[2:]).strip()
            body = ' '.join(lines)
        else:
            # PDF: 行はセルの幅で折り返されているだけなので、そのままつなぐ
            # （空白を入れると「保 坂昌利」のように氏名が割れてしまう）
            body = ''.join(lines) if not r.get('行区切り') else ' '.join(lines)
            body = re.sub(r'[　\s]+', ' ', body).strip()
            if not body:
                continue    # 文字のない色枠（予約を入れない枠など）は予約にしない
            pno, name, proc = '', '', body
            m = _NUM_NAME.match(body)
            if m:
                pno = m.group(1)
                rest = m.group(2)
                # 「氏名/処置」…氏名は最初の「/」まで
                if '/' in rest:
                    name, proc = rest.split('/', 1)
                else:
                    parts = rest.split(' ', 1)
                    name = parts[0]
                    proc = parts[1] if len(parts) > 1 else ''
            else:
                # 番号なし（新患メモなど）はすべて処置扱いにして残す
                proc = body
        if not (pno or name or proc):
            continue

        def hm(v):
            return f'{v // 60:02d}:{v % 60:02d}'

        out.append({
            '予約日': r['予約日'],
            '開始': hm(r['開始分']), '終了': hm(r['終了分']),
            '区分': '',
            '患者No': pno.strip(),
            '氏名': name.strip(),
            '性別': '', '年齢': age,
            'スタッフ': r['スタッフ'].strip(),
            'チェア': '',            # EPARKのPDFにユニットの情報は無い
            '処置名': proc.strip(),
            '主訴': '',
            '特記事項': '',
            '要注意': '',
        })
    out.sort(key=lambda r: (r['予約日'], r['開始']))
    return out


if __name__ == '__main__':
    recs = clean(parse_pdf(sys.argv[1]))
    print('total:', len(recs))
    print('担当者一覧:', sorted({r['スタッフ'] for r in recs}))
    print(json.dumps(recs[:10], ensure_ascii=False, indent=1))
