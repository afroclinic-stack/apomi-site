#!/bin/bash
# apomi セットアップ（Mac用）
# このファイルを右クリック →「開く」で実行してください。
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo "=================================================="
echo "  apomi (アポパトロール) セットアップ — Mac"
echo "=================================================="
echo ""

# ---- 1. Python3 を確認 ----
echo "[1/4] Python3 を確認しています..."
if ! command -v python3 >/dev/null 2>&1; then
  echo "   このMacに Python3 が見つかりませんでした。"
  echo "   python.org からインストールしてから、もう一度このファイルを実行してください。"
  open "https://www.python.org/downloads/macos/" || true
  echo ""
  read -n 1 -s -r -p "Enterキーで終了します"
  exit 1
fi
echo "   OK: $(python3 --version)"

# ---- 2. 専用のPython環境（venv）を作って部品を入れる ----
echo "[2/4] 必要な部品をインストールしています（数分かかります）..."
if [ ! -d "$DIR/.venv" ]; then
  python3 -m venv "$DIR/.venv"
fi
PY="$DIR/.venv/bin/python3"
"$PY" -m pip install --upgrade pip >/dev/null 2>&1 || true
"$PY" -m pip install pdfplumber pillow >/dev/null 2>&1
echo "   OK"

# ---- 3. 自動起動（ログイン時に見張りを開始）を設定 ----
echo "[3/4] 自動起動を設定しています..."
mkdir -p "$HOME/Library/LaunchAgents"
PLIST="$HOME/Library/LaunchAgents/com.apomi.watch.plist"
cat > "$PLIST" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.apomi.watch</string>
  <key>ProgramArguments</key>
  <array>
    <string>$PY</string>
    <string>$DIR/watch_patrol.py</string>
  </array>
  <key>WorkingDirectory</key><string>$DIR</string>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$DIR/launchd_out.log</string>
  <key>StandardErrorPath</key><string>$DIR/launchd_err.log</string>
</dict>
</plist>
PLISTEOF
launchctl unload "$PLIST" >/dev/null 2>&1 || true
launchctl load "$PLIST"
echo "   OK: ログイン時に自動で見張りを開始します"

# ---- 4. デスクトップに「アポチェック」を作る ----
echo "[4/4] デスクトップに「アポチェック」を作っています..."
DESK="$HOME/Desktop"
[ -d "$DESK" ] || DESK="$HOME/デスクトップ"
LAUNCHER="$DESK/アポチェック.command"
cat > "$LAUNCHER" <<LAUNCHEOF
#!/bin/bash
cd "$DIR"
"$PY" "$DIR/run_inbox.py"
LAUNCHEOF
chmod +x "$LAUNCHER"
echo "   OK"

# 見張りが作る取り込みフォルダを先に用意
"$PY" -c "import sys; sys.path.insert(0,'$DIR'); import watch_patrol as w; w.ensure_inbox()" || true

echo ""
echo "=================================================="
echo "  セットアップ完了！"
echo "=================================================="
echo ""
echo "使い方:"
echo "  ・予約一覧を CSV か PDF で書き出し、デスクトップの"
echo "    「apomi_取込」フォルダに保存すると、自動でチェックが走ります。"
echo "  ・すぐ実行したいときは、デスクトップの「アポチェック」をダブルクリック。"
echo ""
read -n 1 -s -r -p "Enterキーで終了します"
